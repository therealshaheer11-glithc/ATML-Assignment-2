"""Block 10: install the reviewed wheel set only in an isolated A100 venv."""
from datetime import datetime, timezone
import importlib.metadata as metadata
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import venv

from packaging.markers import default_environment
from packaging.tags import sys_tags
from packaging.utils import canonicalize_name

from guards import (clean_environment, disk_requirement, install_command,
                    requirement_lines, require, validate_inventory)

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
EXPERIMENT = Path('/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1')
LOCAL = Path('/content/task4_isolated_runtime_v1')
STAGE1 = '9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65'
WHEELS = 'df469ec50f8fc5e493f2f818eb490858c713eb88e3216309aeb43e5fb49a7aab'
WHEEL_ATTEMPT = '20261011T151647.989109Z'
GPU = 'd941ecb6c16ec91a942b319167826007f5124b0dedc10d2a337b3b783ff4015b'
ORCHESTRATION = '35ca690761d2bfda0992ff37855b16fc72c03ffd4b47afaa81edc533ab7a5f65'
DIAGNOSTIC = '71bdb7fdbe130c5adaef8328437371bcd89621d0a93e849bab61b7db8491c540'


def read(path):
    return json.loads(Path(path).read_text())


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def inventory():
    return {canonicalize_name(item.metadata['Name']): item.version for item in metadata.distributions()
            if item.metadata.get('Name')}


def main():
    first = EXPERIMENT / 'preflight_releases' / STAGE1
    # Use the already sealed helper for streaming hashes and immutable evidence.
    import hashlib
    quick_digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
    require(quick_digest(first / 'MANIFEST.json') == STAGE1, 'Original source identity differs')
    require(quick_digest(first / 'scripts/preflight.py') == read(first / 'MANIFEST.json')['scripts/preflight.py'],
            'Original preflight helper differs')
    preflight = load('task4_isolated_preflight', first / 'scripts/preflight.py')
    digest = preflight.sha256
    preflight.verify_source(first)
    own = preflight.verify_source(ROOT)
    require(read(EXPERIMENT / 'OWNER.json')['approval_sha256'] == digest(first / 'docs/approval.json'),
            'Task 4 ownership differs')
    approval = read(ROOT / 'APPROVAL.json')
    require(approval['approved'] is True and approval['user_message'] == 'approved' and
            'isolated A100 environment preserving all 84 reviewed pins' in approval['approved_scope'] and
            approval['approved_proposal_sha256'] == digest(ROOT / 'APPROVED_PROPOSAL.md') and
            approval['approved_isolated_versions_sha256'] == digest(ROOT / 'APPROVED_ISOLATED_VERSIONS.json') and
            approval['gpu_exceptions_authorized'] is False, 'Exact isolated setup approval differs')
    save, save_bytes = preflight.immutable_json, preflight.immutable_bytes
    identity = own['manifest_sha256']
    release = EXPERIMENT / 'isolated_gpu_releases' / identity
    for name in [*read(ROOT / 'MANIFEST.json'), 'MANIFEST.json']:
        save_bytes(release / name, (ROOT / name).read_bytes())
    attempt_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    attempt = EXPERIMENT / 'isolated_gpu_attempts' / attempt_id
    attempt.mkdir(parents=True, exist_ok=False)
    report = {'format': 'ATML_TASK4_ISOLATED_A100_ATTEMPT_V1', 'status': 'RUNNING',
              'attempt_utc': attempt_id, 'source_manifest_sha256': identity,
              'approval_sha256': digest(ROOT / 'APPROVAL.json'), 'commands': [],
              'isolated_package_installation_attempted': False, 'base_package_changes_performed': False,
              'model_downloads_performed': False, 'pretrained_models_loaded': 0,
              'task4_responses_generated': 0, 'task4_judgments_produced': 0,
              'human_labels_assigned': 0, 'training_performed': False, 'gpu_exceptions_accepted': []}

    def command(argv, name, environment=None):
        event = {'stage': name, 'argv': [str(value) for value in argv],
                 'environment_policy': 'Driver settings preserved; inherited Python/pip settings removed; pip config disabled; offline HF.'}
        save(attempt / (name + '_command.json'), event)
        print('Isolated A100 preparation:', name, flush=True)
        with (attempt / (name + '.log')).open('x') as log:
            process = subprocess.Popen(event['argv'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                       text=True, bufsize=1, env=environment or clean_environment(os.environ),
                                       cwd='/content')
            for line in process.stdout:
                log.write(line); log.flush()
                print(line, end='', flush=True)
            event['returncode'] = process.wait()
        event['log_sha256'] = digest(attempt / (name + '.log'))
        save(attempt / (name + '_result.json'), event)
        report['commands'].append(event)
        require(event['returncode'] == 0, name + ' failed; no fallback or automatic repair is applied')

    try:
        save(attempt / 'START.json', report)
        before = inventory()
        save(attempt / 'BASE_PACKAGE_VERSIONS_BEFORE.json', before)
        folders = {}
        for kind, source in [('wheel_cache', WHEELS), ('gpu_environment', GPU),
                             ('orchestration', ORCHESTRATION), ('diagnostic', DIAGNOSTIC)]:
            folder = EXPERIMENT / (kind + '_releases') / source
            require(digest(folder / 'MANIFEST.json') == source, 'Historical source identity differs: ' + kind)
            preflight.verify_source(folder)
            folders[kind] = folder
        # Load exactly the previously checked download guards; do not change them.
        wheels = load('wheels', folders['wheel_cache'] / 'wheels.py')
        cache_module = load('cache_wheels', folders['wheel_cache'] / 'cache_wheels.py')
        gates = load('task4_original_gpu_gates', folders['gpu_environment'] / 'gates.py')
        require(digest(folders['wheel_cache'] / 'APPROVAL.json') == report['approval_sha256'],
                'Wheel download approval and current inherited setup approval differ')
        command(['nvidia-smi', '--query-gpu=name,memory.total,driver_version,uuid',
                 '--format=csv,noheader,nounits'], 'nvidia_inventory')
        hardware = gates.parse_a100_inventory((attempt / 'nvidia_inventory.log').read_text())
        save(attempt / 'A100_HARDWARE.json', hardware)
        previous_folder = EXPERIMENT / 'wheel_cache_attempts' / WHEEL_ATTEMPT
        previous = read(previous_folder / 'REPORT.json')
        require(previous['source_manifest_sha256'] == WHEELS and
                previous['status'] == 'CPU_WHEEL_CACHE_VERIFIED_NO_INSTALLATION' and
                previous['verified_file_count'] == previous['inspected_metadata_count'] == 90 and
                previous['compressed_verified_bytes'] == 2969739166 and
                previous['course_dependency_distributions'] == 83 and
                previous['isolated_dependency_distributions'] == 84 and
                previous['actual_wheel_dependency_closure_passed'] is True and
                previous['cpu_package_inventory_unchanged'] is True, 'Returned wheel-cache result differs')
        for name, expected in previous['artifact_sha256'].items():
            require(digest(previous_folder / wheels.safe_name(name)) == expected,
                    'Saved wheel-cache artifact differs: ' + name)
        wheelhouse = EXPERIMENT / 'environment_wheelhouse'
        contract_path = wheelhouse / 'VERIFIED_WHEELHOUSE_CONTRACT.json'
        require(digest(contract_path) == previous['verified_wheelhouse_contract_sha256'],
                'Verified wheelhouse contract differs')
        wheel_contract = read(contract_path)
        require(wheel_contract['format'] == 'ATML_TASK4_VERIFIED_WHEELHOUSE_V1' and
                wheel_contract['source_manifest_sha256'] == WHEELS and wheel_contract['all_wheels_verified'] is True and
                wheel_contract['approval_sha256'] == report['approval_sha256'] and
                wheel_contract['cache_identity_contract_sha256'] == digest(wheelhouse / 'CACHE_IDENTITY_CONTRACT.json'),
                'Wheelhouse provenance differs')
        binding = read(wheelhouse / 'CACHE_IDENTITY_CONTRACT.json')
        for key, value in binding.items():
            if key != 'format':
                require(wheel_contract[key] == value, 'Wheel cache binding differs: ' + key)
        plan = read(previous_folder / 'APPROVED_ISOLATION_PROPOSAL.json')
        require(digest(previous_folder / 'APPROVED_ISOLATION_PROPOSAL.json') ==
                wheel_contract['isolation_proposal_sha256'], 'Approved isolation proposal differs')
        pins = read(ROOT / 'APPROVED_ISOLATED_VERSIONS.json')
        require(wheel_contract['isolated_package_versions'] == pins, 'Exact 84 isolated versions differ')
        target = wheel_contract['saved_gpu_marker_environment']
        current = default_environment()
        for key in ['implementation_name', 'python_full_version', 'platform_machine', 'platform_system']:
            require(current[key] == target[key], 'A100 Python/platform differs from the reviewed target: ' + key)
        tags = list(sys_tags())
        files = cache_module.validate_plan(plan, pins, tags, target['python_full_version'])
        require(files == wheel_contract['files'], 'Approved wheel records differ')
        require(wheel_contract['relative_wheel_directory'] == 'wheels' and
                wheel_contract['relative_receipt_directory'] == 'receipts', 'Wheel layout differs')
        wheels_dir, receipts = wheelhouse / 'wheels', wheelhouse / 'receipts'
        require(not wheelhouse.is_symlink() and not wheels_dir.is_symlink() and not receipts.is_symlink(),
                'Wheelhouse contains a directory symlink')
        require({p.name for p in wheels_dir.iterdir()} == set(files) and
                {p.name for p in receipts.iterdir()} == {name + '.json' for name in files},
                'Completed wheel/receipt coverage differs')
        for index, (name, record) in enumerate(files.items(), 1):
            print('Fresh A100 wheel check', str(index) + '/90:', name, flush=True)
            result = wheels.verify_file(wheels_dir / name, record)
            require(result == wheel_contract['verified_files'][name] == read(receipts / (name + '.json')),
                    'Cached wheel receipt differs: ' + name)
            inspected = wheels.inspect_wheel(wheels_dir / name, record, tags, target['python_full_version'])
            require(inspected == wheel_contract['wheel_inspections'][name], 'Cached wheel metadata differs: ' + name)
        save(attempt / 'FRESH_A100_WHEEL_CHECKS.json', {'verified': 90, 'tags_validated': True,
             'metadata_matches_frozen_contract': True, 'compatible_tags': [str(tag) for tag in tags]})
        protocol = EXPERIMENT / 'CPU_ORCHESTRATION_VALIDATION_CONTRACT.json'
        require(digest(protocol) == plan['cpu_orchestration_contract_sha256'], 'Frozen CPU protocol differs')
        cpu = read(protocol)
        require(cpu['tests_passed'] == 37 and cpu['source_manifest_sha256'] == ORCHESTRATION,
                'CPU synthetic validation contract differs')
        require(digest(EXPERIMENT / 'CPU_MODEL_INPUT_CONTRACT.json') == cpu['model_input_contract_sha256'],
                'Frozen model input contract differs')
        inputs = read(EXPERIMENT / 'CPU_MODEL_INPUT_CONTRACT.json')
        for name, key in [('INPUT_IDENTITY_CONTRACT.json', 'input_contract_sha256'),
                          ('AUDIT_ID_CONTRACT.json', 'audit_id_contract_sha256'),
                          ('BASE_MODEL_REFERENCE.json', 'base_model_reference_sha256'),
                          ('JUDGE_SNAPSHOT_CONTRACT.json', 'judge_snapshot_contract_sha256')]:
            require(digest(EXPERIMENT / name) == inputs[key], 'Frozen preparation identity differs: ' + name)
        require(inputs['policy_order'] == ['sft', 'dpo', 'ppo', 'grpo'] and inputs['sft_adapter'] is None,
                'Approved policies differ')
        logical_bytes = wheel_contract['sizes']['isolated_84_wheels_zip_uncompressed_file_bytes']
        require(logical_bytes == 5522644346 and
                wheel_contract['sizes']['largest_isolated_wheel_uncompressed_file_bytes'] == 1136912993,
                'Returned size measurements differ')
        space = disk_requirement(logical_bytes, shutil.disk_usage('/content').free)
        save(attempt / 'LOCAL_INSTALLATION_SPACE_CHECK.json', space)
        owner = {'format': 'ATML_TASK4_LOCAL_ISOLATION_OWNER_V1', 'directory': str(LOCAL),
                 'source_manifest_sha256': identity, 'approval_sha256': report['approval_sha256'],
                 'wheelhouse_contract_sha256': digest(contract_path),
                 'base_python_executable': str(Path(sys.executable).resolve()),
                 'target_python_full_version': target['python_full_version'], 'system_site_packages': False}
        owner_file = LOCAL / '.task4_isolation_owner.json'
        require(not LOCAL.is_symlink(), 'Isolated environment path is a symlink')
        if LOCAL.exists():
            require(owner_file.is_file() and read(owner_file) == owner, 'Existing local environment is not the approved owned environment')
        else:
            LOCAL.mkdir()
            save(owner_file, owner)
        if not (LOCAL / 'pyvenv.cfg').exists():
            print('Creating isolated local environment without bundled pip or system packages.', flush=True)
            venv.EnvBuilder(with_pip=False, system_site_packages=False, clear=False, symlinks=True).create(LOCAL)
        python = LOCAL / 'bin/python'
        require(python.exists(), 'Isolated interpreter was not created')
        command([python, '-I', '-B', ROOT / 'inspect_python.py', attempt / 'ISOLATED_INVENTORY_BEFORE.json'],
                'inspect_isolation_before')
        installed = validate_inventory(read(attempt / 'ISOLATED_INVENTORY_BEFORE.json'), pins, LOCAL)
        require(read(attempt / 'ISOLATED_INVENTORY_BEFORE.json')['python'] == target['python_full_version'],
                'Isolated Python version differs')
        requirements = attempt / 'OFFLINE_HASHED_REQUIREMENTS.txt'
        save_bytes(requirements, requirement_lines(files, pins, wheels_dir).encode())
        report['isolated_package_installation_attempted'] = True
        if 'pip' not in installed:
            pip_requirements = attempt / 'OFFLINE_PIP_BOOTSTRAP_REQUIREMENTS.txt'
            save_bytes(pip_requirements, requirement_lines(files, {'pip': pins['pip']}, wheels_dir).encode())
            pip_record = next(record for record in files.values() if record['package'] == 'pip' and record['version'] == pins['pip'])
            command(install_command(python, pip_requirements, attempt / 'PIP_BOOTSTRAP_INSTALL_REPORT.json', bootstrap=True),
                    'bootstrap_approved_pip', clean_environment(os.environ, wheels_dir / pip_record['filename']))
        command(install_command(python, requirements, attempt / 'ISOLATED_INSTALL_REPORT.json'),
                'install_exact_offline_pins')
        command([python, '-I', '-B', ROOT / 'inspect_python.py', attempt / 'ISOLATED_INVENTORY_AFTER.json'],
                'inspect_isolation_after')
        after_inventory = read(attempt / 'ISOLATED_INVENTORY_AFTER.json')
        validate_inventory(after_inventory, pins, LOCAL, complete=True)
        command([python, '-I', '-B', '-m', 'pip', '--disable-pip-version-check', 'check'],
                'isolated_full_dependency_check')
        probe_directory = attempt / 'fresh_probe'
        probe_directory.mkdir()
        command([python, '-I', '-B', '-u', folders['gpu_environment'] / 'probe_gpu.py',
                 first, folders['orchestration'], folders['diagnostic'], probe_directory],
                'preserved_fresh_a100_probe')
        probe = read(probe_directory / 'GPU_PROBE.json')
        expected_course = {name: version for name, version in pins.items() if name != 'pip'}
        require(probe['all_required_package_versions'] == expected_course and
                probe['required_distributions'] == 83 and probe['synthetic_semantic_checks_passed'] == 37 and
                probe['required_dependency_chain_passed'] and probe['fresh_process_imports_passed'] and
                probe['tiny_float16_cuda_check_passed'] and probe['tiny_nf4_cuda_backend_check_passed'] and
                probe['pretrained_model_weights_loaded'] is False, 'Isolated A100 validation is incomplete')
        after = inventory()
        save(attempt / 'BASE_PACKAGE_VERSIONS_AFTER.json', after)
        require(before == after, 'Colab base package inventory changed unexpectedly')
        isolated_contract = {'format': 'ATML_TASK4_ISOLATED_A100_ENVIRONMENT_V1',
            'source_manifest_sha256': identity, 'approval_sha256': report['approval_sha256'],
            'wheelhouse_contract_sha256': digest(contract_path), 'environment_directory': str(LOCAL),
            'python_executable': str(python), 'python': after_inventory['python'],
            'isolated_package_versions': pins, 'all_required_package_versions': expected_course,
            'required_distributions': 83, 'isolated_distributions': 84,
            'cpu_orchestration_contract_sha256': digest(protocol),
            'model_input_contract_sha256': digest(EXPERIMENT / 'CPU_MODEL_INPUT_CONTRACT.json'),
            'course_requirements_sha256': digest(first / 'course_reference/requirements.txt'),
            'system_site_packages': False, 'user_site_enabled': False,
            'isolated_full_dependency_check_passed': True, 'required_dependency_chain_passed': True,
            'fresh_process_imports_passed': True, 'tiny_float16_cuda_check_passed': True,
            'tiny_nf4_cuda_backend_check_passed': True, 'torch_cuda_version': probe['torch_cuda_version'],
            'synthetic_semantic_checks_passed': 37, 'hardware_requirement': 'A100, compute capability 8.0',
            'base_package_inventory_unchanged_by_this_block': True,
            'colab_base_repair_and_full_validation_pending': True,
            'gpu_exceptions_accepted': [], 'pretrained_model_weights_loaded': False,
            'gpu_model_loading_validation_pending': True}
        save(EXPERIMENT / 'ISOLATED_GPU_ENVIRONMENT_CONTRACT.json', isolated_contract)
        report.update({'status': 'ISOLATED_A100_ENVIRONMENT_VALIDATED_BASE_REPAIR_PENDING',
                       'fresh_wheels_verified': 90, 'isolated_distribution_count': 84,
                       'required_distribution_count': 83, 'isolated_full_dependency_check_passed': True,
                       'synthetic_checks_passed': 37, 'fresh_imports_cuda_and_nf4_passed': True,
                       'base_package_inventory_unchanged': True,
                       'isolated_environment_contract_sha256': digest(EXPERIMENT / 'ISOLATED_GPU_ENVIRONMENT_CONTRACT.json'),
                       'colab_base_repair_pending': True,
                       'local_free_bytes_after': shutil.disk_usage('/content').free})
        print('Isolated A100 environment: 84/84 exact distributions; full dependency check PASS.', flush=True)
        print('Course chain 83; fresh imports/CUDA/NF4 PASS; synthetic checks 37/37 PASS.', flush=True)
        print('Colab base inventory unchanged. Its approved repair is the next block.', flush=True)
        print('No model loading, generation, judging or training. Remaining: 1800 responses, 1800 judgments, 240 human labels.', flush=True)
        print('Keep this A100 runtime connected; return this output before continuing.', flush=True)
    except BaseException as error:
        report.update({'status': 'ISOLATED_A100_PREPARATION_FAILED_PRESERVED',
                       'error': {'type': type(error).__name__, 'message': str(error)}})
        raise
    finally:
        report['artifact_sha256'] = {p.relative_to(attempt).as_posix(): digest(p)
                                    for p in attempt.rglob('*') if p.is_file()}
        save(attempt / 'REPORT.json', report)
        print('Saved isolated A100 report:', attempt / 'REPORT.json', flush=True)
        print('Status:', report['status'], flush=True)


if __name__ == '__main__':
    main()
