# Task 4 Block 2: CPU environment and fixed audit IDs

User approval: recommendations 1-4, confirmed on 11 October 2026 with “Yes I approve but document everything”. APPROVAL.json reproduces the approved scope. No new experiment setting is introduced.

## Verified state entering this block

The user returned INPUT_IDENTITIES_VERIFIED from attempt 20261011T102954.170579Z. All four input groups passed and the frozen source/input contracts were read back. XSTest has 450 prompts: 250 safe and 200 unsafe. Standard adapter records identify DPO one epoch/94 updates, PPO 20 updates and GRPO 20 updates. Planned work: 1,800 deterministic responses, 1,800 categorical judge calls and 240 human labels for the same 60 prompt IDs across four policies. Actual Task 4 generation, judging and human labels are all zero.

The starting Colab CPU environment reported Python 3.13.16, Torch 2.11.0+cpu, Transformers 5.18.0, Tokenizers 0.23.2, PEFT 0.21.1, NumPy 2.1.3 and Pandas 2.2.3; TRL and bitsandbytes were absent. This block has not been executed or installed locally. Its actual Colab result remains pending.

## Operation

Remain on CPU / hardware accelerator None. Upload ATML_PA2_Task4_CPU_Environment.zip to the single supplied launch cell. The cell verifies the package and streams child-process output into the notebook, correcting the display limitation observed in Block 1.

The script verifies the entire original first-stage source manifest, its exact input attempt and the immutable input identity contract before installing anything. It installs the unchanged course requirements with the current Colab interpreter and records the exact command, before/after package inventories, installation JSON report, complete logs and return codes. The four exact pins remain Transformers 4.57.1, Tokenizers 0.22.1, PEFT 0.17.1 and TRL 0.27.2; all other packages must meet the released bounds. It does not silently invent alternate pins, uninstall unrelated packages or select another interpreter. Packages are installed in Colab, not on the user's computer.

It runs the original course environment checker, then strictly validates every released requirement and imports the needed model/data classes in a fresh Python process. No model is constructed or downloaded. A global pip check must pass. Installation/import/dependency failure stops and preserves the report; it does not trigger an automatic workaround. Package metadata and download provenance are recorded with pip's documented --report feature: https://pip.pypa.io/en/stable/reference/installation-report/ . Dependency verification follows https://pip.pypa.io/en/stable/cli/pip_check/ . The report is provenance, not itself an installation lock file.

The same fresh process applies the unchanged course fixed_audit_ids function to the fixed CSV's class/ID metadata in its preserved order. The function does not use response text, so this is the same input metadata/order that generated_sft.jsonl will contain. It freezes 30 SAFE plus 30 UNSAFE IDs using seed 6304 and records the selected IDs, NumPy version, helper hash, CSV hash and subtype counts. It does not impose new subtype quotas, inspect responses/judge labels, or assign any manual labels.

## Saved evidence

Drive root: MyDrive/ATML-Assignment-2/task4/experiment_v1.

- environment_releases/<source manifest SHA-256>/: immutable source, documentation, approval and entered-state observation.
- environment_attempts/<UTC attempt>/: each exact command and result, full logs, pip installation report, before/after inventories, fresh-process probe source/results, and REPORT.json even after a catchable failure.
- AUDIT_ID_CONTRACT.json: immutable selected IDs, written after successful checks.
- CPU_ENVIRONMENT_CONTRACT.json: immutable actual CPU package versions, requirement hash, approval identity and validation results.

Previously saved files are not overwritten on a conflicting rerun. Python source bytecode writing is disabled for the source/probe process so preserved source copies remain unchanged. Prior-task data, model artifacts and receipts are read only.

## Remaining work

Base/judge snapshot preparation and inference-pipeline implementation/CPU validation remain pending. GPU feasibility, model loading, deterministic generation, AI judging, blind human audit, aggregate analysis and final export are later blocks. A successful environment check is not model-inference validation. Return the complete cell output before the next block.

## Attribution and local validation

Course reference commit: 1d64ac65acd5e45d1e4e1f415edc80455e21274e. Preserved first-stage source manifest: 9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65. Course environment and audit helpers are reused without modification. New orchestration/packaging was created with Codex coding assistance under the recorded approval.

Local validation checks the outer script and embedded fresh-process probe for Python syntax, rechecks the previous release hashes and ZIP payload integrity, and records the tested source hash. It does not install the Colab environment or claim actual dependency/import success. The earlier 20 synthetic preflight tests remain in the unchanged first-stage release.
