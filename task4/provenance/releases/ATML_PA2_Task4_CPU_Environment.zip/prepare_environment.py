"""Task 4 Block 2: install the released CPU environment and freeze audit IDs.

No base/judge model download, model construction, generation or training occurs.
The unchanged course requirements define installation; no package-removal,
compatibility workaround or alternate version is silently applied.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parent
EXPERIMENT = Path("/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1")
STAGE1_MANIFEST = "9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65"
INPUT_ATTEMPT = "20261011T102954.170579Z"

PROBE = r'''
from pathlib import Path
import hashlib, importlib.metadata, json, platform, sys
sys.dont_write_bytecode = True
from packaging.requirements import Requirement

release, input_contract_path, destination = map(Path, sys.argv[1:])
course = release / "course_reference"
sys.path.insert(0, str(course))
versions = {}
for line in (course / "requirements.txt").read_text().splitlines():
    if not line.strip() or line.lstrip().startswith("#"):
        continue
    requirement = Requirement(line)
    actual = importlib.metadata.version(requirement.name)
    assert requirement.specifier.contains(actual, prereleases=False), (line, actual)
    versions[requirement.name] = actual

import torch, transformers, tokenizers, peft, trl
import datasets, accelerate, bitsandbytes, numpy as np, pandas as pd
import safetensors, yaml, matplotlib, sklearn, tqdm
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from peft import PeftModel
from common.data import load_yaml
from task4_safety.make_audit_sheet import fixed_audit_ids
from task4_safety.judge_responses import judge_one, parse_json, LABELS

assert not torch.cuda.is_available(), "Use a CPU runtime for Block 2."
cfg = load_yaml("configs/feedback.yaml")
assert cfg["seed"] == 6304 and cfg["safety_max_new_tokens"] == 256
assert cfg["judge_max_new_tokens"] == 64 and cfg["manual_audit_per_class"] == 30
assert cfg["base_model"] == "Qwen/Qwen2.5-1.5B-Instruct"
assert cfg["ai_judge_model"] == "Qwen/Qwen2.5-3B-Instruct"
assert cfg["dtype"] == "float16" and cfg["quantize_frozen_models"] is True
assert len(LABELS) == 5

contract = json.loads(input_contract_path.read_text())
data = contract["inputs"]["xstest"]
csv_path = Path(data["path"])
assert hashlib.sha256(csv_path.read_bytes()).hexdigest() == data["sha256"]
frame = pd.read_csv(csv_path)
assert frame["xstest_id"].astype(int).tolist() == data["ordered_prompt_ids"]
# The course function uses only class/ID metadata. This is exactly the row
# order that generated_sft.jsonl will retain; no response or AI label is used.
selected = fixed_audit_ids(frame.to_dict("records"), per_class=30, seed=6304)
assert len(selected) == len(set(selected)) == 60 and selected == sorted(selected)
subset = frame.loc[frame["xstest_id"].isin(selected)]
counts = {str(k): int(v) for k, v in subset["benchmark_class"].value_counts().items()}
assert counts == {"SAFE": 30, "UNSAFE": 30}
helper = course / "task4_safety/make_audit_sheet.py"
audit = {"format": "ATML_TASK4_AUDIT_IDS_V1", "xstest_sha256": data["sha256"],
         "helper_sha256": hashlib.sha256(helper.read_bytes()).hexdigest(),
         "selection": "Unchanged course fixed_audit_ids on preserved CSV metadata/order",
         "seed": 6304, "per_class": 30, "numpy_version": np.__version__,
         "ordered_audit_prompt_ids": selected, "class_counts": counts,
         "same_ids_for_all_four_policies": True, "manual_response_labels": 240,
         "type_counts_in_selected_subset": {str(k): int(v) for k, v in subset["type"].value_counts().items()},
         "responses_or_ai_labels_used_for_selection": False,
         "manual_labels_assigned": 0}
result = {"python": platform.python_version(), "course_package_versions": versions,
          "cuda_available": False, "fresh_process_imports_passed": True,
          "all_course_requirement_specifiers_satisfied": True,
          "model_weights_loaded": False, "audit": audit}
destination.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
assert json.loads(destination.read_text()) == result
print("Fresh-process imports and all course requirement bounds: PASS", flush=True)
print("Core versions:", json.dumps({k: versions[k] for k in ["torch", "transformers", "tokenizers", "peft", "trl", "numpy"]}), flush=True)
print("Audit selection: 60 fixed prompt IDs, 30 SAFE / 30 UNSAFE; 240 human labels planned.", flush=True)
'''


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verified_manifest(folder, expected=None):
    manifest_path = folder / "MANIFEST.json"
    if expected is not None and digest(manifest_path) != expected:
        raise RuntimeError("Source manifest identity differs: " + str(folder))
    manifest = json.loads(manifest_path.read_text())
    for name, expected_digest in manifest.items():
        path = folder / name
        if not path.is_file() or path.is_symlink() or digest(path) != expected_digest:
            raise RuntimeError("Source file differs: " + name)
    return manifest


def main():
    release = EXPERIMENT / "preflight_releases" / STAGE1_MANIFEST
    verified_manifest(release, STAGE1_MANIFEST)
    own_manifest = verified_manifest(ROOT)
    spec = importlib.util.spec_from_file_location("task4_frozen_preflight", release / "scripts/preflight.py")
    preflight = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(preflight)
    preflight.require_cpu()
    immutable_json, immutable_bytes, require = preflight.immutable_json, preflight.immutable_bytes, preflight.require
    approval = json.loads((release / "docs/approval.json").read_text())
    require(approval["approved"] is True, "Task 4 approval is missing")
    approval_hash = digest(release / "docs/approval.json")
    require(json.loads((EXPERIMENT / "OWNER.json").read_text())["approval_sha256"] == approval_hash,
            "Experiment owner differs")
    contract_path = EXPERIMENT / "INPUT_IDENTITY_CONTRACT.json"
    contract = json.loads(contract_path.read_text())
    report_path = EXPERIMENT / "preflight_attempts" / INPUT_ATTEMPT / "REPORT.json"
    input_report = json.loads(report_path.read_text())
    require(input_report["status"] == "INPUT_IDENTITIES_VERIFIED", "The verified input attempt is unavailable")
    require(contract["inputs"] == input_report["checks"] and
            contract["planned_units"] == input_report["planned_units"] and
            contract["approval_sha256"] == approval_hash, "Input contract differs from the verified report")
    require(contract["planned_units"]["responses"] == 1800, "Verified workload differs")
    own_identity = digest(ROOT / "MANIFEST.json")
    persistent_source = EXPERIMENT / "environment_releases" / own_identity
    for name in own_manifest:
        immutable_bytes(persistent_source / name, (ROOT / name).read_bytes())
    immutable_bytes(persistent_source / "MANIFEST.json", (ROOT / "MANIFEST.json").read_bytes())
    attempt_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    attempt = EXPERIMENT / "environment_attempts" / attempt_id
    attempt.mkdir(parents=True, exist_ok=False)
    requirements = release / "course_reference/requirements.txt"
    report = {"format": "ATML_TASK4_CPU_ENVIRONMENT_ATTEMPT_V1", "attempt_utc": attempt_id,
              "status": "RUNNING", "source_manifest_sha256": own_identity,
              "preflight_source_manifest_sha256": STAGE1_MANIFEST,
              "input_contract_sha256": digest(contract_path), "approval_sha256": approval_hash,
              "unchanged_course_requirements_sha256": digest(requirements), "commands": [],
              "model_downloads_performed": False, "model_weights_loaded": False,
              "generation_performed": False, "judging_performed": False, "training_performed": False}

    def command(argv, name, display=True, check=True):
        event = {"stage": name, "argv": [str(x) for x in argv]}
        report["commands"].append(event)
        immutable_json(attempt / (name + "_command.json"), event)
        print("CPU stage:", name, flush=True)
        with (attempt / (name + ".log")).open("x", encoding="utf-8") as log:
            process = subprocess.Popen([str(x) for x in argv], stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in process.stdout:
                log.write(line)
                log.flush()
                if display:
                    print(line, end="", flush=True)
            event["returncode"] = process.wait()
        event["log_sha256"] = digest(attempt / (name + ".log"))
        immutable_json(attempt / (name + "_result.json"), event)
        if check and event["returncode"] != 0:
            if not display:
                print((attempt / (name + ".log")).read_text(), flush=True)
            raise RuntimeError(name + " failed; its complete log was preserved")
        return event["returncode"]

    try:
        immutable_json(attempt / "START.json", report)
        command([sys.executable, "-m", "pip", "freeze", "--all"], "packages_before", display=False)
        command([sys.executable, "-m", "pip", "install", "--quiet", "--disable-pip-version-check",
                 "--report", attempt / "pip_install_report.json", "-r", requirements], "install_course_requirements")
        command([sys.executable, "-m", "pip", "freeze", "--all"], "packages_after", display=False)
        command([sys.executable, "-u", release / "course_reference/scripts/check_environment.py"],
                "original_course_environment_check")
        probe_path = attempt / "fresh_process_probe.py"
        immutable_bytes(probe_path, PROBE.encode())
        command([sys.executable, "-u", probe_path, release, contract_path, attempt / "probe_results.json"],
                "fresh_process_validation_and_audit_ids")
        command([sys.executable, "-m", "pip", "check"], "dependency_check")
        result = json.loads((attempt / "probe_results.json").read_text())
        audit = result.pop("audit")
        immutable_json(EXPERIMENT / "AUDIT_ID_CONTRACT.json", audit)
        environment = {"format": "ATML_TASK4_CPU_ENVIRONMENT_V1", **result,
                       "course_requirements_sha256": digest(requirements),
                       "approval_sha256": approval_hash, "dependency_check_passed": True}
        immutable_json(EXPERIMENT / "CPU_ENVIRONMENT_CONTRACT.json", environment)
        report.update({"status": "CPU_ENVIRONMENT_AND_AUDIT_IDS_VERIFIED",
                       "environment_contract_sha256": digest(EXPERIMENT / "CPU_ENVIRONMENT_CONTRACT.json"),
                       "audit_id_contract_sha256": digest(EXPERIMENT / "AUDIT_ID_CONTRACT.json"),
                       "resolved_course_package_versions": result["course_package_versions"],
                       "audit_prompt_ids": audit["ordered_audit_prompt_ids"],
                       "audit_class_counts": audit["class_counts"],
                       "complete_model_preparation_pending": True})
    except BaseException as error:
        report["status"] = "FAILED_PRESERVED"
        report["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        report["artifact_sha256"] = {path.name: digest(path) for path in attempt.iterdir() if path.is_file()}
        immutable_json(attempt / "REPORT.json", report)
        print("Saved environment report:", attempt / "REPORT.json", flush=True)
        print("Status:", report["status"], flush=True)
    print("CPU environment verified; course audit IDs frozen: 60/60.", flush=True)
    print("Task 4 remaining: generation 1800; judging 1800; blind human labels 240.", flush=True)
    print("Model files and inference pipeline still need preparation; remain on CPU.", flush=True)


if __name__ == "__main__":
    main()
