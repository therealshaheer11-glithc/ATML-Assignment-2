import copy
import unittest
from packaging.tags import Tag
from planning import restoration_plan, select_wheel, torch_candidates

TAGS = [Tag('cp313', 'cp313', 'manylinux_2_28_x86_64'), Tag('py3', 'none', 'any')]
SHA = 'a' * 64


def wheel(filename='demo-1.0-py3-none-any.whl'):
    return {'filename': filename, 'url': 'https://files.pythonhosted.org/' + filename,
            'size': 100, 'digests': {'sha256': SHA}, 'packagetype': 'bdist_wheel',
            'yanked': False, 'requires_python': '>=3.9'}


class PlanningGuards(unittest.TestCase):
    def test_exact_version_and_name_required(self):
        value = select_wheel('demo', '1.0', [wheel('other-1.0-py3-none-any.whl'),
                             wheel('demo-2.0-py3-none-any.whl'), wheel()], TAGS, '3.13.16')
        self.assertEqual(value['version'], '1.0')

    def test_specific_compatible_tag_preferred(self):
        native = wheel('demo-1.0-cp313-cp313-manylinux_2_28_x86_64.whl')
        value = select_wheel('demo', '1.0', [wheel(), native], TAGS, '3.13.16')
        self.assertEqual(value['filename'], native['filename'])

    def test_yanked_sdist_wrong_abi_and_python_bound_rejected(self):
        cases = [dict(wheel(), yanked=True), dict(wheel(), packagetype='sdist'),
                 wheel('demo-1.0-cp312-cp312-manylinux_2_28_x86_64.whl'),
                 dict(wheel(), requires_python='<3.13')]
        for item in cases:
            with self.subTest(item=item), self.assertRaises(RuntimeError):
                select_wheel('demo', '1.0', [item], TAGS, '3.13.16')

    def test_missing_hash_and_unexpected_host_rejected(self):
        for item in [dict(wheel(), digests={}), dict(wheel(), url='https://example.org/demo.whl')]:
            with self.assertRaises(RuntimeError):
                select_wheel('demo', '1.0', [item], TAGS, '3.13.16')

    def test_torch_preserves_exact_cuda_build(self):
        filename = 'torch-2.11.0%2Bcu130-cp313-cp313-manylinux_2_28_x86_64.whl'
        html = '<a href="https://download.pytorch.org/whl/cu130/' + filename + '#sha256=' + SHA + '">wheel</a>'
        value = torch_candidates(html, 'https://download.pytorch.org/whl/cu130/torch/', '2.11.0+cu130', TAGS)
        self.assertEqual(value['sha256'], SHA)
        with self.assertRaises(RuntimeError):
            torch_candidates(html, 'https://download.pytorch.org/whl/cu130/torch/', '2.11.0+cpu', TAGS)

    def test_torch_without_published_identity_rejected(self):
        html = '<a href="torch-2.11.0%2Bcu130-cp313-cp313-manylinux_2_28_x86_64.whl">wheel</a>'
        with self.assertRaises(RuntimeError):
            torch_candidates(html, 'https://download.pytorch.org/whl/cu130/torch/', '2.11.0+cu130', TAGS)

    def inventories(self):
        before = {'torch': '2.11.0+cu130', 'huggingface-hub': '1.33.0', 'transformers': '5.18.0',
                  'tokenizers': '0.23.2', 'peft': '0.21.1'}
        after = {**before, 'huggingface-hub': '0.36.2', 'transformers': '4.57.1',
                 'tokenizers': '0.22.1', 'peft': '0.17.1', 'trl': '0.27.2', 'bitsandbytes': '0.50.2'}
        changes = {name: {'before': before.get(name), 'after': after.get(name)}
                   for name in set(before) | set(after) if before.get(name) != after.get(name)}
        return before, after, changes

    def test_restoration_is_limited_to_exact_recorded_global_changes(self):
        plan = restoration_plan(*self.inventories())
        self.assertEqual(len(plan['restore_original_versions_if_still_modified']), 4)
        self.assertEqual(plan['remove_only_course_added_global_packages_after_isolated_environment_passes'], ['bitsandbytes', 'trl'])

    def test_unrecorded_change_or_torch_substitution_is_rejected(self):
        before, after, changes = self.inventories()
        for altered in [dict(after, unrelated='2.0'), dict(after, torch='2.11.0+cpu')]:
            with self.assertRaises(RuntimeError):
                restoration_plan(before, altered, changes)


if __name__ == '__main__':
    unittest.main(verbosity=2)
