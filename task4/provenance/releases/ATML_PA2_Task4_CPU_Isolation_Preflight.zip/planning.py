"""Read-only wheel selection and explicit restoration-plan guards."""
from html.parser import HTMLParser
import re
from urllib.parse import parse_qs, unquote, urljoin, urlparse

from packaging.specifiers import SpecifierSet
from packaging.utils import canonicalize_name, parse_wheel_filename
from packaging.version import Version


def require(value, message):
    if not value:
        raise RuntimeError(message)


def select_wheel(name, version, files, tag_order, python_version):
    ranks = {tag: index for index, tag in enumerate(tag_order)}
    candidates = []
    for item in files:
        if item.get('packagetype') != 'bdist_wheel' or item.get('yanked'):
            continue
        try:
            actual_name, actual_version, _, tags = parse_wheel_filename(item['filename'])
        except (ValueError, KeyError):
            continue
        if canonicalize_name(actual_name) != canonicalize_name(name) or actual_version != Version(version):
            continue
        rank = min((ranks[tag] for tag in tags if tag in ranks), default=None)
        if rank is None:
            continue
        bound = item.get('requires_python')
        if bound and not SpecifierSet(bound).contains(python_version, prereleases=False):
            continue
        sha256 = item.get('digests', {}).get('sha256', '')
        require(bool(re.fullmatch('[0-9a-f]{64}', sha256)), 'Missing published wheel SHA-256: ' + item['filename'])
        require(isinstance(item.get('size'), int) and item['size'] > 0, 'Missing wheel size')
        parsed = urlparse(item['url'])
        require(parsed.scheme == 'https' and parsed.hostname in
                {'files.pythonhosted.org', 'download.pytorch.org', 'download-r2.pytorch.org'},
                'Unexpected wheel publisher host')
        candidates.append((rank, item['filename'], item))
    require(bool(candidates), 'No compatible published binary wheel for ' + name + '==' + version)
    item = min(candidates, key=lambda value: value[:2])[2]
    return {'package': canonicalize_name(name), 'version': version, 'filename': item['filename'],
            'url': item['url'], 'sha256': item['digests']['sha256'], 'bytes': item['size'],
            'requires_python': item.get('requires_python'),
            'core_metadata_identity': item.get('core-metadata', item.get('dist-info-metadata'))}


class TorchLinks(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attributes):
        if tag == 'a':
            value = dict(attributes)
            if value.get('href'):
                self.links.append(value)


def torch_candidates(html, base_url, version, tag_order):
    parser = TorchLinks()
    parser.feed(html)
    compatible = []
    ranks = {tag: index for index, tag in enumerate(tag_order)}
    for attributes in parser.links:
        full = urljoin(base_url, attributes['href'])
        parsed = urlparse(full)
        filename = unquote(parsed.path.rsplit('/', 1)[-1])
        try:
            name, candidate_version, _, tags = parse_wheel_filename(filename)
        except ValueError:
            continue
        rank = min((ranks[tag] for tag in tags if tag in ranks), default=None)
        if name != 'torch' or candidate_version != Version(version) or rank is None:
            continue
        require(parsed.scheme == 'https' and parsed.hostname in {'download.pytorch.org', 'download-r2.pytorch.org'},
                'Unexpected Torch wheel publisher')
        hashes = parse_qs(parsed.fragment).get('sha256', [])
        require(len(hashes) == 1 and re.fullmatch('[0-9a-f]{64}', hashes[0]), 'Missing published Torch wheel SHA-256')
        compatible.append((rank, filename, {'filename': filename, 'url': full.split('#', 1)[0],
            'sha256': hashes[0], 'metadata_identity': attributes.get('data-core-metadata',
                                                    attributes.get('data-dist-info-metadata'))}))
    require(bool(compatible), 'No exact CUDA Torch wheel matches the saved GPU version and CPU planning tags')
    return min(compatible, key=lambda value: value[:2])[2]


def restoration_plan(before, after, changes):
    before = {canonicalize_name(name): version for name, version in before.items()}
    after = {canonicalize_name(name): version for name, version in after.items()}
    actual = {name: {'before': before.get(name), 'after': after.get(name)}
              for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)}
    require(actual == changes, 'Recorded package changes do not match before/after inventories')
    restore = {name: value['before'] for name, value in actual.items() if value['before'] is not None}
    added = sorted(name for name, value in actual.items() if value['before'] is None)
    require(set(restore) == {'huggingface-hub', 'transformers', 'tokenizers', 'peft'} and
            set(added) == {'trl', 'bitsandbytes'}, 'Unexpected global package changes require review')
    require(before.get('torch') == after.get('torch') == '2.11.0+cu130', 'Saved GPU Torch identity differs')
    return {'restore_original_versions_if_still_modified': restore,
            'remove_only_course_added_global_packages_after_isolated_environment_passes': added,
            'fresh_base_already_matching_original_inventory_requires_no_restoration': True,
            'unexpected_inventory_drift_requires_review': True}
