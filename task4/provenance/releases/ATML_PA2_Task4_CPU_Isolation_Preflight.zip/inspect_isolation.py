"""CPU-only planning: saved GPU identities and public metadata; no installation."""
from datetime import datetime, timezone
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import platform
import sys
from urllib.parse import quote, urlparse
from urllib.request import Request, urlopen

from packaging.markers import default_environment
from packaging.requirements import Requirement
from packaging.tags import sys_tags
from packaging.utils import canonicalize_name
from packaging.version import Version

from planning import require, restoration_plan, select_wheel, torch_candidates

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
EXPERIMENT = Path('/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1')
STAGE1 = '9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65'
GPU_SOURCE = 'd941ecb6c16ec91a942b319167826007f5124b0dedc10d2a337b3b783ff4015b'
DIAGNOSTIC = '71bdb7fdbe130c5adaef8328437371bcd89621d0a93e849bab61b7db8491c540'
GPU_ATTEMPT = '20261011T142511.766769Z'
TORCH_INDEX = 'https://download.pytorch.org/whl/cu130/torch/'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def inventory():
    return {canonicalize_name(item.metadata['Name']): item.version for item in metadata.distributions()
            if item.metadata.get('Name')}


def main():
    stage1 = EXPERIMENT / 'preflight_releases' / STAGE1
    require(digest(stage1 / 'MANIFEST.json') == STAGE1, 'Preflight source differs')
    manifest = read(stage1 / 'MANIFEST.json')
    require(digest(stage1 / 'scripts/preflight.py') == manifest['scripts/preflight.py'], 'Preflight helper differs')
    spec = importlib.util.spec_from_file_location('task4_isolation_preflight', stage1 / 'scripts/preflight.py')
    preflight = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(preflight)
    preflight.verify_source(stage1)
    preflight.require_cpu()
    source = preflight.verify_source(ROOT)
    approval = digest(stage1 / 'docs/approval.json')
    require(read(EXPERIMENT / 'OWNER.json')['approval_sha256'] == approval, 'Task ownership differs')
    save, save_bytes = preflight.immutable_json, preflight.immutable_bytes
    release = EXPERIMENT / 'isolation_preflight_releases' / source['manifest_sha256']
    for name in [*read(ROOT / 'MANIFEST.json'), 'MANIFEST.json']:
        save_bytes(release / name, (ROOT / name).read_bytes())
    attempt_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    attempt = EXPERIMENT / 'isolation_preflight_attempts' / attempt_id
    attempt.mkdir(parents=True, exist_ok=False)
    report = {'format': 'ATML_TASK4_ISOLATION_PREFLIGHT_ATTEMPT_V1', 'status': 'RUNNING',
              'attempt_utc': attempt_id, 'source_manifest_sha256': source['manifest_sha256'],
              'authorization': 'sure, following proposal to review an isolated setup before changing packages',
              'package_changes_performed': False, 'virtual_environment_created': False,
              'wheel_files_downloaded': 0, 'model_downloads_performed': False,
              'pretrained_models_loaded': 0, 'task4_responses_generated': 0,
              'task4_judgments_produced': 0, 'human_labels_assigned': 0,
              'gpu_exceptions_accepted': [], 'implementation_approval_pending': True}
    requests = []
    responses = {}

    def fetch(url, label, head=False):
        key = ('HEAD' if head else 'GET', url)
        if key in responses:
            return responses[key]
        allowed = {'pypi.org', 'files.pythonhosted.org', 'download.pytorch.org', 'download-r2.pytorch.org'}
        require(urlparse(url).scheme == 'https' and urlparse(url).hostname in allowed,
                'Unexpected public metadata URL')
        record = {'method': key[0], 'url': url, 'label': label}
        requests.append(record)
        try:
            request = Request(url, method=key[0], headers={'User-Agent': 'ATML-PA2-Task4-Isolation-Preflight'})
            with urlopen(request, timeout=30) as response:
                require(urlparse(response.url).hostname in allowed, 'Unexpected metadata redirect host')
                record.update({'status': response.status, 'final_url': response.url,
                               'content_type': response.headers.get('Content-Type')})
                if head:
                    length = response.headers.get('Content-Length')
                    require(length is not None and length.isdigit() and int(length) > 0,
                            'Publisher HEAD response has no reliable wheel size')
                    value = int(length)
                    record['content_length'] = value
                    record['body_bytes_read'] = 0
                else:
                    value = response.read(8 * 1024 * 1024 + 1)
                    require(len(value) <= 8 * 1024 * 1024, 'Metadata exceeds size limit')
                    filename = 'PUBLIC_METADATA_' + str(len(requests)).zfill(4) + '.bin'
                    save_bytes(attempt / filename, value)
                    record.update({'saved_metadata': filename, 'sha256': hashlib.sha256(value).hexdigest(),
                                   'body_bytes_read': len(value)})
            responses[key] = value
            return value
        except BaseException as error:
            record['error'] = {'type': type(error).__name__, 'message': str(error)}
            raise

    def pypi(name, version=None):
        url = 'https://pypi.org/pypi/' + quote(canonicalize_name(name), safe='') + '/'
        if version is not None:
            url += quote(version, safe='') + '/'
        data = json.loads(fetch(url + 'json', name + ' package metadata'))
        require(canonicalize_name(data['info']['name']) == canonicalize_name(name), 'PyPI name differs')
        if version is not None:
            require(Version(data['info']['version']) == Version(version), 'PyPI version differs')
        return data

    try:
        save(attempt / 'START.json', report)
        current_inventory = inventory()
        save(attempt / 'CURRENT_CPU_PACKAGE_VERSIONS.json', current_inventory)
        for folder, identity in [(EXPERIMENT / 'gpu_environment_releases' / GPU_SOURCE, GPU_SOURCE),
                                 (EXPERIMENT / 'diagnostic_releases' / DIAGNOSTIC, DIAGNOSTIC)]:
            require(digest(folder / 'MANIFEST.json') == identity, 'Referenced source identity differs')
            preflight.verify_source(folder)
        previous_folder = EXPERIMENT / 'gpu_environment_attempts' / GPU_ATTEMPT
        previous = read(previous_folder / 'REPORT.json')
        require(previous['source_manifest_sha256'] == GPU_SOURCE and
                previous['status'] == 'GPU_ENVIRONMENT_REVIEW_REQUIRED' and
                previous['synthetic_checks_passed'] == 37 and previous['gpu_exceptions_accepted'] == [],
                'Saved GPU result differs from returned evidence')
        for name, expected in previous['artifact_sha256'].items():
            require(Path(name).name == name and name not in {'.', '..'}, 'Unsafe GPU artifact path')
            require(digest(previous_folder / name) == expected, 'Saved GPU evidence changed: ' + name)
        require(digest(EXPERIMENT / 'CPU_ORCHESTRATION_VALIDATION_CONTRACT.json') ==
                previous['cpu_orchestration_contract_sha256'], 'CPU protocol changed')
        cpu = read(EXPERIMENT / 'CPU_ORCHESTRATION_VALIDATION_CONTRACT.json')
        require(digest(EXPERIMENT / 'CPU_MODEL_INPUT_CONTRACT.json') == cpu['model_input_contract_sha256'],
                'Frozen model-input identity changed')
        probe = read(previous_folder / 'GPU_PROBE.json')
        graph = read(previous_folder / 'GPU_REQUIRED_DEPENDENCY_CHAIN.json')
        target = graph['marker_environment']
        now = default_environment()
        for key in ['implementation_name', 'python_version', 'platform_machine', 'platform_system']:
            require(now[key] == target[key], 'CPU planning platform differs from saved A100 platform: ' + key)
        require(target['platform_system'] == 'Linux' and target['platform_machine'] == 'x86_64',
                'Unexpected saved GPU platform')
        tags = list(sys_tags())
        save(attempt / 'CPU_PLANNING_PLATFORM.json', {'python': platform.python_version(),
             'marker_environment': now, 'compatible_tags': [str(tag) for tag in tags],
             'saved_gpu_marker_environment': target,
             'fresh_a100_wheel_tag_validation_still_required': True})
        require(graph['required_chain_passed'] and not graph['issues'] and probe['required_dependency_chain_passed'] and
                probe['synthetic_semantic_checks_passed'] == 37 and probe['cuda_available'] and
                probe['tiny_float16_cuda_check_passed'] and probe['tiny_nf4_cuda_backend_check_passed'],
                'Saved A100 technical checks are incomplete')
        spec = importlib.util.spec_from_file_location('task4_isolation_dependencies',
            EXPERIMENT / 'diagnostic_releases' / DIAGNOSTIC / 'dependencies.py')
        dependencies = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(dependencies)
        fields = ['name', 'version', 'requires_dist', 'provides_extra', 'requires_python']
        lookup = lambda name: {key: graph['nodes'][name].get(key) for key in fields} if name in graph['nodes'] else None
        rechecked = dependencies.inspect_chain((stage1 / 'course_reference/requirements.txt').read_text().splitlines(),
                                              lookup, target)
        require(rechecked['required_chain_passed'] and not rechecked['issues'], 'Saved required graph fails recomputation')
        save(attempt / 'RECOMPUTED_GPU_DEPENDENCY_CHAIN.json', rechecked)
        versions = {name: node['version'] for name, node in graph['nodes'].items()}
        require(versions == probe['all_required_package_versions'], 'Saved GPU versions and graph disagree')
        membership = {name: name in graph['nodes'] for name in ['ipython', 'diffusers', 'gradio', 'jedi']}
        save(attempt / 'CONFLICT_PACKAGE_MEMBERSHIP.json', membership)
        require(not any(membership.values()), 'A disputed package is in the actual required GPU chain')
        before = read(previous_folder / 'PACKAGE_VERSIONS_BEFORE.json')
        after = read(previous_folder / 'PACKAGE_VERSIONS_AFTER.json')
        changes = read(previous_folder / 'PACKAGE_CHANGES.json')
        restore = restoration_plan(before, after, changes)
        before = {canonicalize_name(name): value for name, value in before.items()}
        restore['preserve_colab_tools'] = {name: before[name] for name in ['ipython', 'diffusers', 'gradio']}
        gpu_versions = {**versions, 'pip': before['pip']}
        pins = '\n'.join(name + '==' + version for name, version in sorted(gpu_versions.items())) + '\n'
        save_bytes(attempt / 'PROPOSED_TASK4_PACKAGE_PINS.txt', pins.encode())
        wheel_records, blockers = {}, []

        def inspect(name, version):
            key = (canonicalize_name(name), version)
            if key in wheel_records:
                return wheel_records[key]
            if canonicalize_name(name) == 'torch':
                require(version == '2.11.0+cu130', 'A different Torch build would require a new decision')
                candidate = torch_candidates(fetch(TORCH_INDEX, 'official CUDA 13.0 Torch index').decode(),
                                             TORCH_INDEX, version, tags)
                size = fetch(candidate['url'], 'Torch wheel size headers only', head=True)
                result = {'package': 'torch', 'version': version, 'filename': candidate['filename'],
                    'url': candidate['url'], 'sha256': candidate['sha256'], 'bytes': size,
                    'publisher': 'Official PyTorch CUDA 13.0 wheel index',
                    'core_metadata_identity': candidate['metadata_identity']}
            else:
                data = pypi(name, version)
                result = select_wheel(name, version, data['urls'], tags, target['python_full_version'])
                result['publisher'] = 'PyPI release metadata'
            wheel_records[key] = result
            return result

        total = len(gpu_versions)
        for index, (name, version) in enumerate(sorted(gpu_versions.items()), 1):
            print('Metadata', str(index) + '/' + str(total) + ':', name + '==' + version, flush=True)
            try:
                inspect(name, version)
            except Exception as error:
                blockers.append({'package': name, 'version': version, 'reason': str(error)})
                print('  Needs review:', str(error), flush=True)
        for name, version in sorted(restore['restore_original_versions_if_still_modified'].items()):
            print('Original Colab package metadata:', name + '==' + version, flush=True)
            try:
                inspect(name, version)
            except Exception as error:
                blockers.append({'package': name, 'version': version, 'reason': str(error)})

        # Jedi is a proposal for repairing Colab, never an installation/default
        # inside the course environment. Its concrete version is reviewed later.
        ipython = pypi('ipython', before['ipython'])
        jedi_bounds = [Requirement(raw) for raw in ipython['info'].get('requires_dist') or []
                       if canonicalize_name(Requirement(raw).name) == 'jedi']
        require(len(jedi_bounds) == 1, 'Unexpected IPython/Jedi declared requirement')
        jedi = pypi('jedi')
        jedi_version = jedi['info']['version']
        require(not Version(jedi_version).is_prerelease and not Version(jedi_version).is_devrelease and
                jedi_bounds[0].specifier.contains(jedi_version, prereleases=False),
                'Latest published Jedi candidate does not satisfy saved IPython bounds')
        repairs = {'jedi': jedi_version}
        inspect('jedi', jedi_version)
        repair_dependencies = {}
        for raw in jedi['info'].get('requires_dist') or []:
            requirement = Requirement(raw)
            if requirement.marker is not None and not requirement.marker.evaluate({**target, 'extra': ''}):
                continue
            require(not requirement.url and not requirement.extras, 'Unexpected Jedi dependency shape requires review')
            name = canonicalize_name(requirement.name)
            require(name == 'parso', 'A new Jedi dependency needs a separate review: ' + name)
            version = before.get(name)
            if version is None or not requirement.specifier.contains(version, prereleases=False):
                version = pypi(name)['info']['version']
                require(not Version(version).is_prerelease and requirement.specifier.contains(version, prereleases=False),
                        'No latest stable Jedi-dependency candidate satisfies the declared bounds')
                repairs[name] = version
            inspect(name, version)
            repair_dependencies[name] = {'requirement': raw, 'original_version': before.get(name),
                                         'proposed_version': version}
        restore.update({'jedi_declared_requirement': str(jedi_bounds[0]),
            'proposed_jedi_candidate_selection': 'Latest published stable candidate satisfying the original IPython bound; approval and actual import/completion checks still required',
            'proposed_add_or_change_base_packages': repairs, 'jedi_dependencies': repair_dependencies,
            'full_base_dependency_check_and_fresh_imports_still_required': True})
        unique = {}
        for record in wheel_records.values():
            old = unique.get(record['filename'])
            require(old is None or old['sha256'] == record['sha256'], 'Wheel filename identity collision')
            unique[record['filename']] = record
        total_bytes = sum(record['bytes'] for record in unique.values())
        plan = {'format': 'ATML_TASK4_ISOLATION_PROPOSAL_V1', 'approval_pending': True,
            'source_manifest_sha256': source['manifest_sha256'],
            'original_gpu_report_sha256': digest(previous_folder / 'REPORT.json'),
            'cpu_orchestration_contract_sha256': digest(EXPERIMENT / 'CPU_ORCHESTRATION_VALIDATION_CONTRACT.json'),
            'original_gpu_python': probe['python'], 'original_gpu_required_distributions': len(versions),
            'isolated_package_versions': gpu_versions, 'course_pins_changed': False,
            'gpu_torch_build_preserved': versions['torch'], 'colab_base_repair_proposal': restore,
            'conflict_packages_in_actual_task4_chain': membership,
            'proposed_wheels': [unique[name] for name in sorted(unique)],
            'binary_wheel_only': True, 'source_builds_proposed': False, 'blockers': blockers,
            'known_unique_wheel_count': len(unique), 'known_compressed_download_bytes': total_bytes,
            'known_compressed_download_gib': total_bytes / (1024 ** 3),
            'download_total_complete': not blockers,
            'uncompressed_installed_size_bytes': None,
            'installed_size_note': 'Not measured. The approved CPU download stage must inspect ZIP entry sizes before A100 installation.',
            'timing_estimate': 'Not measured; network and Drive throughput determine download/install time.',
            'proposed_wheelhouse': str(EXPERIMENT / 'environment_wheelhouse'),
            'proposed_local_a100_environment': '/content/task4_isolated_runtime_v1',
            'proposed_environment_isolated_from_system_site_packages': True,
            'proposed_execution': 'Colab launcher stays in the base kernel; Task 4 scripts use the isolated environment Python executable.',
            'planned_stages': ['Review and approve exact package repair, binary artifacts and Drive storage.',
                'CPU: download only approved package wheels to a checksummed Drive wheelhouse; inspect actual wheel METADATA, complete dependency closure and uncompressed sizes.',
                'A100: create the isolated environment on local runtime disk and install from verified offline wheels; validate full dependency check, course imports, CUDA/NF4 and 37 synthetic checks.',
                'Restore only the recorded base-package changes if they are still present, remove only the course-added global copies after isolated validation, and install the approved Jedi repair; verify base global check and fresh tools.',
                'Restart notebook kernel if needed for repaired base imports; recheck both interpreters, then validate actual policy/judge loading.'],
            'new_model_or_evaluation_settings_selected': False, 'gpu_exceptions_accepted': [],
            'package_changes_performed': False, 'wheel_files_downloaded': 0,
            'virtual_environment_created': False, 'pretrained_models_loaded': 0}
        save(attempt / 'ISOLATION_PROPOSAL.json', plan)
        require(inventory() == current_inventory, 'CPU distribution inventory changed unexpectedly during read-only planning')
        report.update({'status': 'ISOLATION_PREFLIGHT_NEEDS_REVIEW' if blockers else 'ISOLATION_PREFLIGHT_READY_FOR_REVIEW',
            'gpu_required_distributions': len(versions), 'conflict_package_membership_checked': membership,
            'proposed_wheel_count': len(unique), 'known_compressed_download_bytes': total_bytes,
            'download_total_complete': not blockers, 'blockers': blockers,
            'proposal_sha256': digest(attempt / 'ISOLATION_PROPOSAL.json'),
            'current_cpu_package_versions_unchanged': True})
        print('\nSaved GPU dependency chain:', len(versions), 'distributions; disputed packages are outside it.', flush=True)
        print('Proposed isolated Torch:', versions['torch'], flush=True)
        print('Proposed original Colab versions to restore only if needed:', json.dumps(restore['restore_original_versions_if_still_modified']), flush=True)
        print('Proposed Jedi repair:', json.dumps(repairs), flush=True)
        print('Published compatible wheels:', len(unique), '; compressed total:', total_bytes, 'bytes /', round(total_bytes / 1024**3, 3), 'GiB.', flush=True)
        print('Download-size total complete:', not blockers, '; unresolved artifacts:', len(blockers), flush=True)
        print('Uncompressed installation size and elapsed installation time are not measured.', flush=True)
        print('This is a proposal only: no package install, environment creation, wheel download or model loading occurred.', flush=True)
        print('Remain on CPU. Return this output for review before approving downloads or package changes.', flush=True)
    except BaseException as error:
        report['status'] = 'ISOLATION_PREFLIGHT_FAILED_PRESERVED'
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        save(attempt / 'PUBLIC_METADATA_REQUESTS.json', requests)
        report['artifact_sha256'] = {path.name: digest(path) for path in attempt.iterdir() if path.is_file()}
        save(attempt / 'REPORT.json', report)
        print('Saved isolation preflight report:', attempt / 'REPORT.json', flush=True)
        print('Status:', report['status'], flush=True)


if __name__ == '__main__':
    main()
