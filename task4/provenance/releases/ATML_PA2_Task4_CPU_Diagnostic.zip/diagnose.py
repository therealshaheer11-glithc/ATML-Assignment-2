"""Read-only Block 2 diagnosis. Only new diagnostic evidence is written to Drive."""
from datetime import datetime, timezone
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path, PurePosixPath
import platform
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
EXPERIMENT = Path("/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1")
STAGE1 = "9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65"
STAGE2 = "5767d9553b4b4c32f6470cbd59cc7afa4ae6cc56be838b9be8f0f85ce0f47ff1"
FAILED_ATTEMPT = "20261011T105114.911388Z"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def verify(folder, expected=None):
    path = folder / "MANIFEST.json"
    if expected is not None and digest(path) != expected:
        raise RuntimeError("Manifest identity differs: " + str(folder))
    manifest = read_json(path)
    for name, expected_digest in manifest.items():
        relative = PurePosixPath(name)
        assert not relative.is_absolute() and ".." not in relative.parts
        path = folder / name
        assert path.is_file() and not path.is_symlink() and digest(path) == expected_digest, name
    return manifest


def lookup(name):
    try:
        distribution = metadata.distribution(name)
    except metadata.PackageNotFoundError:
        return None
    return {"name": distribution.metadata["Name"], "version": distribution.version,
            "requires_dist": distribution.requires or [],
            "provides_extra": distribution.metadata.get_all("Provides-Extra", []),
            "requires_python": distribution.metadata.get("Requires-Python")}


def freeze_versions(path):
    from packaging.requirements import Requirement
    from packaging.utils import canonicalize_name
    result = {}
    for raw in path.read_text().splitlines():
        if not raw.strip() or raw.startswith(("#", "-")):
            continue
        try:
            requirement = Requirement(raw)
            result[canonicalize_name(requirement.name)] = str(requirement.specifier) or requirement.url
        except Exception:
            continue
    return result


def main():
    stage1 = EXPERIMENT / "preflight_releases" / STAGE1
    stage2 = EXPERIMENT / "environment_releases" / STAGE2
    verify(stage1, STAGE1)
    verify(stage2, STAGE2)
    own_manifest = verify(ROOT)
    spec = importlib.util.spec_from_file_location("task4_preflight", stage1 / "scripts/preflight.py")
    preflight = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(preflight)
    preflight.require_cpu()
    immutable_json, immutable_bytes = preflight.immutable_json, preflight.immutable_bytes
    source_identity = digest(ROOT / "MANIFEST.json")
    preserved_source = EXPERIMENT / "diagnostic_releases" / source_identity
    for name in [*own_manifest, "MANIFEST.json"]:
        immutable_bytes(preserved_source / name, (ROOT / name).read_bytes())
    attempt_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    attempt = EXPERIMENT / "diagnostic_attempts" / attempt_id
    attempt.mkdir(parents=True, exist_ok=False)
    report = {"format": "ATML_TASK4_ENVIRONMENT_DIAGNOSIS_V1", "status": "RUNNING",
              "attempt_utc": attempt_id, "source_manifest_sha256": source_identity,
              "authorization": "sure check what went wrong", "commands": [],
              "package_changes_performed": False, "model_downloads_performed": False,
              "generation_performed": False, "judging_performed": False,
              "training_performed": False, "environment_contract_finalized": False}

    def command(argv, name, display=False):
        event = {"stage": name, "argv": [str(x) for x in argv]}
        print("Diagnostic stage:", name, flush=True)
        immutable_json(attempt / (name + "_command.json"), event)
        with (attempt / (name + ".log")).open("x") as log:
            process = subprocess.Popen(event["argv"], stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in process.stdout:
                log.write(line)
                log.flush()
                if display:
                    print(line, end="", flush=True)
            event["returncode"] = process.wait()
        event["log_sha256"] = digest(attempt / (name + ".log"))
        immutable_json(attempt / (name + "_result.json"), event)
        report["commands"].append(event)
        return event["returncode"]

    try:
        immutable_json(attempt / "START.json", report)
        failed = EXPERIMENT / "environment_attempts" / FAILED_ATTEMPT
        previous = read_json(failed / "REPORT.json")
        assert previous["status"] == "FAILED_PRESERVED"
        assert previous["source_manifest_sha256"] == STAGE2
        assert previous["preflight_source_manifest_sha256"] == STAGE1
        for name, expected in previous["artifact_sha256"].items():
            relative = PurePosixPath(name)
            assert not relative.is_absolute() and ".." not in relative.parts
            assert digest(failed / name) == expected, name
        assert digest(EXPERIMENT / "INPUT_IDENTITY_CONTRACT.json") == previous["input_contract_sha256"]
        assert digest(stage1 / "docs/approval.json") == previous["approval_sha256"]
        assert read_json(EXPERIMENT / "OWNER.json")["approval_sha256"] == previous["approval_sha256"]
        assert digest(stage1 / "course_reference/requirements.txt") == previous["unchanged_course_requirements_sha256"]
        report["failed_report_sha256"] = digest(failed / "REPORT.json")
        report["failed_attempt_artifacts_verified"] = True

        from dependencies import inspect_chain
        from packaging.requirements import Requirement
        from packaging.utils import canonicalize_name
        requirements = (stage1 / "course_reference/requirements.txt").read_text().splitlines()
        graph = inspect_chain(requirements, lookup)
        immutable_json(attempt / "required_dependency_chain.json", graph)
        current_metadata = sorted([lookup(item.metadata["Name"]) for item in metadata.distributions()
                                   if item.metadata.get("Name")], key=lambda x: x["name"].lower())
        immutable_json(attempt / "installed_distribution_metadata.json", current_metadata)
        assert command([sys.executable, "-m", "pip", "freeze", "--all"], "current_packages") == 0
        global_returncode = command([sys.executable, "-m", "pip", "check"], "current_global_pip_check", True)
        old_lines = sorted(x.strip() for x in (failed / "dependency_check.log").read_text().splitlines() if x.strip())
        new_lines = sorted(x.strip() for x in (attempt / "current_global_pip_check.log").read_text().splitlines() if x.strip())
        before = freeze_versions(failed / "packages_before.log")
        after = freeze_versions(failed / "packages_after.log")
        now = freeze_versions(attempt / "current_packages.log")
        targets = ["transformers", "huggingface-hub", "diffusers", "gradio", "ipython", "jedi"]
        membership, provenance = {}, {}
        for name in targets:
            node = graph["nodes"].get(name)
            membership[name] = {"in_required_chain": node is not None,
                                "path": node["first_path"] if node else None}
            provenance[name] = {"before": before.get(name), "after": after.get(name),
                                "now": now.get(name), "current_metadata": lookup(name)}
        immutable_json(attempt / "conflict_package_provenance.json", provenance)
        hub = lookup("huggingface-hub")
        hub_constraints = {}
        for name in ["transformers", "diffusers", "gradio"]:
            installed = lookup(name)
            hub_constraints[name] = []
            for raw in (installed or {}).get("requires_dist", []):
                requirement = Requirement(raw)
                if canonicalize_name(requirement.name) == "huggingface-hub" and (
                        requirement.marker is None or requirement.marker.evaluate({"extra": ""})):
                    hub_constraints[name].append({"requirement": raw,
                        "installed_hub": hub["version"] if hub else None,
                        "satisfied": hub is not None and requirement.specifier.contains(
                            hub["version"], prereleases=True)})
        original_probe = read_json(failed / "probe_results.json")
        probe_destination = attempt / "current_probe_results.json"
        probe_returncode = command([sys.executable, "-B", "-u", failed / "fresh_process_probe.py",
                                    stage1, EXPERIMENT / "INPUT_IDENTITY_CONTRACT.json", probe_destination],
                                   "fresh_imports_and_audit_comparison", True)
        current_probe = read_json(probe_destination) if probe_returncode == 0 else None
        audit_match = current_probe is not None and current_probe["audit"] == original_probe["audit"]
        package_match = current_probe is not None and current_probe["course_package_versions"] == original_probe["course_package_versions"]
        outside = all(not membership[name]["in_required_chain"] for name in ["ipython", "gradio", "diffusers"])
        report.update({"python": platform.python_version(),
                       "required_distributions": len(graph["nodes"]),
                       "required_dependency_issues": graph["issues"],
                       "required_dependency_chain_passed": graph["required_chain_passed"],
                       "conflict_package_membership": membership,
                       "three_reported_packages_outside_required_chain": outside,
                       "global_pip_check_returncode": global_returncode,
                       "global_dependency_issues_unchanged": old_lines == new_lines,
                       "global_dependency_messages": new_lines,
                       "installed_packages_hub_constraints": hub_constraints,
                       "fresh_probe_passed": probe_returncode == 0,
                       "audit_contract_matches_original_probe": audit_match,
                       "course_versions_match_original_probe": package_match,
                       "final_root_contracts_present": {name: (EXPERIMENT / name).exists() for name in
                            ["AUDIT_ID_CONTRACT.json", "CPU_ENVIRONMENT_CONTRACT.json"]}})
        if graph["issues"]:
            report["status"] = "DIAGNOSIS_TASK_DEPENDENCY_CONFLICT"
        elif outside and old_lines == new_lines and probe_returncode == 0 and audit_match and package_match:
            report["status"] = "DIAGNOSIS_CONFLICTS_OUTSIDE_COURSE_CHAIN"
        else:
            report["status"] = "DIAGNOSIS_NEEDS_REVIEW"
        print("\nRequired Task 4 dependency chain:", "PASS" if graph["required_chain_passed"] else "FAIL",
              "—", len(graph["nodes"]), "distributions inspected", flush=True)
        for issue in graph["issues"]:
            print("Required-chain issue:", json.dumps(issue), flush=True)
        for name in targets:
            item = provenance[name]
            print(name + ":", json.dumps({"before": item["before"], "after": item["after"],
                  "now": item["now"], **membership[name]}), flush=True)
        print("Installed Hub requirements:", json.dumps(hub_constraints), flush=True)
        print("Same global dependency errors:", old_lines == new_lines, flush=True)
        print("Same saved audit selection:", audit_match, flush=True)
        print("Diagnosis only; no exceptions accepted and no final environment/audit contracts written.", flush=True)
        print("Remaining: generation 1800; judging 1800; human labels 240.", flush=True)
    except BaseException as error:
        report["status"] = "DIAGNOSTIC_FAILED_PRESERVED"
        report["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        report["artifact_sha256"] = {p.name: digest(p) for p in attempt.iterdir() if p.is_file()}
        immutable_json(attempt / "REPORT.json", report)
        print("Saved diagnostic report:", attempt / "REPORT.json", flush=True)
        print("Status:", report["status"], flush=True)


if __name__ == "__main__":
    main()
