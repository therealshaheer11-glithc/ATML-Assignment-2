# Task 4: Block 2 diagnostic

The user authorized diagnosis with: “sure check what went wrong”. This package inspects the existing Colab CPU runtime. It performs no installation, removal, version change, downloads, model construction, generation, judging or training. It does not accept dependency exceptions or finalize root environment/audit contracts. Only new diagnostic evidence is saved.

## What it checks

- Verifies the unchanged preflight and environment source manifests against their approved identities.
- Verifies the preserved failed attempt REPORT.json and all its checksummed artifacts, original requirements, approval, owner and input contract.
- Traverses the complete installed dependency chain of all course requirements. Checks every active requirement, shared constraints, requested extras, Python/platform markers and supported Python versions. Missing dependencies, unsatisfied constraints and unsupported direct-URL identity checks are reported as issues.
- Records full installed distribution metadata and identifies whether IPython, Gradio and Diffusers are in that chain, including the first path for any that are.
- Reads the preserved before/after package inventories and captures the current inventory. Reports Transformers, Hugging Face Hub, Diffusers, Gradio, IPython and Jedi versions across all three. Missing Jedi is only described as preexisting if the before inventory proves it.
- Re-runs global pip check and preserves its nonzero result without converting it into a pass. Reports whether the exact original messages remain unchanged. Prints the installed Transformers/Diffusers/Gradio Hub constraints from actual distribution metadata.
- Runs the preserved fresh-process import/audit probe with a new destination and verifies the full audit selection record and course package versions against the original saved probe. No models are constructed.

## Persistence and result boundaries

Source: MyDrive/ATML-Assignment-2/task4/experiment_v1/diagnostic_releases/<manifest SHA-256>.
Attempts: MyDrive/ATML-Assignment-2/task4/experiment_v1/diagnostic_attempts/<UTC timestamp>.

Each attempt stores exact commands, logs, before/after comparison, full dependency graph, metadata, fresh probe result, hashes and REPORT.json. Prior attempts and root contracts are read only. Existing failed reports are not rewritten.

DIAGNOSIS_CONFLICTS_OUTSIDE_COURSE_CHAIN means the installed course dependency chain passes, all three reported packages are outside it, global messages match the saved failure, and fresh imports/audit/package versions match. It is a diagnostic classification, not a whole-environment pass or permission to accept exceptions. DIAGNOSIS_TASK_DEPENDENCY_CONFLICT identifies issues in the required chain. DIAGNOSIS_NEEDS_REVIEW indicates other differences. Unexpected failure preserves DIAGNOSTIC_FAILED_PRESERVED with the error.

Actual Colab diagnosis remains pending until the user returns the output. Last verified experimental counts: inputs 4/4; generation 0/1,800; AI judging 0/1,800; human labels 0/240. Audit selection was computed for 60 prompts, but the final contract remains pending.

## Local validation

Eight synthetic semantic tests passed: missing transitive package; conflict from a second parent; platform exclusion; late extra activation; exclusion of unrequested extras/unrelated broken packages; normalized-name cycles; unprovided requested extras; incompatible Python bounds. These test the diagnostic logic, not the actual Colab installation. Python syntax, historical source hashes and archive integrity are also checked locally.

## References

Course requirements remain unmodified. Metadata evaluation uses the packaging library and follows its documented markers/extras behavior: https://packaging.pypa.io/en/stable/markers.html . Whole-environment dependency-check semantics: https://pip.pypa.io/en/stable/cli/pip_check/ . Pip implementation reference: https://github.com/pypa/pip/blob/main/src/pip/_internal/operations/check.py . New diagnostic orchestration was created with Codex assistance.
