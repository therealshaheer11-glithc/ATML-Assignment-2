import unittest
from dependencies import inspect_chain


def record(name, version="1.0", requires=(), extras=(), python=None):
    return {"name": name, "version": version, "requires_dist": list(requires),
            "provides_extra": list(extras), "requires_python": python}


class DependencySemantics(unittest.TestCase):
    def check(self, roots, records):
        return inspect_chain(roots, records.get, {
            "python_version": "3.13", "python_full_version": "3.13.16",
            "sys_platform": "linux", "os_name": "posix"})

    def test_missing_transitive_distribution(self):
        result = self.check(["a"], {"a": record("a", requires=["b"])})
        self.assertEqual(result["issues"][0]["kind"], "missing_distribution")
        self.assertEqual(result["nodes"]["b"]["first_path"], ["a", "b"])

    def test_conflicting_constraint_from_second_parent(self):
        result = self.check(["a", "b"], {
            "a": record("a", requires=["c<2"]), "b": record("b", requires=["c>=2"]),
            "c": record("c")})
        self.assertEqual(len(result["issues"]), 1)
        self.assertEqual(result["issues"][0]["parent"], "b")

    def test_inactive_platform_dependency_is_excluded(self):
        result = self.check(["a"], {"a": record("a", requires=['missing; sys_platform == "win32"'])})
        self.assertTrue(result["required_chain_passed"])
        self.assertNotIn("missing", result["nodes"])

    def test_extras_discovered_after_node_was_processed(self):
        result = self.check(["a", "z"], {
            "a": record("a", requires=["b"]), "z": record("z", requires=["c"]),
            "b": record("b", requires=['missing; extra == "http"'], extras=["http"]),
            "c": record("c", requires=["b[http]"])})
        self.assertIn("missing", result["nodes"])
        self.assertFalse(result["required_chain_passed"])

    def test_unrequested_extra_and_unrelated_bad_package_are_excluded(self):
        result = self.check(["a"], {
            "a": record("a", requires=['missing; extra == "dev"'], extras=["dev"]),
            "unrelated": record("unrelated", requires=["also-missing"])})
        self.assertTrue(result["required_chain_passed"])
        self.assertEqual(set(result["nodes"]), {"a"})

    def test_cycles_terminate_and_names_are_normalized(self):
        result = self.check(["A_Pkg"], {
            "a-pkg": record("a-pkg", requires=["b"]),
            "b": record("b", requires=["a.pkg"])})
        self.assertTrue(result["required_chain_passed"])
        self.assertEqual(set(result["nodes"]), {"a-pkg", "b"})

    def test_missing_requested_extra_is_reported(self):
        result = self.check(["a[http]"], {"a": record("a")})
        self.assertEqual(result["issues"][0]["kind"], "unprovided_extra")

    def test_python_requirement_is_checked(self):
        result = self.check(["a"], {"a": record("a", python="<3.13")})
        self.assertEqual(result["issues"][0]["kind"], "incompatible_python")


if __name__ == "__main__":
    unittest.main(verbosity=2)
