"""Synthetic failure/resume/metadata guards; never fetch/install real packages."""
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import warnings
import zipfile

from packaging.tags import Tag
from packaging.version import Version

import wheels
from cache_wheels import (BASE_VERSIONS, EXPERIMENT, PREFLIGHT, TOTAL_BYTES,
                          check_existing, validate_plan)

TAGS = [Tag('py3', 'none', 'any')]
ROOT = Path(__file__).resolve().parent


def fixture(folder, metadata_name='demo', metadata_version='1.0', dependencies='',
            extra_name=None, wheel_tag='py3-none-any', python_bound='>=3.9'):
    path = folder / 'demo-1.0-py3-none-any.whl'
    content = 'Metadata-Version: 2.1\nName: ' + metadata_name + '\nVersion: ' + metadata_version + '\nRequires-Python: ' + python_bound + '\n' + dependencies + '\n'
    with zipfile.ZipFile(path, 'w') as archive:
        archive.writestr('demo/__init__.py', 'raise RuntimeError("Must not execute")\n')
        archive.writestr('demo-1.0.dist-info/METADATA', content)
        archive.writestr('demo-1.0.dist-info/WHEEL', 'Wheel-Version: 1.0\nTag: ' + wheel_tag + '\n')
        archive.writestr('demo-1.0.dist-info/RECORD', '')
        if extra_name:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore', UserWarning)
                archive.writestr(extra_name, 'bad')
    return path, {'filename': path.name, 'package': 'demo', 'version': '1.0',
                  'url': 'https://files.pythonhosted.org/demo.whl',
                  'sha256': wheels.digest(path), 'bytes': path.stat().st_size}


class Response(io.BytesIO):
    def __init__(self, data, size=None, url='https://files.pythonhosted.org/demo.whl'):
        super().__init__(data)
        self.status = 200
        self.url = url
        self.headers = {} if size is None else {'Content-Length': str(size)}


class WheelChecks(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.folder = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_metadata_and_sizes_without_execution(self):
        path, record = fixture(self.folder, dependencies='Requires-Dist: child>=1; python_version >= "3.13"\n')
        result = wheels.inspect_wheel(path, record, TAGS, '3.13.16')
        self.assertEqual(result['metadata']['name'], 'demo')
        self.assertEqual(len(result['metadata']['requires_dist']), 1)
        self.assertEqual(result['zip_member_count'], 4)
        self.assertGreater(result['zip_uncompressed_file_bytes'], 0)

    def test_actual_metadata_identity_and_python_bound_checked(self):
        for args in [{'metadata_name': 'other'}, {'metadata_version': '2.0'}, {'python_bound': '<3.13'}]:
            with self.subTest(args=args):
                path, record = fixture(self.folder, **args)
                with self.assertRaises(RuntimeError):
                    wheels.inspect_wheel(path, record, TAGS, '3.13.16')

    def test_zip_traversal_duplicate_and_tags_rejected(self):
        for args in [{'extra_name': '../escape'}, {'extra_name': 'demo-1.0.dist-info/RECORD'},
                     {'wheel_tag': 'cp312-cp312-linux_x86_64'}]:
            with self.subTest(args=args):
                path, record = fixture(self.folder, **args)
                with self.assertRaises(RuntimeError):
                    wheels.inspect_wheel(path, record, TAGS, '3.13.16')

    def test_record_publisher_tag_and_hash_guards(self):
        _, record = fixture(self.folder)
        for changes in [{'url': 'http://files.pythonhosted.org/demo.whl'},
                        {'url': 'https://other.example/demo.whl'}, {'filename': '../demo.whl'},
                        {'sha256': 'x' * 64}, {'bytes': 0}, {'version': '2.0'}]:
            with self.subTest(changes=changes), self.assertRaises((RuntimeError, ValueError)):
                wheels.validate_record({**record, **changes}, TAGS, '3.13.16')

    def test_complete_cached_file_and_receipt_verified(self):
        cache = self.folder / 'wheels'
        receipts = self.folder / 'receipts'
        cache.mkdir(); receipts.mkdir()
        path, record = fixture(cache)
        def save(path, value):
            path.write_text(json.dumps(value))
        checked = check_existing(cache, {path.name: record}, receipts, save)
        self.assertEqual(set(checked), {path.name})
        (receipts / (path.name + '.json')).write_text('{}')
        with self.assertRaises(RuntimeError):
            check_existing(cache, {path.name: record}, receipts, save)

    def test_corrupt_cache_and_missing_receipted_file_preserved(self):
        cache, receipts = self.folder / 'wheels', self.folder / 'receipts'
        cache.mkdir(); receipts.mkdir()
        path, record = fixture(cache)
        data = path.read_bytes()
        path.write_bytes(b'x' + data[1:])
        with self.assertRaises(RuntimeError):
            check_existing(cache, {path.name: record}, receipts, lambda *args: None)
        self.assertTrue(path.exists())
        path.unlink()
        (receipts / (path.name + '.json')).write_text('{}')
        with self.assertRaises(RuntimeError):
            check_existing(cache, {path.name: record}, receipts, lambda *args: None)

    def test_stream_enforces_size_digest_and_redirect(self):
        data = b'approved bytes'
        record = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        self.assertEqual(wheels.copy_response(Response(data, len(data)), io.BytesIO(), record), len(data))
        for response in [Response(data[:-1]), Response(data + b'!'),
                         Response(b'x' * len(data)), Response(data, len(data) + 1),
                         Response(data, url='https://other.example/file')]:
            with self.subTest(response=response), self.assertRaises(RuntimeError):
                wheels.copy_response(response, io.BytesIO(), record)

    def test_transfer_publishes_only_verified_bytes(self):
        source, record = fixture(self.folder)
        cache = self.folder / 'cache' / 'wheels'
        cache.mkdir(parents=True)
        opener = type('Opener', (), {'open': lambda self, *a, **k: Response(source.read_bytes(), record['bytes'])})()
        with patch.object(wheels, 'build_opener', return_value=opener):
            final = wheels.download_one(record, cache, 'attempt1')
        self.assertEqual(final.read_bytes(), source.read_bytes())
        self.assertFalse((cache.parent / 'incomplete/attempt1' / (source.name + '.partial')).exists())

    def test_interrupted_transfer_preserved_and_next_attempt_can_restart(self):
        source, record = fixture(self.folder)
        cache = self.folder / 'cache' / 'wheels'
        cache.mkdir(parents=True)
        opener = type('Opener', (), {'open': lambda self, *a, **k: Response(source.read_bytes()[:-1])})()
        with patch.object(wheels, 'build_opener', return_value=opener), self.assertRaises(RuntimeError):
            wheels.download_one(record, cache, 'attempt1')
        self.assertFalse((cache / source.name).exists())
        self.assertTrue((cache.parent / 'incomplete/attempt1' / (source.name + '.partial')).exists())
        opener = type('Opener', (), {'open': lambda self, *a, **k: Response(source.read_bytes())})()
        with patch.object(wheels, 'build_opener', return_value=opener):
            self.assertTrue(wheels.download_one(record, cache, 'attempt2').is_file())


class PlanChecks(unittest.TestCase):
    def proposal(self):
        approved = json.loads((ROOT / 'APPROVED_ISOLATED_VERSIONS.json').read_text())
        versions = list(approved.items()) + list(BASE_VERSIONS.items()) + [('jedi', '0.20.0'), ('parso', '0.8.5')]
        records = [{'package': name, 'version': version,
                    'filename': name.replace('-', '_') + '-' + version + '-py3-none-any.whl',
                    'url': 'https://' + ('download.pytorch.org' if name == 'torch' else 'files.pythonhosted.org') + '/wheel.whl',
                    'bytes': 1, 'sha256': 'a' * 64} for name, version in versions]
        records[0]['bytes'] = TOTAL_BYTES - 89
        plan = {'format': 'ATML_TASK4_ISOLATION_PROPOSAL_V1', 'approval_pending': True,
                'source_manifest_sha256': PREFLIGHT, 'blockers': [], 'download_total_complete': True,
                'original_gpu_required_distributions': 83, 'isolated_package_versions': approved,
                'gpu_torch_build_preserved': '2.11.0+cu130', 'course_pins_changed': False,
                'gpu_exceptions_accepted': [], 'package_changes_performed': False, 'wheel_files_downloaded': 0,
                'virtual_environment_created': False, 'pretrained_models_loaded': 0,
                'conflict_packages_in_actual_task4_chain': {'ipython': False, 'jedi': False, 'gradio': False, 'diffusers': False},
                'proposed_environment_isolated_from_system_site_packages': True,
                'proposed_wheelhouse': str(EXPERIMENT / 'environment_wheelhouse'),
                'proposed_local_a100_environment': '/content/task4_isolated_runtime_v1',
                'colab_base_repair_proposal': {'restore_original_versions_if_still_modified': BASE_VERSIONS,
                    'remove_only_course_added_global_packages_after_isolated_environment_passes': ['bitsandbytes', 'trl'],
                    'proposed_add_or_change_base_packages': {'jedi': '0.20.0'},
                    'jedi_dependencies': {'parso': {'original_version': '0.8.5', 'proposed_version': '0.8.5'}}},
                'proposed_wheels': records, 'known_unique_wheel_count': 90, 'known_compressed_download_bytes': TOTAL_BYTES}
        return plan, approved

    def test_exact_reviewed_scope_passes(self):
        plan, approved = self.proposal()
        self.assertEqual(len(validate_plan(plan, approved, TAGS, '3.13.16')), 90)

    def test_changed_versions_totals_and_unapproved_repairs_rejected(self):
        plan, approved = self.proposal()
        candidates = []
        value = copy.deepcopy(plan); value['isolated_package_versions']['torch'] = '2.11.0+cpu'; candidates.append(value)
        value = copy.deepcopy(plan); value['known_compressed_download_bytes'] += 1; candidates.append(value)
        value = copy.deepcopy(plan); value['colab_base_repair_proposal']['proposed_add_or_change_base_packages']['parso'] = '9'; candidates.append(value)
        value = copy.deepcopy(plan); value['gpu_exceptions_accepted'] = ['anything']; candidates.append(value)
        for value in candidates:
            with self.assertRaises(RuntimeError):
                validate_plan(value, approved, TAGS, '3.13.16')


class DependencyChecks(unittest.TestCase):
    def helper(self):
        spec = importlib.util.spec_from_file_location('fixture_dependencies', ROOT.parent / 'diagnostic_v1/dependencies.py')
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        return module.inspect_chain

    def node(self, name, version='1.0', deps=None, extras=None):
        return {'metadata': {'name': name, 'version': version, 'requires_dist': deps or [],
                             'provides_extra': extras or [], 'requires_python': '>=3.9'}}

    def test_extras_transitive_closure_and_missing_dependency(self):
        target = {'python_version': '3.13', 'python_full_version': '3.13.16', 'sys_platform': 'linux'}
        nodes = {('root', Version('1.0')): self.node('root', deps=['child[feature]>=1']),
                 ('child', Version('1.0')): self.node('child', deps=['leaf>=1; extra == "feature"'], extras=['feature']),
                 ('leaf', Version('1.0')): self.node('leaf')}
        pins = {'root': '1.0', 'child': '1.0', 'leaf': '1.0'}
        course, full = wheels.check_closure(self.helper(), nodes, pins, target, ['root==1.0'], pins)
        self.assertEqual(len(course['nodes']), 3)
        self.assertEqual(len(full['nodes']), 3)
        del nodes[('leaf', Version('1.0'))]
        del pins['leaf']
        with self.assertRaises(RuntimeError):
            wheels.check_closure(self.helper(), nodes, pins, target, ['root==1.0'], pins)

    def test_incompatible_transitive_version_cannot_be_ignored(self):
        target = {'python_version': '3.13', 'python_full_version': '3.13.16', 'sys_platform': 'linux'}
        nodes = {('root', Version('1.0')): self.node('root', deps=['child>=2']),
                 ('child', Version('1.0')): self.node('child')}
        pins = {'root': '1.0', 'child': '1.0'}
        with self.assertRaises(RuntimeError):
            wheels.check_closure(self.helper(), nodes, pins, target, ['root==1.0'], pins)


if __name__ == '__main__':
    unittest.main(verbosity=2)
