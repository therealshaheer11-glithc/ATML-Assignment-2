"""Approved Block 9: CPU-only exact package cache; no install or model loading."""
from datetime import datetime, timezone
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import platform
import shutil
import sys

from packaging.markers import default_environment
from packaging.requirements import Requirement
from packaging.tags import sys_tags
from packaging.utils import canonicalize_name
from packaging.version import Version

from wheels import (check_closure, digest, download_one, inspect_wheel, require,
                    safe_name, validate_record, verify_file)

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
EXPERIMENT = Path('/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1')
STAGE1 = '9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65'
PREFLIGHT = '2ddda0858de0b95a43e006f77b56e569cf037beeec97c06e3f8b3a99275435d5'
PREFLIGHT_ATTEMPT = '20261011T145304.669615Z'
GPU = 'd941ecb6c16ec91a942b319167826007f5124b0dedc10d2a337b3b783ff4015b'
GPU_ATTEMPT = '20261011T142511.766769Z'
DIAGNOSTIC = '71bdb7fdbe130c5adaef8328437371bcd89621d0a93e849bab61b7db8491c540'
TOTAL_BYTES = 2969739166
BASE_VERSIONS = {'huggingface-hub': '1.33.0', 'peft': '0.21.1',
                 'tokenizers': '0.23.2', 'transformers': '5.18.0'}


def read(path):
    return json.loads(Path(path).read_text())


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def inventory():
    return {canonicalize_name(item.metadata['Name']): item.version for item in metadata.distributions()
            if item.metadata.get('Name')}


def validate_plan(plan, approved, tags, python_version):
    require(plan['format'] == 'ATML_TASK4_ISOLATION_PROPOSAL_V1' and plan['approval_pending'] is True and
            plan['source_manifest_sha256'] == PREFLIGHT and not plan['blockers'] and
            plan['download_total_complete'] is True, 'Saved isolation proposal is not the reviewed candidate')
    require(plan['original_gpu_required_distributions'] == 83 and
            plan['isolated_package_versions'] == approved and len(approved) == 84 and
            plan['gpu_torch_build_preserved'] == '2.11.0+cu130' and plan['course_pins_changed'] is False,
            'Exact approved isolated package versions differ')
    require(plan['gpu_exceptions_accepted'] == [] and plan['package_changes_performed'] is False and
            plan['wheel_files_downloaded'] == 0 and plan['virtual_environment_created'] is False and
            plan['pretrained_models_loaded'] == 0, 'Unexpected prior preflight action')
    require(not any(plan['conflict_packages_in_actual_task4_chain'].values()) and
            plan['proposed_environment_isolated_from_system_site_packages'] is True,
            'Isolation/membership proposal differs')
    require(plan['proposed_wheelhouse'] == str(EXPERIMENT / 'environment_wheelhouse') and
            plan['proposed_local_a100_environment'] == '/content/task4_isolated_runtime_v1',
            'Approved environment destination differs')
    repair = plan['colab_base_repair_proposal']
    require(repair['restore_original_versions_if_still_modified'] == BASE_VERSIONS and
            repair['remove_only_course_added_global_packages_after_isolated_environment_passes'] == ['bitsandbytes', 'trl'] and
            repair['proposed_add_or_change_base_packages'] == {'jedi': '0.20.0'},
            'Approved conditional base repair differs')
    require(set(repair['jedi_dependencies']) == {'parso'}, 'Unexpected Jedi dependency')
    parso = repair['jedi_dependencies']['parso']
    require(parso['original_version'] == parso['proposed_version'] and parso['proposed_version'] is not None,
            'A Parso version change was not approved')
    expected = {(canonicalize_name(name), Version(version)) for name, version in approved.items()}
    expected |= {(name, Version(version)) for name, version in BASE_VERSIONS.items()}
    expected |= {('jedi', Version('0.20.0')), ('parso', Version(parso['proposed_version']))}
    records = plan['proposed_wheels']
    require(len(records) == plan['known_unique_wheel_count'] == 90 and
            sum(item['bytes'] for item in records) == plan['known_compressed_download_bytes'] == TOTAL_BYTES,
            'Approved 90-file download count or byte total differs')
    require(len({item['filename'] for item in records}) == 90 and
            len({(canonicalize_name(item['package']), Version(item['version'])) for item in records}) == 90,
            'Duplicate proposed wheel name or package/version')
    require({(canonicalize_name(item['package']), Version(item['version'])) for item in records} == expected,
            'Proposed wheels differ from approved isolated/base packages')
    for item in records:
        validate_record(item, tags, python_version)
    return {item['filename']: item for item in sorted(records, key=lambda item: item['filename'])}


def check_existing(cache, files, receipts, save):
    """Validate every complete cached unit before making any network request."""
    require(not cache.is_symlink() and not receipts.is_symlink(), 'Cache directory is a symlink')
    require(not cache.exists() or (cache.is_dir() and {p.name for p in cache.iterdir()} <= set(files)),
            'Unexpected cache file; preserved')
    require(not receipts.exists() or (receipts.is_dir() and
            {p.name for p in receipts.iterdir()} <= {name + '.json' for name in files}),
            'Unexpected wheel receipt; preserved')
    checked = {}
    for name, record in files.items():
        path, receipt = cache / name, receipts / (name + '.json')
        require(not receipt.exists() or path.is_file(), 'Receipted wheel is missing: ' + name)
        if path.exists() or path.is_symlink():
            print('Verifying saved wheel:', name, flush=True)
            result = verify_file(path, record)
            require(not receipt.exists() or read(receipt) == result, 'Saved wheel receipt differs: ' + name)
            checked[name] = result
    for name, result in checked.items():
        save(receipts / (name + '.json'), result)
    return checked


def main():
    first = EXPERIMENT / 'preflight_releases' / STAGE1
    require(digest(first / 'MANIFEST.json') == STAGE1, 'Original preflight source differs')
    require(digest(first / 'scripts/preflight.py') == read(first / 'MANIFEST.json')['scripts/preflight.py'],
            'Original preflight helper differs')
    preflight = load('task4_wheel_preflight', first / 'scripts/preflight.py')
    preflight.verify_source(first)
    preflight.require_cpu()
    own = preflight.verify_source(ROOT)
    require(read(EXPERIMENT / 'OWNER.json')['approval_sha256'] == digest(first / 'docs/approval.json'),
            'Task ownership differs')
    approval = read(ROOT / 'APPROVAL.json')
    require(approval['approved'] is True and approval['user_message'] == 'approved' and
            approval['current_block_scope'] == 'CPU wheel download, checksum, metadata and dependency validation only' and
            approval['package_installation_performed_by_this_block'] is False and
            approval['approved_proposal_sha256'] == digest(ROOT / 'APPROVED_PROPOSAL.md') and
            approval['approved_isolated_versions_sha256'] == digest(ROOT / 'APPROVED_ISOLATED_VERSIONS.json'),
            'Reviewed setup approval identity/scope differs')
    save, save_bytes = preflight.immutable_json, preflight.immutable_bytes
    identity = own['manifest_sha256']
    release = EXPERIMENT / 'wheel_cache_releases' / identity
    for name in [*read(ROOT / 'MANIFEST.json'), 'MANIFEST.json']:
        save_bytes(release / name, (ROOT / name).read_bytes())
    attempt_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    attempt = EXPERIMENT / 'wheel_cache_attempts' / attempt_id
    attempt.mkdir(parents=True, exist_ok=False)
    report = {'format': 'ATML_TASK4_WHEEL_CACHE_ATTEMPT_V1', 'status': 'RUNNING',
              'attempt_utc': attempt_id, 'source_manifest_sha256': identity,
              'approval_sha256': digest(ROOT / 'APPROVAL.json'),
              'verified_file_count': 0, 'download_calls_started': [], 'reused_complete_files': [],
              'package_changes_performed': False, 'virtual_environment_created': False,
              'model_downloads_performed': False, 'pretrained_models_loaded': 0,
              'task4_responses_generated': 0, 'task4_judgments_produced': 0,
              'human_labels_assigned': 0, 'training_performed': False, 'gpu_exceptions_accepted': []}
    try:
        save(attempt / 'START.json', report)
        before = inventory()
        save(attempt / 'CPU_PACKAGE_VERSIONS_BEFORE.json', before)
        for kind, source in [('isolation_preflight', PREFLIGHT), ('gpu_environment', GPU), ('diagnostic', DIAGNOSTIC)]:
            folder = EXPERIMENT / (kind + '_releases') / source
            require(digest(folder / 'MANIFEST.json') == source, 'Referenced sealed source differs')
            preflight.verify_source(folder)
        previous_folder = EXPERIMENT / 'isolation_preflight_attempts' / PREFLIGHT_ATTEMPT
        previous = read(previous_folder / 'REPORT.json')
        require(previous['status'] == 'ISOLATION_PREFLIGHT_READY_FOR_REVIEW' and
                previous['source_manifest_sha256'] == PREFLIGHT and
                previous['proposed_wheel_count'] == 90 and previous['gpu_required_distributions'] == 83 and
                previous['known_compressed_download_bytes'] == TOTAL_BYTES and not previous['blockers'] and
                previous['current_cpu_package_versions_unchanged'] is True, 'Returned CPU preflight report differs')
        for name, expected in previous['artifact_sha256'].items():
            require(digest(previous_folder / safe_name(name)) == expected, 'Saved CPU planning artifact differs: ' + name)
        require(previous['proposal_sha256'] == digest(previous_folder / 'ISOLATION_PROPOSAL.json'),
                'Saved proposal identity differs')
        plan = read(previous_folder / 'ISOLATION_PROPOSAL.json')
        report.update({'isolation_preflight_report_sha256': digest(previous_folder / 'REPORT.json'),
                       'isolation_proposal_sha256': previous['proposal_sha256']})
        save(attempt / 'APPROVED_ISOLATION_PROPOSAL.json', plan)
        gpu_folder = EXPERIMENT / 'gpu_environment_attempts' / GPU_ATTEMPT
        gpu_report = read(gpu_folder / 'REPORT.json')
        require(digest(gpu_folder / 'REPORT.json') == plan['original_gpu_report_sha256'] and
                gpu_report['source_manifest_sha256'] == GPU and
                gpu_report['status'] == 'GPU_ENVIRONMENT_REVIEW_REQUIRED' and
                gpu_report['gpu_exceptions_accepted'] == [], 'Saved A100 result differs')
        for name, expected in gpu_report['artifact_sha256'].items():
            require(digest(gpu_folder / safe_name(name)) == expected, 'Saved A100 artifact differs: ' + name)
        protocol = EXPERIMENT / 'CPU_ORCHESTRATION_VALIDATION_CONTRACT.json'
        require(digest(protocol) == plan['cpu_orchestration_contract_sha256'] ==
                gpu_report['cpu_orchestration_contract_sha256'], 'Fixed CPU protocol differs')
        require(digest(EXPERIMENT / 'CPU_MODEL_INPUT_CONTRACT.json') == read(protocol)['model_input_contract_sha256'],
                'Frozen model inputs differ')
        graph = read(gpu_folder / 'GPU_REQUIRED_DEPENDENCY_CHAIN.json')
        require(graph['required_chain_passed'] and not graph['issues'], 'Saved GPU graph failed')
        target = graph['marker_environment']
        now = default_environment()
        for key in ['implementation_name', 'python_version', 'platform_machine', 'platform_system']:
            require(now[key] == target[key], 'CPU inspection platform differs from A100: ' + key)
        tags = list(sys_tags())
        approved = read(ROOT / 'APPROVED_ISOLATED_VERSIONS.json')
        files = validate_plan(plan, approved, tags, target['python_full_version'])
        require((previous_folder / 'PROPOSED_TASK4_PACKAGE_PINS.txt').read_text() ==
                ''.join(name + '==' + version + '\n' for name, version in sorted(approved.items())),
                'Saved isolated pin file differs')
        save(attempt / 'CPU_INSPECTION_PLATFORM.json', {'python': platform.python_version(),
            'marker_environment': now, 'saved_gpu_marker_environment': target,
            'compatible_tags': [str(tag) for tag in tags], 'fresh_a100_tag_validation_pending': True})
        wheelhouse = EXPERIMENT / 'environment_wheelhouse'
        cache, receipts = wheelhouse / 'wheels', wheelhouse / 'receipts'
        binding = {'format': 'ATML_TASK4_APPROVED_WHEELHOUSE_V1',
                   'approval_sha256': report['approval_sha256'], 'source_manifest_sha256': identity,
                   'isolation_proposal_sha256': report['isolation_proposal_sha256'],
                   'isolation_preflight_report_sha256': report['isolation_preflight_report_sha256'],
                   'files': files, 'total_compressed_bytes': TOTAL_BYTES}
        # Existing cache evidence is never rebound to a new source or approval.
        save(wheelhouse / 'CACHE_IDENTITY_CONTRACT.json', binding)
        checked = check_existing(cache, files, receipts, save)
        reused = sorted(checked)
        report.update({'verified_file_count': len(checked), 'reused_complete_files': reused,
                       'cache_identity_contract_sha256': digest(wheelhouse / 'CACHE_IDENTITY_CONTRACT.json')})
        save(attempt / 'VERIFIED_EXISTING_FILES.json', checked)
        cache.mkdir(parents=True, exist_ok=True)
        receipts.mkdir(parents=True, exist_ok=True)
        print('Approved wheel cache:', len(files), 'files;', TOTAL_BYTES, 'compressed bytes.', flush=True)
        print('Verified complete files reused:', len(reused), '; missing:', len(files) - len(reused), flush=True)
        print('Per-file resume: prior incomplete transfers remain preserved; missing files restart from byte zero.', flush=True)
        measurements = {}
        for index, (name, record) in enumerate(files.items(), 1):
            path = cache / name
            if name not in checked:
                print('Downloading wheel', str(index) + '/' + str(len(files)) + ':', name, flush=True)
                report['download_calls_started'].append(name)
                save(attempt / ('DOWNLOAD_STARTED_' + str(index).zfill(3) + '.json'), record)
                download_one(record, cache, attempt_id)
                checked[name] = verify_file(path, record)
                save(receipts / (name + '.json'), checked[name])
                report['verified_file_count'] = len(checked)
            # Parse each already checksum-verified wheel without executing its code.
            measurements[name] = inspect_wheel(path, record, tags, target['python_full_version'])
            save(attempt / ('WHEEL_' + str(index).zfill(3) + '.json'), measurements[name])
            report['verified_file_count'] = len(checked)
            report['inspected_metadata_count'] = len(measurements)
            print('Wheels verified:', str(len(checked)) + '/90; metadata inspected:',
                  str(len(measurements)) + '/90', flush=True)
        dependencies = load('task4_wheel_dependencies',
                            EXPERIMENT / 'diagnostic_releases' / DIAGNOSTIC / 'dependencies.py')
        records = {(canonicalize_name(value['metadata']['name']), Version(value['metadata']['version'])): value
                   for value in measurements.values()}
        saved_versions = {name: node['version'] for name, node in graph['nodes'].items()}
        course, full = check_closure(dependencies.inspect_chain, records, approved, target,
                                    (first / 'course_reference/requirements.txt').read_text().splitlines(), saved_versions)
        save(attempt / 'ACTUAL_WHEEL_COURSE_DEPENDENCY_CHAIN.json', course)
        save(attempt / 'ACTUAL_WHEEL_FULL_ISOLATED_DEPENDENCY_CHAIN.json', full)
        parso = plan['colab_base_repair_proposal']['jedi_dependencies']['parso']['proposed_version']
        base_nodes = {name: records[(name, Version(version))]['metadata']
                      for name, version in {'jedi': '0.20.0', 'parso': parso}.items()}
        jedi = dependencies.inspect_chain(['jedi==0.20.0'], base_nodes.get, target)
        require(jedi['required_chain_passed'] and not jedi['issues'] and set(jedi['nodes']) == {'jedi', 'parso'},
                'Actual Jedi/Parso wheel dependency closure failed')
        requirement = Requirement(plan['colab_base_repair_proposal']['jedi_declared_requirement'])
        require(requirement.name.lower() == 'jedi' and requirement.specifier.contains('0.20.0'),
                'Approved Jedi does not satisfy the original IPython bound')
        save(attempt / 'ACTUAL_JEDI_REPAIR_DEPENDENCY_CHAIN.json', jedi)
        isolated = [records[(name, Version(version))] for name, version in approved.items()]
        sizes = {'compressed_wheel_bytes': TOTAL_BYTES,
                 'all_90_wheels_zip_uncompressed_file_bytes': sum(v['zip_uncompressed_file_bytes'] for v in measurements.values()),
                 'isolated_84_wheels_zip_uncompressed_file_bytes': sum(v['zip_uncompressed_file_bytes'] for v in isolated),
                 'largest_isolated_wheel_uncompressed_file_bytes': max(v['zip_uncompressed_file_bytes'] for v in isolated),
                 'largest_isolated_wheel_compressed_bytes': max(v['compressed_bytes'] for v in isolated),
                 'installed_disk_usage_measured': False,
                 'note': 'ZIP logical byte totals only. Before A100 installation check actual available local space, installer temporary space, bytecode and filesystem overhead; no timing estimate is asserted.',
                 'current_cpu_local_content_free_bytes': shutil.disk_usage('/content').free}
        save(attempt / 'WHEEL_SIZE_MEASUREMENTS.json', sizes)
        save(attempt / 'ALL_WHEEL_INSPECTIONS.json', measurements)
        after = inventory()
        save(attempt / 'CPU_PACKAGE_VERSIONS_AFTER.json', after)
        require(before == after, 'CPU package inventory changed unexpectedly')
        contract = {**binding, 'format': 'ATML_TASK4_VERIFIED_WHEELHOUSE_V1',
                    'cache_identity_contract_sha256': report['cache_identity_contract_sha256'],
                    'relative_wheel_directory': 'wheels', 'relative_receipt_directory': 'receipts',
                    'verified_files': checked, 'wheel_inspections': measurements,
                    'isolated_package_versions': approved, 'saved_gpu_marker_environment': target,
                    'course_wheel_dependency_chain_sha256': digest(attempt / 'ACTUAL_WHEEL_COURSE_DEPENDENCY_CHAIN.json'),
                    'full_isolated_dependency_chain_sha256': digest(attempt / 'ACTUAL_WHEEL_FULL_ISOLATED_DEPENDENCY_CHAIN.json'),
                    'sizes': {key: value for key, value in sizes.items() if key != 'current_cpu_local_content_free_bytes'},
                    'all_wheels_verified': True, 'package_installation_performed': False,
                    'isolated_a100_installation_and_validation_pending': True,
                    'colab_base_repair_and_validation_pending': True}
        save(wheelhouse / 'VERIFIED_WHEELHOUSE_CONTRACT.json', contract)
        report.update({'status': 'CPU_WHEEL_CACHE_VERIFIED_NO_INSTALLATION',
                       'verified_file_count': len(checked), 'inspected_metadata_count': len(measurements),
                       'compressed_verified_bytes': TOTAL_BYTES,
                       'course_dependency_distributions': len(course['nodes']),
                       'isolated_dependency_distributions': len(full['nodes']),
                       'actual_wheel_dependency_closure_passed': True, 'cpu_package_inventory_unchanged': True,
                       'verified_wheelhouse_contract_sha256': digest(wheelhouse / 'VERIFIED_WHEELHOUSE_CONTRACT.json'),
                       'wheel_size_measurements': sizes})
        print('COMPLETE: 90/90 wheels checksum-verified and metadata-inspected.', flush=True)
        print('Dependency closure: course', len(course['nodes']), '; isolated', len(full['nodes']), '; Jedi/Parso passes.', flush=True)
        print('Isolated wheels logical unpacked bytes:', sizes['isolated_84_wheels_zip_uncompressed_file_bytes'], flush=True)
        print('Largest isolated unpacked wheel bytes:', sizes['largest_isolated_wheel_uncompressed_file_bytes'], flush=True)
        print('Reused complete files:', len(reused), '; download calls:', len(report['download_calls_started']), flush=True)
        print('No package installation/removal, environment creation, model loading, inference or training.', flush=True)
        print('Remaining: responses 1800; judgments 1800; human labels 240. Return this output before the A100 block.', flush=True)
    except BaseException as error:
        report.update({'status': 'CPU_WHEEL_CACHE_FAILED_PRESERVED',
                       'error': {'type': type(error).__name__, 'message': str(error)}})
        raise
    finally:
        report['artifact_sha256'] = {p.name: digest(p) for p in attempt.iterdir() if p.is_file()}
        save(attempt / 'REPORT.json', report)
        print('Saved wheel cache report:', attempt / 'REPORT.json', flush=True)
        print('Status:', report['status'], flush=True)


if __name__ == '__main__':
    main()
