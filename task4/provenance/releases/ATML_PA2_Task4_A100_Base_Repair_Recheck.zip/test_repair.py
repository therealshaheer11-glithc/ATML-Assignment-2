"""Mutation-boundary regression tests; no real package changes."""
import copy
import importlib.util
from pathlib import Path
import sys
import unittest

from repair_guards import (RESTORE, MODIFIED, ADDED, TOOLS, JEDI, PARSO, plan_repair,
                           validate_final_inventory, validate_base_inventory,
                           base_install_command, base_remove_command)

ROOT = Path(__file__).resolve().parent


class BaseRepairGuards(unittest.TestCase):
    def setUp(self):
        self.original = {**RESTORE, **TOOLS, 'parso': PARSO, 'torch': '2.11.0+cu130', 'other': '1'}
        self.modified = {**self.original, **MODIFIED, **ADDED}
        self.changes = {name: {'before': self.original.get(name), 'after': self.modified.get(name)}
                        for name in sorted(set(self.original) | set(self.modified))
                        if self.original.get(name) != self.modified.get(name)}
        self.proposal = {'restore_original_versions_if_still_modified': RESTORE,
            'remove_only_course_added_global_packages_after_isolated_environment_passes': sorted(ADDED),
            'proposed_add_or_change_base_packages': {'jedi': JEDI}, 'preserve_colab_tools': TOOLS,
            'jedi_dependencies': {'parso': {'original_version': PARSO, 'proposed_version': PARSO}}}

    def plan(self, current, baseline=None):
        return plan_repair(current, baseline or self.modified, self.original, self.modified, self.changes, self.proposal)

    def test_modified_base_selects_exact_five_installs_and_two_removals(self):
        planned = self.plan(self.modified)
        self.assertEqual(planned['install_exact_versions'], {**RESTORE, 'jedi': JEDI})
        self.assertEqual(planned['remove_exact_global_names'], sorted(ADDED))
        self.assertEqual(planned['expected_complete_base_versions'], {**self.original, 'jedi': JEDI})

    def test_fresh_base_only_adds_missing_jedi(self):
        planned = self.plan(self.original)
        self.assertEqual(planned['install_exact_versions'], {'jedi': JEDI})
        self.assertEqual(planned['remove_exact_global_names'], [])

    def test_already_repaired_base_is_noop_and_does_not_reinstall(self):
        planned = self.plan({**self.original, 'jedi': JEDI})
        self.assertFalse(planned['package_changes_needed'])
        self.assertEqual(planned['install_exact_versions'], {})

    def test_partial_known_repair_resumes_only_missing_operations(self):
        partial = {**self.modified, 'huggingface-hub': RESTORE['huggingface-hub'], 'jedi': JEDI}
        del partial['trl']
        planned = self.plan(partial)
        self.assertEqual(set(planned['install_exact_versions']), {'peft', 'tokenizers', 'transformers'})
        self.assertEqual(planned['remove_exact_global_names'], ['bitsandbytes'])

    def test_unknown_target_and_added_versions_stop_before_planning(self):
        for name in [*RESTORE, *ADDED, 'jedi']:
            with self.subTest(name=name), self.assertRaises(RuntimeError):
                self.plan({**self.modified, name: '999'})

    def test_unrelated_add_remove_or_version_drift_stops(self):
        for current in [{**self.modified, 'other': '2'}, {**self.modified, 'new': '1'},
                        {name: value for name, value in self.modified.items() if name != 'other'}]:
            with self.assertRaises(RuntimeError): self.plan(current)

    def test_colab_tools_torch_parso_are_preserved_even_if_baseline_has_drifted(self):
        for name in [*TOOLS, 'torch', 'parso']:
            bad = {**self.modified, name: '999'}
            with self.subTest(name=name), self.assertRaises(RuntimeError): self.plan(bad, bad)

    def test_unrecorded_historical_mutation_or_parso_repair_rejected(self):
        self.changes['other'] = {'before': '1', 'after': '2'}
        with self.assertRaises(RuntimeError): self.plan(self.modified)
        self.setUp()
        self.proposal['jedi_dependencies']['parso']['proposed_version'] = '999'
        with self.assertRaises(RuntimeError): self.plan(self.modified)

    def test_final_inventory_rejects_extra_changes(self):
        planned = self.plan(self.modified)
        expected = planned['expected_complete_base_versions']
        changes = validate_final_inventory(self.modified, expected, planned)
        self.assertEqual(set(changes), set(RESTORE) | set(ADDED) | {'jedi'})
        with self.assertRaises(RuntimeError):
            validate_final_inventory(self.modified, {**expected, 'torch': '2.11.0+cpu'}, planned)

    def test_wrong_interpreter_or_escaped_distributions_rejected(self):
        base = {'prefix': '/usr', 'base_prefix': '/usr', 'executable': '/usr/bin/python',
                'duplicate_distributions': [], 'outside_prefix_distributions': [],
                'outside_prefix_site_paths': [], 'package_versions': self.modified}
        self.assertEqual(validate_base_inventory(base, '/usr/bin/python'), self.modified)
        for changed in [{**base, 'prefix': '/content/task4_isolated_runtime_v1'},
                        {**base, 'executable': '/other/bin/python'},
                        {**base, 'duplicate_distributions': ['jedi']},
                        {**base, 'outside_prefix_distributions': ['jedi']}]:
            with self.assertRaises(RuntimeError): validate_base_inventory(changed, '/usr/bin/python')

    def test_installation_stays_offline_hashed_and_dependency_changes_disabled(self):
        command = base_install_command('/base/python', '/req.txt', '/report.json')
        self.assertEqual(command[:5], ['/base/python', '-I', '-B', '-m', 'pip'])
        for flag in ['--no-index', '--no-deps', '--only-binary=:all:', '--require-hashes']:
            self.assertIn(flag, command)
        self.assertNotIn('--upgrade', command)
        self.assertNotIn('--force-reinstall', command)

    def test_uninstall_cannot_target_anything_beyond_two_approved_names(self):
        self.assertEqual(base_remove_command('/base/python', ['trl'])[-1], 'trl')
        for names in [[], ['torch'], ['trl', 'torch'], ['trl', 'trl']]:
            with self.assertRaises(RuntimeError): base_remove_command('/base/python', names)

    def test_actual_worker_and_preserved_cache_helpers_import_without_dependency_alias_error(self):
        # Earlier releases import `wheels` by its preserved module name.
        spec = importlib.util.spec_from_file_location('wheels', ROOT.parent / 'wheel_cache_v1/wheels.py')
        wheels = importlib.util.module_from_spec(spec); sys.modules['wheels'] = wheels; spec.loader.exec_module(wheels)
        spec = importlib.util.spec_from_file_location('fixture_cache', ROOT.parent / 'wheel_cache_v1/cache_wheels.py')
        cache = importlib.util.module_from_spec(spec); spec.loader.exec_module(cache)
        spec = importlib.util.spec_from_file_location('fixture_repair', ROOT / 'repair_base.py')
        worker = importlib.util.module_from_spec(spec); spec.loader.exec_module(worker)
        self.assertTrue(callable(cache.validate_plan))
        self.assertTrue(callable(worker.main))


if __name__ == '__main__': unittest.main(verbosity=2)
