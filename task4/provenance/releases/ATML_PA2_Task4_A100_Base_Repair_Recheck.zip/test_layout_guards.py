"""Preserve exact observed duplicates while rejecting drift and ambiguity."""
from collections import Counter
import copy
import json
from pathlib import Path
import unittest

from layout_guards import validate_reviewed_base_inventory, validate_after_layout
from repair_guards import MODIFIED

ROOT = Path(__file__).resolve().parent


class ReviewedLayout(unittest.TestCase):
    def setUp(self):
        self.details = json.loads((ROOT/'REVIEWED_LAYOUT_DETAILS.json').read_text())
        groups = copy.deepcopy(self.details['fresh_duplicate_distribution_entries'])
        for name, version in MODIFIED.items():
            groups[name] = [{'version': version, 'root': '/usr/local/lib/python3.13/dist-packages',
                'metadata_path': '/usr/local/lib/python3.13/dist-packages/'+name+'-'+version+'.dist-info',
                'outside_prefix': False}]
        self.reviewed = {'python': '3.13.15', 'executable': '/usr/bin/python3', 'prefix': '/usr',
            'base_prefix': '/usr', 'user_site_enabled': False,
            'sys_path': ['/usr/local/lib/python3.13/dist-packages', '/usr/lib/python3/dist-packages'],
            'all_distribution_entries': groups,
            'duplicate_distribution_entries': copy.deepcopy(self.details['fresh_duplicate_distribution_entries']),
            'package_versions': {name: entries[-1]['version'] for name, entries in groups.items()},
            'outside_prefix_distribution_entries': {}, 'outside_prefix_site_paths': []}
        self.layout = copy.deepcopy(self.reviewed)
        self.layout['selected_distribution_metadata'] = {name: entries[0] for name,entries in groups.items()}
        self.value = {'python': '3.13.15', 'executable': '/usr/bin/python3', 'prefix': '/usr',
            'base_prefix': '/usr', 'user_site_enabled': False, 'sys_path': self.layout['sys_path'],
            'package_versions': self.layout['package_versions'],
            'duplicate_distributions': list(Counter({name:len(entries)-1
                for name,entries in self.details['fresh_duplicate_distribution_entries'].items()}).elements()),
            'outside_prefix_distributions': [], 'outside_prefix_site_paths': []}

    def validate(self):
        return validate_reviewed_base_inventory(self.value, self.layout, self.reviewed,
                                                self.details, '/usr/bin/python3')

    def test_exact_sixteen_groups_with_differing_versions_are_preserved(self):
        self.assertEqual(self.validate(), self.value['package_versions'])
        self.assertEqual(self.layout['selected_distribution_metadata']['numpy']['version'], '2.1.3')
        self.assertEqual(self.value['package_versions']['numpy'], '1.26.4')

    def test_metadata_selection_cannot_be_assumed_from_last_enumerated_version(self):
        self.layout['selected_distribution_metadata']['numpy'] = self.layout['all_distribution_entries']['numpy'][-1]
        with self.assertRaises(RuntimeError): self.validate()

    def test_new_or_changed_duplicate_group_is_rejected(self):
        for name, value in [('unexpected', [{'version':'1'}]), ('numpy', [{'version':'999'}])]:
            self.setUp()
            self.layout['duplicate_distribution_entries'][name] = value
            with self.assertRaises(RuntimeError): self.validate()

    def test_removed_or_reordered_existing_duplicate_entries_are_rejected(self):
        for entries in [self.layout['duplicate_distribution_entries']['numpy'][:1],
                        list(reversed(self.layout['duplicate_distribution_entries']['numpy']))]:
            self.setUp()
            self.layout['duplicate_distribution_entries']['numpy'] = entries
            with self.assertRaises(RuntimeError): self.validate()

    def test_search_path_outside_prefix_and_interpreter_drift_are_rejected(self):
        for kind in ['search_path', 'outside', 'prefix', 'user_site', 'executable']:
            self.setUp()
            if kind == 'search_path': self.layout['sys_path'] = ['/unexpected']
            if kind == 'outside': self.value['outside_prefix_distributions'] = [{'name':'numpy'}]
            if kind == 'prefix': self.value['prefix'] = '/content/task4_isolated_runtime_v1'
            if kind == 'user_site': self.layout['user_site_enabled'] = True
            if kind == 'executable': self.layout['executable'] = '/other/python'
            with self.subTest(kind=kind), self.assertRaises(RuntimeError): self.validate()

    def test_unrelated_unique_distribution_metadata_path_drift_is_rejected(self):
        self.reviewed['all_distribution_entries']['unchanged'] = [{'version':'1', 'metadata_path':'/original'}]
        self.layout['all_distribution_entries']['unchanged'] = [{'version':'1', 'metadata_path':'/changed'}]
        with self.assertRaises(RuntimeError): self.validate()

    def test_approved_target_must_remain_unique(self):
        self.layout['all_distribution_entries']['peft'] *= 2
        with self.assertRaises(RuntimeError): self.validate()

    def test_post_repair_only_approved_targets_may_change(self):
        after = copy.deepcopy(self.layout)
        jedi = {'version': '0.20.0', 'root':'/usr/local/lib/python3.13/dist-packages',
                'metadata_path':'/usr/local/lib/python3.13/dist-packages/jedi-0.20.0.dist-info', 'outside_prefix':False}
        after['all_distribution_entries']['jedi'] = [jedi]
        after['selected_distribution_metadata']['jedi'] = jedi
        expected = {**self.value['package_versions'], 'jedi':'0.20.0'}
        validate_after_layout(self.layout, after, expected)
        after['selected_distribution_metadata']['numpy'] = copy.deepcopy(after['selected_distribution_metadata']['numpy'])
        after['selected_distribution_metadata']['numpy']['version'] = '999'
        with self.assertRaises(RuntimeError): validate_after_layout(self.layout, after, expected)


if __name__ == '__main__': unittest.main(verbosity=2)
