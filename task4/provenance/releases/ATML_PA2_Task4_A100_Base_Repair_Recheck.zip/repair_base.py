"""Repeat approved conditional base repair with exact reviewed Colab layout guards."""
from datetime import datetime, timezone
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import subprocess

from layout_guards import validate_reviewed_base_inventory, validate_after_layout
from packaging.tags import sys_tags
from packaging.utils import canonicalize_name
from repair_guards import (TOOLS, JEDI, PARSO, require, plan_repair, validate_base_inventory,
                           validate_final_inventory, base_install_command, base_remove_command)

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
EXPERIMENT = Path('/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1')
LOCAL = Path('/content/task4_isolated_runtime_v1')
STAGE1 = '9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65'
RECHECK = '999b26996654587e6ddfda1a146cac4ac38b421f0856f6134abd2ac61433c363'
INSTALL = '7a5673003062448f66a3c43763340483968234f42d2659d517c47d7e33de6e8a'
WHEELS = 'df469ec50f8fc5e493f2f818eb490858c713eb88e3216309aeb43e5fb49a7aab'
GPU = 'd941ecb6c16ec91a942b319167826007f5124b0dedc10d2a337b3b783ff4015b'
ORCHESTRATION = '35ca690761d2bfda0992ff37855b16fc72c03ffd4b47afaa81edc533ab7a5f65'
RECHECK_ATTEMPT = '20261011T155750.714353Z'
WHEEL_ATTEMPT = '20261011T151647.989109Z'
GPU_ATTEMPT = '20261011T142511.766769Z'
ORIGINAL_REPAIR = '76963d33df89cd6439d988bd11808dd503a3724bde6d5c5ef02dec172037b47b'
LAYOUT = '961b9825e7a34823a8f3930e597149c425427d494f8d9c9b10652e5998a734be'
LAYOUT_ATTEMPT = '20261011T162510.009372Z'


def read(path): return json.loads(Path(path).read_text())


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def observed_versions():
    return {canonicalize_name(value.metadata['Name']): value.version for value in metadata.distributions()
            if value.metadata.get('Name')}


def main():
    first = EXPERIMENT / 'preflight_releases' / STAGE1
    require(hashlib.sha256((first / 'MANIFEST.json').read_bytes()).hexdigest() == STAGE1,
            'Original source identity differs')
    require(hashlib.sha256((first / 'scripts/preflight.py').read_bytes()).hexdigest() ==
            read(first / 'MANIFEST.json')['scripts/preflight.py'], 'Original helper differs')
    preflight = load('task4_base_repair_preflight', first / 'scripts/preflight.py')
    digest, save, save_bytes = preflight.sha256, preflight.immutable_json, preflight.immutable_bytes
    preflight.verify_source(first)
    identity = preflight.verify_source(ROOT)['manifest_sha256']
    require(read(EXPERIMENT / 'OWNER.json')['approval_sha256'] == digest(first / 'docs/approval.json'),
            'Original Task 4 ownership differs')
    approval = read(ROOT / 'APPROVAL.json')
    require(approval['approved'] is True and approval['user_message'] == 'approved' and
            'conditional original Colab base restoration and Jedi repair after isolated validation' in approval['approved_scope'] and
            approval['approved_proposal_sha256'] == digest(ROOT / 'APPROVED_PROPOSAL.md') and
            approval['approved_isolated_versions_sha256'] == digest(ROOT / 'APPROVED_ISOLATED_VERSIONS.json') and
            approval['gpu_exceptions_authorized'] is False, 'Conditional repair approval differs')
    release = EXPERIMENT / 'base_repair_recheck_releases' / identity
    for name in [*read(ROOT / 'MANIFEST.json'), 'MANIFEST.json']:
        save_bytes(release / name, (ROOT / name).read_bytes())
    attempt_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    attempt = EXPERIMENT / 'base_repair_recheck_attempts' / attempt_id
    attempt.mkdir(parents=True, exist_ok=False)
    report = {'format': 'ATML_TASK4_BASE_REPAIR_RECHECK_ATTEMPT_V1', 'status': 'RUNNING',
              'attempt_utc': attempt_id, 'source_manifest_sha256': identity,
              'approval_sha256': digest(ROOT / 'APPROVAL.json'), 'commands': [],
              'base_package_mutation_commands_started': [], 'wheel_downloads_performed': False,
              'isolated_package_changes_performed': False, 'kernel_restart_performed': False,
              'pretrained_models_loaded': 0, 'task4_responses_generated': 0,
              'task4_judgments_produced': 0, 'human_labels_assigned': 0,
              'training_performed': False, 'gpu_exceptions_accepted': []}

    def command(argv, name, environment, mutation=False):
        event = {'stage': name, 'argv': [str(value) for value in argv], 'base_mutation': mutation}
        save(attempt / (name + '_command.json'), event)
        if mutation: report['base_package_mutation_commands_started'].append(name)
        print('Task 4 approved base repair:', name, flush=True)
        with (attempt / (name + '.log')).open('x') as log:
            process = subprocess.Popen(event['argv'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                       text=True, bufsize=1, env=environment, cwd='/content')
            for line in process.stdout:
                log.write(line); log.flush(); print(line, end='', flush=True)
            event['returncode'] = process.wait()
        event['log_sha256'] = digest(attempt / (name + '.log'))
        save(attempt / (name + '_result.json'), event)
        report['commands'].append(event)
        require(event['returncode'] == 0, name + ' failed; no further automatic repair is applied')

    try:
        save(attempt / 'START.json', report)
        folders = {}
        for kind, source in [('isolated_recheck', RECHECK), ('isolated_gpu', INSTALL),
                             ('wheel_cache', WHEELS), ('gpu_environment', GPU), ('orchestration', ORCHESTRATION),
                             ('base_repair', ORIGINAL_REPAIR), ('base_layout_diagnostic', LAYOUT)]:
            folder = EXPERIMENT / (kind + '_releases') / source
            require(digest(folder / 'MANIFEST.json') == source, 'Referenced source differs: ' + kind)
            preflight.verify_source(folder)
            folders[kind] = folder
        isolation = load('task4_repair_isolation', folders['isolated_recheck'] / 'isolation.py')
        guards = load('task4_repair_original_guards', folders['isolated_gpu'] / 'guards.py')
        wheels = load('wheels', folders['wheel_cache'] / 'wheels.py')
        cache_module = load('task4_repair_cache', folders['wheel_cache'] / 'cache_wheels.py')
        gates = load('task4_repair_gpu_gates', folders['gpu_environment'] / 'gates.py')
        require(digest(folders['isolated_recheck'] / 'APPROVAL.json') == report['approval_sha256'],
                'Original setup approval differs')

        def verify_report(folder, expected_source, expected_status):
            value = read(folder / 'REPORT.json')
            require(value['source_manifest_sha256'] == expected_source and value['status'] == expected_status and
                    value['gpu_exceptions_accepted'] == [], 'Saved report identity/status differs')
            for name, expected in value['artifact_sha256'].items():
                require(digest(isolation.safe_artifact(folder, name)) == expected,
                        'Saved evidence hash differs: ' + name)
            return value

        diagnostic_folder = EXPERIMENT / 'base_layout_diagnostic_attempts' / LAYOUT_ATTEMPT
        diagnostic = read(diagnostic_folder / 'REPORT.json')
        require(diagnostic['source_manifest_sha256'] == LAYOUT and
                diagnostic['status'] == 'BASE_LAYOUT_DIAGNOSIS_SAVED_REVIEW_PENDING' and
                diagnostic['complete_base_versions_unchanged'] is True and
                diagnostic['metadata_and_paths_unchanged'] is True and
                diagnostic['package_installation_or_removal_performed'] is False and
                diagnostic['repair_guards_changed'] is False and
                diagnostic['dependency_exceptions_accepted'] == [], 'Saved layout diagnosis differs')
        for name, expected in diagnostic['artifact_sha256'].items():
            require(digest(isolation.safe_artifact(diagnostic_folder, name)) == expected,
                    'Saved diagnostic evidence differs: ' + name)
        reviewed_details = read(ROOT / 'REVIEWED_LAYOUT_DETAILS.json')
        require(read(diagnostic_folder / 'LAYOUT_DETAILS_FOR_REVIEW.json') == reviewed_details,
                'Saved layout details differ from user-returned reviewed entries')
        reviewed_layout = read(diagnostic_folder / 'FRESH_BASE_LAYOUT_AFTER_STDOUT.json')
        require(reviewed_layout == read(diagnostic_folder / 'FRESH_BASE_LAYOUT_BEFORE_STDOUT.json'),
                'Diagnostic scans did not preserve the exact layout')
        failed_folder = EXPERIMENT / 'base_repair_attempts' / '20261011T161416.759661Z'
        failed = verify_report(failed_folder, ORIGINAL_REPAIR, 'BASE_REPAIR_FAILED_PRESERVED_REVIEW_REQUIRED')
        require(digest(failed_folder / 'REPORT.json') == diagnostic['original_base_repair_report_sha256'] and
                failed['base_package_mutation_commands_started'] == [] and
                failed['error']['message'] == 'Base distribution paths/duplicates require review',
                'Original no-mutation guard failure differs')
        report.update({'base_layout_diagnostic_report_sha256': digest(diagnostic_folder / 'REPORT.json'),
                       'reviewed_layout_details_sha256': digest(ROOT / 'REVIEWED_LAYOUT_DETAILS.json'),
                       'original_base_repair_report_sha256': digest(failed_folder / 'REPORT.json')})
        previous_folder = EXPERIMENT / 'isolated_recheck_attempts' / RECHECK_ATTEMPT
        previous = verify_report(previous_folder, RECHECK,
                                 'ISOLATED_A100_ENVIRONMENT_VALIDATED_BASE_REPAIR_PENDING')
        require(previous['synthetic_checks_passed'] == 37 and previous['fresh_imports_cuda_and_nf4_passed'] is True and
                previous['isolated_full_dependency_check_passed'] is True and previous['base_package_inventory_unchanged'] is True and
                previous['pretrained_models_loaded'] == 0, 'Isolated success prerequisite is incomplete')
        isolated_path = EXPERIMENT / 'ISOLATED_GPU_ENVIRONMENT_CONTRACT.json'
        policy_path = EXPERIMENT / 'ISOLATED_CHILD_ENVIRONMENT_CONTRACT.json'
        require(digest(isolated_path) == previous['isolated_environment_contract_sha256'] and
                digest(policy_path) == previous['isolated_child_environment_contract_sha256'],
                'Root isolated environment/policy contracts differ')
        contract, policy = read(isolated_path), read(policy_path)
        pins = read(ROOT / 'APPROVED_ISOLATED_VERSIONS.json')
        require(contract['source_manifest_sha256'] == policy['source_manifest_sha256'] == RECHECK and
                contract['installation_source_manifest_sha256'] == INSTALL and
                contract['approval_sha256'] == report['approval_sha256'] and
                contract['isolated_package_versions'] == pins and len(pins) == 84 and
                contract['isolated_child_environment_policy'] == policy and contract['gpu_exceptions_accepted'] == [] and
                contract['synthetic_semantic_checks_passed'] == 37 and
                contract['python_executable'] == str(LOCAL / 'bin/python') and
                contract['environment_directory'] == str(LOCAL), 'Isolated contract fields differ')
        require(policy['additional_variable_removed_only_from_child'] == 'MPLBACKEND' and
                policy['recognized_removed_value'] == isolation.NOTEBOOK_BACKEND and
                policy['original_sanitizer_source_manifest_sha256'] == INSTALL and
                policy['replacement_backend_forced'] is False and policy['parent_environment_modified'] is False,
                'Child environment policy differs')
        require(LOCAL.is_dir() and not LOCAL.is_symlink(), 'Owned isolated environment is missing; keep the same A100 runtime')
        owner = read(LOCAL / '.task4_isolation_owner.json')
        wheelhouse = EXPERIMENT / 'environment_wheelhouse'
        wheel_contract_path = wheelhouse / 'VERIFIED_WHEELHOUSE_CONTRACT.json'
        require(owner['source_manifest_sha256'] == INSTALL and owner['directory'] == str(LOCAL) and
                owner['approval_sha256'] == report['approval_sha256'] and
                owner['wheelhouse_contract_sha256'] == digest(wheel_contract_path) == contract['wheelhouse_contract_sha256'] and
                owner['system_site_packages'] is False, 'Local environment ownership differs')
        protocol_path = EXPERIMENT / 'CPU_ORCHESTRATION_VALIDATION_CONTRACT.json'
        require(digest(protocol_path) == contract['cpu_orchestration_contract_sha256'] and
                read(protocol_path)['source_manifest_sha256'] == ORCHESTRATION and
                digest(EXPERIMENT / 'CPU_MODEL_INPUT_CONTRACT.json') == contract['model_input_contract_sha256'] ==
                read(protocol_path)['model_input_contract_sha256'], 'Frozen evaluation/model inputs differ')
        report.update({'isolated_recheck_report_sha256': digest(previous_folder / 'REPORT.json'),
                       'isolated_environment_contract_sha256': digest(isolated_path),
                       'isolated_child_environment_contract_sha256': digest(policy_path),
                       'cpu_orchestration_contract_sha256': digest(protocol_path)})
        parent_backend = os.environ.get('MPLBACKEND')
        base_env = guards.clean_environment(os.environ)
        isolated_env = isolation.child_environment(os.environ, guards.clean_environment)
        kernel = read(sys.argv[1])
        require(type(kernel['pid']) is int and kernel['pid'] > 0, 'Notebook observation differs')
        save(attempt / 'NOTEBOOK_KERNEL_OBSERVATION.json', kernel)
        save(attempt / 'PROCESS_ENVIRONMENT_POLICY.json', {'parent_mplbackend': parent_backend,
             'base_child_mplbackend': base_env.get('MPLBACKEND'),
             'isolated_child_mplbackend': isolated_env.get('MPLBACKEND'),
             'base_and_parent_backend_preserved': True, 'isolated_policy_sha256': digest(policy_path)})
        command(['nvidia-smi', '--query-gpu=name,memory.total,driver_version,uuid',
                 '--format=csv,noheader,nounits'], 'nvidia_inventory', base_env)
        hardware = gates.parse_a100_inventory((attempt / 'nvidia_inventory.log').read_text())
        require(hardware == read(previous_folder / 'A100_HARDWARE.json'), 'A100 hardware/runtime changed')
        save(attempt / 'A100_HARDWARE.json', hardware)
        inspect = folders['isolated_gpu'] / 'inspect_python.py'
        isolated_python = LOCAL / 'bin/python'
        command([isolated_python, '-I', '-B', inspect, attempt / 'ISOLATED_INVENTORY_BEFORE.json'],
                'inspect_isolated_before', isolated_env)
        isolated_before = read(attempt / 'ISOLATED_INVENTORY_BEFORE.json')
        guards.validate_inventory(isolated_before, pins, LOCAL, complete=True)
        require(isolated_before['python'] == owner['target_python_full_version'] == contract['python'],
                'Isolated Python version changed')
        command([isolated_python, '-I', '-B', '-m', 'pip', '--disable-pip-version-check', 'check'],
                'isolated_dependency_check_before', isolated_env)
        command([sys.executable, '-I', '-B', inspect, attempt / 'BASE_INVENTORY_BEFORE.json'],
                'inspect_base_before', base_env)
        base_before = read(attempt / 'BASE_INVENTORY_BEFORE.json')
        command([sys.executable, '-I', '-B', ROOT / 'scan_base_layout.py',
                 folders['base_layout_diagnostic'] / 'scan_layout.py', attempt / 'BASE_LAYOUT_BEFORE.json'],
                'inspect_reviewed_base_layout_before', base_env)
        base_layout_before = read(attempt / 'BASE_LAYOUT_BEFORE.json')
        current = validate_reviewed_base_inventory(base_before, base_layout_before, reviewed_layout,
                                                   reviewed_details, owner['base_python_executable'])
        require(base_before['python'] == owner['target_python_full_version'], 'Base Python identity differs')
        wheel_attempt = EXPERIMENT / 'wheel_cache_attempts' / WHEEL_ATTEMPT
        wheel_report = verify_report(wheel_attempt, WHEELS, 'CPU_WHEEL_CACHE_VERIFIED_NO_INSTALLATION')
        require(wheel_report['verified_wheelhouse_contract_sha256'] == digest(wheel_contract_path),
                'Saved wheelhouse contract differs')
        wheel_contract = read(wheel_contract_path)
        require(wheel_contract['all_wheels_verified'] is True and wheel_contract['source_manifest_sha256'] == WHEELS and
                wheel_contract['approval_sha256'] == report['approval_sha256'] and
                wheel_contract['cache_identity_contract_sha256'] == digest(wheelhouse / 'CACHE_IDENTITY_CONTRACT.json'),
                'Wheelhouse binding differs')
        plan_path = wheel_attempt / 'APPROVED_ISOLATION_PROPOSAL.json'
        require(digest(plan_path) == wheel_contract['isolation_proposal_sha256'], 'Approved proposal differs')
        plan = read(plan_path)
        files = cache_module.validate_plan(plan, pins, list(sys_tags()), base_before['python'])
        require(files == wheel_contract['files'], 'Approved binary identities differ')
        gpu_attempt = EXPERIMENT / 'gpu_environment_attempts' / GPU_ATTEMPT
        verify_report(gpu_attempt, GPU, 'GPU_ENVIRONMENT_REVIEW_REQUIRED')
        require(digest(gpu_attempt / 'REPORT.json') == plan['original_gpu_report_sha256'],
                'Original base change evidence differs')
        planned = plan_repair(current, read(previous_folder / 'BASE_PACKAGE_VERSIONS_AFTER.json'),
                              read(gpu_attempt / 'PACKAGE_VERSIONS_BEFORE.json'),
                              read(gpu_attempt / 'PACKAGE_VERSIONS_AFTER.json'),
                              read(gpu_attempt / 'PACKAGE_CHANGES.json'), plan['colab_base_repair_proposal'])
        save(attempt / 'VALIDATED_CONDITIONAL_REPAIR_PLAN.json', planned)
        save(attempt / 'EXPECTED_BASE_TOOLS.json', {**TOOLS, 'jedi': JEDI, 'parso': PARSO})
        prior_base_contract = None
        base_contract_path = EXPERIMENT / 'COLAB_BASE_REPAIR_CONTRACT.json'
        if base_contract_path.exists():
            prior_base_contract = read(base_contract_path)
            require(prior_base_contract['source_manifest_sha256'] == identity and
                    prior_base_contract['approval_sha256'] == report['approval_sha256'] and
                    prior_base_contract['isolated_environment_contract_sha256'] == digest(isolated_path) and
                    prior_base_contract['isolated_child_environment_contract_sha256'] == digest(policy_path) and
                    prior_base_contract['complete_base_package_versions'] == current == planned['expected_complete_base_versions'],
                    'Existing completed base repair contract differs; it will not be replaced')
        print('Exact base versions to install:', json.dumps(planned['install_exact_versions']), flush=True)
        print('Approved global copies to remove:', planned['remove_exact_global_names'], flush=True)
        wheels_dir = wheelhouse / 'wheels'
        require(not wheelhouse.is_symlink() and not wheels_dir.is_symlink(), 'Wheel directory symlink differs')
        selected = {}
        logical_bytes = 0
        for name, version in planned['install_exact_versions'].items():
            matches = [value for value in files.values() if value['package'] == name and value['version'] == version]
            require(len(matches) == 1, 'Exact base wheel missing/duplicated: ' + name)
            record = matches[0]
            checked = wheels.verify_file(wheels_dir / record['filename'], record)
            require(checked == wheel_contract['verified_files'][record['filename']] ==
                    read(wheelhouse / 'receipts' / (record['filename'] + '.json')), 'Base wheel receipt differs')
            inspected = wheels.inspect_wheel(wheels_dir / record['filename'], record, list(sys_tags()), base_before['python'])
            require(inspected == wheel_contract['wheel_inspections'][record['filename']], 'Base wheel METADATA differs')
            logical_bytes += inspected['zip_uncompressed_file_bytes']
            selected[record['filename']] = record
        save(attempt / 'VERIFIED_BASE_INSTALL_WHEELS.json', selected)
        space = {'logical_unpacked_bytes': logical_bytes, 'free_bytes_before': shutil.disk_usage('/content').free,
                 'required_free_bytes': 2 * logical_bytes}
        require(space['free_bytes_before'] >= space['required_free_bytes'], 'Insufficient base repair disk space')
        save(attempt / 'BASE_REPAIR_SPACE_CHECK.json', space)
        # All provenance/inventories/selected wheel bytes pass before either mutation.
        require(observed_versions() == current, 'Base versions changed while preflight was running')
        if planned['remove_exact_global_names']:
            command(base_remove_command(sys.executable, planned['remove_exact_global_names']),
                    'remove_only_approved_global_additions', base_env, mutation=True)
        if planned['install_exact_versions']:
            requirements = attempt / 'OFFLINE_HASHED_BASE_REQUIREMENTS.txt'
            save_bytes(requirements, guards.requirement_lines(selected, planned['install_exact_versions'], wheels_dir).encode())
            command(base_install_command(sys.executable, requirements, attempt / 'BASE_INSTALL_REPORT.json'),
                    'restore_only_approved_base_versions', base_env, mutation=True)
        command([sys.executable, '-I', '-B', inspect, attempt / 'BASE_INVENTORY_AFTER.json'],
                'inspect_base_after', base_env)
        base_after = read(attempt / 'BASE_INVENTORY_AFTER.json')
        command([sys.executable, '-I', '-B', ROOT / 'scan_base_layout.py',
                 folders['base_layout_diagnostic'] / 'scan_layout.py', attempt / 'BASE_LAYOUT_AFTER.json'],
                'inspect_reviewed_base_layout_after', base_env)
        base_layout_after = read(attempt / 'BASE_LAYOUT_AFTER.json')
        after = validate_reviewed_base_inventory(base_after, base_layout_after, reviewed_layout,
                                                 reviewed_details, owner['base_python_executable'])
        validate_after_layout(base_layout_before, base_layout_after, planned['expected_complete_base_versions'])
        changes = validate_final_inventory(current, after, planned)
        save(attempt / 'VERIFIED_BASE_PACKAGE_CHANGES.json', changes)
        command([sys.executable, '-I', '-B', '-m', 'pip', '--disable-pip-version-check', 'check'],
                'base_full_dependency_check', base_env)
        require((attempt / 'base_full_dependency_check.log').read_text().strip() == 'No broken requirements found.',
                'A clean full base dependency check is required; no exceptions are accepted')
        command([sys.executable, '-I', '-B', '-u', ROOT / 'probe_base.py', attempt / 'EXPECTED_BASE_TOOLS.json',
                 attempt / 'BASE_TOOLS_PROBE.json', attempt / 'BASE_LAYOUT_AFTER.json'], 'fresh_base_tools_and_completion', base_env)
        command([isolated_python, '-I', '-B', inspect, attempt / 'ISOLATED_INVENTORY_AFTER.json'],
                'inspect_isolated_after', isolated_env)
        isolated_after = read(attempt / 'ISOLATED_INVENTORY_AFTER.json')
        guards.validate_inventory(isolated_after, pins, LOCAL, complete=True)
        require(isolated_after == isolated_before, 'Base repair affected the isolated interpreter')
        command([isolated_python, '-I', '-B', '-m', 'pip', '--disable-pip-version-check', 'check'],
                'isolated_dependency_check_after', isolated_env)
        require(observed_versions() == after and os.environ.get('MPLBACKEND') == parent_backend and
                digest(isolated_path) == report['isolated_environment_contract_sha256'] and
                digest(policy_path) == report['isolated_child_environment_contract_sha256'],
                'Inventory/backend/original isolated contracts changed unexpectedly')
        # Reruns preserve the original restart requirement until the separate
        # post-restart validation block records that it has been satisfied.
        restart = (prior_base_contract['base_kernel_restart_required'] if prior_base_contract is not None
                   else planned['package_changes_needed'])
        repaired = {'format': 'ATML_TASK4_COLAB_BASE_REPAIR_CONTRACT_V2', 'source_manifest_sha256': identity,
                    'approval_sha256': report['approval_sha256'], 'isolated_recheck_source_manifest_sha256': RECHECK,
                    'isolated_environment_contract_sha256': digest(isolated_path),
                    'isolated_child_environment_contract_sha256': digest(policy_path),
                    'wheelhouse_contract_sha256': digest(wheel_contract_path),
                    'python_executable': sys.executable, 'python': base_after['python'],
                    'complete_base_package_versions': after,
                    'complete_base_package_versions_meaning': base_layout_after['legacy_version_map_meaning'],
                    'effective_metadata_versions': base_layout_after['effective_metadata_versions'],
                    'reviewed_duplicate_distribution_entries': reviewed_details['fresh_duplicate_distribution_entries'],
                    'reviewed_base_search_path': reviewed_layout['sys_path'],
                    'base_layout_diagnostic_report_sha256': report['base_layout_diagnostic_report_sha256'],
                    'reviewed_layout_details_sha256': report['reviewed_layout_details_sha256'],
                    'exact_reviewed_base_layout_preserved': True,
                    'fresh_numpy_packaging_imports_match_selected_metadata': True,
                    'base_full_dependency_check_passed': True,
                    'fresh_ipython_jedi_gradio_diffusers_imports_passed': True,
                    'jedi_completion_passed': True, 'isolated_exact_packages_preserved': 84,
                    'isolated_full_dependency_check_passed_after_repair': True,
                    'gpu_exceptions_accepted': [], 'base_kernel_restart_required': restart,
                    'post_restart_or_next_block_both_interpreters_recheck_pending': True,
                    'pretrained_models_loaded': 0, 'gpu_model_loading_validation_pending': True}
        save(base_contract_path, repaired)
        report.update({'status': 'BASE_REPAIRED_FRESH_VALIDATION_PASSED_RESTART_PENDING' if restart else
                                'BASE_ALREADY_MATCHED_FRESH_VALIDATION_PASSED_RECHECK_PENDING',
                       'base_full_dependency_check_passed': True, 'fresh_base_tool_imports_and_completion_passed': True,
                       'verified_base_changes': changes, 'isolated_84_packages_unchanged': True,
                       'reviewed_duplicate_groups_preserved': 16, 'actual_named_metadata_selection_recorded': True,
                       'base_repair_contract_sha256': digest(EXPERIMENT / 'COLAB_BASE_REPAIR_CONTRACT.json'),
                       'base_kernel_restart_required': restart, 'both_interpreters_next_recheck_pending': True})
        print('Exact reviewed Colab duplicate layout preserved: 16 groups; no outside-prefix paths.', flush=True)
        print('Full base dependency check PASS; fresh tools/Jedi completion PASS.', flush=True)
        print('Isolated environment preserved: 84/84; full dependency check PASS.', flush=True)
        print('Base kernel restart required:', restart, flush=True)
        print('Return this output first. Keep A100 connected; do not factory-reset or disconnect/delete the runtime.', flush=True)
        print('Next reviewed block: restart if needed, then recheck both interpreters before model validation.', flush=True)
        print('Responses 0/1800; judgments 0/1800; human labels 0/240. No pretrained models loaded.', flush=True)
    except BaseException as error:
        report.update({'status': 'BASE_REPAIR_FAILED_PRESERVED_REVIEW_REQUIRED',
                       'error': {'type': type(error).__name__, 'message': str(error)},
                       'automatic_additional_repair_applied': False})
        raise
    finally:
        save(attempt / 'BASE_VERSIONS_OBSERVED_AT_EXIT.json', observed_versions())
        report['artifact_sha256'] = {p.relative_to(attempt).as_posix(): digest(p) for p in attempt.rglob('*') if p.is_file()}
        save(attempt / 'REPORT.json', report)
        print('Saved base repair report:', attempt / 'REPORT.json', flush=True)
        print('Status:', report['status'], flush=True)


if __name__ == '__main__': main()
