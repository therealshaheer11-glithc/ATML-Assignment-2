"""Reuse the sealed scanner and record actual named metadata selection."""
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import sys


def main():
    spec = importlib.util.spec_from_file_location('task4_original_layout_scanner', sys.argv[1])
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    value = module.collect()
    selected = {}
    for name in value['all_distribution_entries']:
        distribution = metadata.distribution(name)
        root = Path(distribution.locate_file('')).resolve()
        info = getattr(distribution, '_path', None)
        selected[name] = {'version': distribution.version, 'root': str(root),
                          'metadata_path': None if info is None else str(Path(info).resolve()),
                          'outside_prefix': not root.is_relative_to(Path(sys.prefix).resolve())}
    value['selected_distribution_metadata'] = selected
    value['effective_metadata_versions'] = {name: entry['version'] for name, entry in selected.items()}
    value['legacy_version_map_meaning'] = 'Last enumerated metadata version per canonical distribution name; historical comparison only, not necessarily the selected distribution.'
    with Path(sys.argv[2]).open('x') as stream: json.dump(value, stream, indent=2); stream.write('\n')
    print('Fresh base layout:', len(value['package_versions']), 'names;',
          len(value['duplicate_distribution_entries']), 'preserved duplicate groups.', flush=True)
    print('Named metadata selection for duplicate groups:',
          json.dumps({name: selected[name] for name in value['duplicate_distribution_entries']}, indent=2), flush=True)


if __name__ == '__main__': main()
