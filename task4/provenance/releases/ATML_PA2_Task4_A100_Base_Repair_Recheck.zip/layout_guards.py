"""Preserve the exact observed Colab layout, without relaxing venv checks."""
from collections import Counter
from pathlib import Path

from repair_guards import MUTABLE, require


def validate_reviewed_base_inventory(value, layout, reviewed, details, base_executable):
    require(value['prefix'] == value['base_prefix'] == layout['prefix'] == layout['base_prefix'] == reviewed['prefix'],
            'Base interpreter prefix changed or is a virtual environment')
    require(str(Path(value['executable']).resolve()) == str(Path(layout['executable']).resolve()) ==
            str(Path(base_executable).resolve()), 'Base interpreter differs from owned installation')
    require(value['python'] == layout['python'] == reviewed['python'] and
            value['user_site_enabled'] is False and layout['user_site_enabled'] is False,
            'Base Python/user-site isolation changed')
    require(not value['outside_prefix_distributions'] and not value['outside_prefix_site_paths'] and
            not layout['outside_prefix_distribution_entries'] and not layout['outside_prefix_site_paths'],
            'Unexpected outside-prefix distribution/site path')
    require(layout['sys_path'] == reviewed['sys_path'] == value['sys_path'], 'Base search path changed')
    expected = details['fresh_duplicate_distribution_entries']
    require(len(expected) == 16 and not set(expected) & MUTABLE and
            expected == reviewed['duplicate_distribution_entries'] == layout['duplicate_distribution_entries'],
            'Observed duplicate entries changed; only the exact reviewed layout is allowed')
    require(details['base_prefix'] == value['prefix'] and
            details['fresh_outside_prefix_distribution_entries'] == {} and
            details['fresh_outside_prefix_site_paths'] == [], 'Reviewed diagnostic details differ')
    require(Counter(value['duplicate_distributions']) == Counter({name: len(entries)-1 for name, entries in expected.items()}),
            'Legacy duplicate inventory disagrees with the detailed scan')
    require(value['package_versions'] == layout['package_versions'], 'Legacy and detailed version inventories disagree')
    for name in set(layout['all_distribution_entries']) | set(reviewed['all_distribution_entries']):
        entries = layout['all_distribution_entries'].get(name, [])
        if name not in MUTABLE:
            require(entries == reviewed['all_distribution_entries'].get(name, []),
                    'Unrelated distribution metadata/path changed: ' + name)
        else:
            require(len(entries) <= 1, 'Repair target has ambiguous duplicate metadata: ' + name)
        if entries:
            # Compare actual named metadata discovery, not a last-writer dict.
            require(layout['selected_distribution_metadata'][name] == entries[0],
                    'Named metadata selection differs from reviewed path order: ' + name)
    require(not Path(value['prefix']).is_relative_to('/content/task4_isolated_runtime_v1'),
            'Base repair would target the isolated environment')
    return value['package_versions']


def validate_after_layout(before, after, expected_versions):
    require(before['sys_path'] == after['sys_path'] and
            before['duplicate_distribution_entries'] == after['duplicate_distribution_entries'],
            'Base repair changed the observed search path or duplicate metadata')
    for name in set(before['all_distribution_entries']) | set(after['all_distribution_entries']):
        old, new = before['all_distribution_entries'].get(name), after['all_distribution_entries'].get(name)
        if name not in MUTABLE:
            require(old == new and before['selected_distribution_metadata'][name] == after['selected_distribution_metadata'][name],
                    'Base repair changed unrelated metadata/selection: ' + name)
        else:
            wanted = expected_versions.get(name)
            require((new is None and wanted is None) or
                    (new is not None and len(new) == 1 and new[0]['version'] == wanted and
                     after['selected_distribution_metadata'][name] == new[0]),
                    'Approved target metadata does not match planned final inventory: ' + name)
