"""Enforce exactly the reviewed conditional Colab base changes."""
from pathlib import Path

RESTORE = {'huggingface-hub': '1.33.0', 'peft': '0.21.1',
           'tokenizers': '0.23.2', 'transformers': '5.18.0'}
MODIFIED = {'huggingface-hub': '0.36.2', 'peft': '0.17.1',
            'tokenizers': '0.22.1', 'transformers': '4.57.1'}
ADDED = {'bitsandbytes': '0.50.2', 'trl': '0.27.2'}
TOOLS = {'ipython': '7.34.0', 'diffusers': '0.40.0', 'gradio': '6.29.0'}
JEDI = '0.20.0'
PARSO = '0.8.7'
MUTABLE = set(RESTORE) | set(ADDED) | {'jedi'}


def require(condition, message):
    if not condition: raise RuntimeError(message)


def plan_repair(current, saved_baseline, original, modified, recorded_changes, proposal):
    actual_changes = {name: {'before': original.get(name), 'after': modified.get(name)}
                      for name in sorted(set(original) | set(modified))
                      if original.get(name) != modified.get(name)}
    expected_changes = {name: {'before': RESTORE[name], 'after': MODIFIED[name]} for name in RESTORE}
    expected_changes.update({name: {'before': None, 'after': version} for name, version in ADDED.items()})
    require(actual_changes == recorded_changes == expected_changes,
            'Original recorded global changes differ from the approved six packages')
    require(proposal['restore_original_versions_if_still_modified'] == RESTORE and
            proposal['remove_only_course_added_global_packages_after_isolated_environment_passes'] == sorted(ADDED) and
            proposal['proposed_add_or_change_base_packages'] == {'jedi': JEDI} and
            proposal['preserve_colab_tools'] == TOOLS,
            'Saved conditional repair proposal differs')
    require(set(proposal['jedi_dependencies']) == {'parso'} and
            proposal['jedi_dependencies']['parso']['original_version'] == PARSO and
            proposal['jedi_dependencies']['parso']['proposed_version'] == PARSO,
            'A Parso change was not approved')
    for name in set(current) | set(saved_baseline):
        if name not in MUTABLE:
            require(current.get(name) == saved_baseline.get(name),
                    'Unexpected base inventory drift requires review: ' + name)
    for name, version in TOOLS.items():
        require(current.get(name) == original.get(name) == version, 'Colab tool version differs: ' + name)
    require(current.get('parso') == original.get('parso') == PARSO, 'Existing Parso differs')
    require(current.get('torch') == original.get('torch') == modified.get('torch') == '2.11.0+cu130',
            'Global CUDA Torch must remain unchanged')
    installs, removals = {}, []
    for name, version in RESTORE.items():
        require(current.get(name) in {version, MODIFIED[name]},
                'Unknown modified base version requires review: ' + name)
        if current[name] != version: installs[name] = version
    for name, version in ADDED.items():
        require(current.get(name) in {None, version}, 'Unknown global addition requires review: ' + name)
        if name in current: removals.append(name)
    require(current.get('jedi') in {None, JEDI}, 'Unknown Jedi version requires review')
    if 'jedi' not in current: installs['jedi'] = JEDI
    expected = dict(current)
    for name in ADDED: expected.pop(name, None)
    expected.update(RESTORE)
    expected['jedi'] = JEDI
    return {'install_exact_versions': dict(sorted(installs.items())), 'remove_exact_global_names': sorted(removals),
            'expected_complete_base_versions': dict(sorted(expected.items())),
            'package_changes_needed': bool(installs or removals)}


def validate_base_inventory(value, base_executable):
    require(value['prefix'] == value['base_prefix'], 'Repair interpreter is a virtual environment')
    require(str(Path(value['executable']).resolve()) == str(Path(base_executable).resolve()),
            'Base interpreter differs from the owned installation')
    require(not value['duplicate_distributions'] and not value['outside_prefix_distributions'] and
            not value['outside_prefix_site_paths'], 'Base distribution paths/duplicates require review')
    require(not Path(value['prefix']).is_relative_to('/content/task4_isolated_runtime_v1'),
            'Base repair would target the isolated environment')
    return value['package_versions']


def validate_final_inventory(before, after, planned):
    require(after == planned['expected_complete_base_versions'],
            'Post-repair versions differ; additional repairs require review')
    changes = {name: {'before': before.get(name), 'after': after.get(name)}
               for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)}
    require(set(changes) <= MUTABLE, 'A package outside the approved repair changed')
    return changes


def base_install_command(python, requirements, report):
    return [str(python), '-I', '-B', '-m', 'pip', '--disable-pip-version-check', '--no-cache-dir',
            'install', '--no-index', '--no-deps', '--only-binary=:all:', '--require-hashes',
            '--report', str(report), '-r', str(requirements)]


def base_remove_command(python, names):
    require(bool(names) and len(names) == len(set(names)) and set(names) <= set(ADDED),
            'Only the two approved course-added global packages may be removed')
    return [str(python), '-I', '-B', '-m', 'pip', '--disable-pip-version-check', 'uninstall', '--yes', *sorted(names)]
