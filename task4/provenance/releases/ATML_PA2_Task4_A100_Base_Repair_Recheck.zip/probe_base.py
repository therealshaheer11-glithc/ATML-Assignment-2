"""Fresh-process validation of the restored notebook tools, without model loading."""
import importlib
import importlib.metadata as metadata
import json
from pathlib import Path
import platform
import sys


def main():
    expected = json.loads(Path(sys.argv[1]).read_text())
    modules = {}
    for package, module_name in [('ipython', 'IPython'), ('jedi', 'jedi'), ('parso', 'parso'),
                                 ('gradio', 'gradio'), ('diffusers', 'diffusers')]:
        module = importlib.import_module(module_name)
        version = metadata.version(package)
        if version != expected[package]: raise RuntimeError('Fresh Colab tool version differs: ' + package)
        modules[package] = {'version': version, 'module_file': str(Path(module.__file__).resolve())}
        print('Fresh base import PASS:', package, version, flush=True)
    jedi = importlib.import_module('jedi')
    completions = jedi.Script("task4_text = 'verified'\ntask4_text.up").complete(2, len('task4_text.up'))
    if 'upper' not in {value.name for value in completions}:
        raise RuntimeError('Jedi completion check failed')
    layout = json.loads(Path(sys.argv[3]).read_text())
    selected_imports = {}
    for name in ['numpy', 'packaging']:
        module = importlib.import_module(name)
        chosen = layout['selected_distribution_metadata'][name]
        actual_version = str(module.__version__)
        location = Path(module.__file__).resolve()
        if actual_version != chosen['version'] or not location.is_relative_to(Path(chosen['root']).resolve()):
            raise RuntimeError('Fresh base module differs from selected metadata: ' + name)
        selected_imports[name] = {'version': actual_version, 'module_file': str(location)}
        print('Fresh base selected module PASS:', name, actual_version, flush=True)
    result = {'format': 'ATML_TASK4_BASE_TOOLS_PROBE_V2', 'python': platform.python_version(),
              'executable': sys.executable, 'fresh_tool_imports': modules,
              'jedi_string_upper_completion_passed': True,
              'fresh_numpy_packaging_match_selected_metadata': selected_imports, 'pretrained_models_loaded': 0,
              'training_performed': False}
    with Path(sys.argv[2]).open('x') as stream: json.dump(result, stream, indent=2); stream.write('\n')
    print('Fresh IPython/Jedi, Gradio, Diffusers imports and Jedi completion PASS.', flush=True)


if __name__ == '__main__': main()
