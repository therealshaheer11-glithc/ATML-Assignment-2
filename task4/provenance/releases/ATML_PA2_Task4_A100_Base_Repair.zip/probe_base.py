"""Fresh-process validation of the restored notebook tools, without model loading."""
import importlib
import importlib.metadata as metadata
import json
from pathlib import Path
import platform
import sys


def main():
    expected = json.loads(Path(sys.argv[1]).read_text())
    modules = {}
    for package, module_name in [('ipython', 'IPython'), ('jedi', 'jedi'), ('parso', 'parso'),
                                 ('gradio', 'gradio'), ('diffusers', 'diffusers')]:
        module = importlib.import_module(module_name)
        version = metadata.version(package)
        if version != expected[package]: raise RuntimeError('Fresh Colab tool version differs: ' + package)
        modules[package] = {'version': version, 'module_file': str(Path(module.__file__).resolve())}
        print('Fresh base import PASS:', package, version, flush=True)
    jedi = importlib.import_module('jedi')
    completions = jedi.Script("task4_text = 'verified'\ntask4_text.up").complete(2, len('task4_text.up'))
    if 'upper' not in {value.name for value in completions}:
        raise RuntimeError('Jedi completion check failed')
    result = {'format': 'ATML_TASK4_BASE_TOOLS_PROBE_V1', 'python': platform.python_version(),
              'executable': sys.executable, 'fresh_tool_imports': modules,
              'jedi_string_upper_completion_passed': True, 'pretrained_models_loaded': 0,
              'training_performed': False}
    with Path(sys.argv[2]).open('x') as stream: json.dump(result, stream, indent=2); stream.write('\n')
    print('Fresh IPython/Jedi, Gradio, Diffusers imports and Jedi completion PASS.', flush=True)


if __name__ == '__main__': main()
