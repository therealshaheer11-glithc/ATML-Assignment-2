"""Read-only both-interpreter validation after the approved base kernel restart."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

from kernel_guards import require, validate_kernel

ROOT=Path(__file__).resolve().parent
EXPERIMENT=Path('/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1')
LOCAL=Path('/content/task4_isolated_runtime_v1')
SOURCES={
 'preflight':'9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65',
 'isolated_gpu':'7a5673003062448f66a3c43763340483968234f42d2659d517c47d7e33de6e8a',
 'isolated_recheck':'999b26996654587e6ddfda1a146cac4ac38b421f0856f6134abd2ac61433c363',
 'base_repair_recheck':'4955a6f76dfbfc5b2f92825fce309eabbe4c209cf576b73a7d182ff0b101f09a',
 'base_layout_diagnostic':'961b9825e7a34823a8f3930e597149c425427d494f8d9c9b10652e5998a734be',
 'gpu_environment':'d941ecb6c16ec91a942b319167826007f5124b0dedc10d2a337b3b783ff4015b',
 'orchestration':'35ca690761d2bfda0992ff37855b16fc72c03ffd4b47afaa81edc533ab7a5f65',
 'diagnostic':'71bdb7fdbe130c5adaef8328437371bcd89621d0a93e849bab61b7db8491c540'}
REPAIR_ATTEMPT='20261011T164024.510450Z'


def read(path):return json.loads(Path(path).read_text())


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    spec.loader.exec_module(module)
    return module


def main():
    first=EXPERIMENT/'preflight_releases'/SOURCES['preflight']
    require(hashlib.sha256((first/'MANIFEST.json').read_bytes()).hexdigest()==SOURCES['preflight'],
            'Original source identity differs')
    require(hashlib.sha256((first/'scripts/preflight.py').read_bytes()).hexdigest()==
            read(first/'MANIFEST.json')['scripts/preflight.py'],'Original helper differs')
    preflight=load('task4_post_restart_preflight',first/'scripts/preflight.py')
    digest,save,save_bytes=preflight.sha256,preflight.immutable_json,preflight.immutable_bytes
    preflight.verify_source(first)
    identity=preflight.verify_source(ROOT)['manifest_sha256']
    require(read(EXPERIMENT/'OWNER.json')['approval_sha256']==digest(first/'docs/approval.json'),'Task owner differs')
    release=EXPERIMENT/'post_restart_releases'/identity
    for name in [*read(ROOT/'MANIFEST.json'),'MANIFEST.json']:save_bytes(release/name,(ROOT/name).read_bytes())
    attempt_id=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    attempt=EXPERIMENT/'post_restart_attempts'/attempt_id
    attempt.mkdir(parents=True,exist_ok=False)
    report={'format':'ATML_TASK4_POST_RESTART_ATTEMPT_V1','status':'RUNNING',
            'attempt_utc':attempt_id,'source_manifest_sha256':identity,'commands':[],
            'package_installation_or_removal_performed':False,'downloads_performed':False,
            'virtual_environment_created':False,'kernel_restart_performed_by_this_block':False,
            'pretrained_models_loaded':0,'task4_responses_generated':0,
            'task4_judgments_produced':0,'human_labels_assigned':0,
            'training_performed':False,'gpu_exceptions_accepted':[]}

    def command(argv,name,env):
        event={'stage':name,'argv':[str(value) for value in argv]}
        save(attempt/(name+'_COMMAND.json'),event)
        print('Task 4 post-restart validation:',name,flush=True)
        with (attempt/(name+'.log')).open('x') as log:
            process=subprocess.Popen(event['argv'],cwd='/content',env=env,stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT,text=True,bufsize=1)
            for line in process.stdout:log.write(line);log.flush();print(line,end='',flush=True)
            event['returncode']=process.wait()
        event['log_sha256']=digest(attempt/(name+'.log'))
        save(attempt/(name+'_RESULT.json'),event)
        report['commands'].append(event)
        require(event['returncode']==0,name+' failed; no automatic repair or fallback is applied')

    try:
        save(attempt/'START.json',report)
        folders={}
        for kind,source in SOURCES.items():
            folder=EXPERIMENT/(kind+'_releases')/source
            require(digest(folder/'MANIFEST.json')==source,'Referenced sealed source differs: '+kind)
            preflight.verify_source(folder)
            folders[kind]=folder
        original=load('task4_post_restart_isolation',folders['isolated_gpu']/'guards.py')
        isolation=load('task4_post_restart_artifacts',folders['isolated_recheck']/'isolation.py')
        load('repair_guards',folders['base_repair_recheck']/'repair_guards.py')
        layout_guards=load('task4_post_restart_layout',folders['base_repair_recheck']/'layout_guards.py')
        gates=load('task4_post_restart_gpu_gates',folders['gpu_environment']/'gates.py')
        approval=read(ROOT/'APPROVAL.json')
        require(approval['approved'] is True and approval['user_message']=='approved' and
                approval['gpu_exceptions_authorized'] is False and
                approval['approved_proposal_sha256']==digest(ROOT/'APPROVED_PROPOSAL.md') and
                approval['approved_isolated_versions_sha256']==digest(ROOT/'APPROVED_ISOLATED_VERSIONS.json') and
                digest(ROOT/'APPROVAL.json')==digest(folders['base_repair_recheck']/'APPROVAL.json'),
                'Inherited setup/restart validation approval differs')
        report['approval_sha256']=digest(ROOT/'APPROVAL.json')
        repair_folder=EXPERIMENT/'base_repair_recheck_attempts'/REPAIR_ATTEMPT
        previous=read(repair_folder/'REPORT.json')
        require(previous['source_manifest_sha256']==SOURCES['base_repair_recheck'] and
                previous['status']=='BASE_REPAIRED_FRESH_VALIDATION_PASSED_RESTART_PENDING' and
                previous['base_kernel_restart_required'] is True and
                previous['base_full_dependency_check_passed'] is True and
                previous['fresh_base_tool_imports_and_completion_passed'] is True and
                previous['isolated_84_packages_unchanged'] is True and previous['gpu_exceptions_accepted']==[],
                'Saved successful repair differs')
        for name,expected in previous['artifact_sha256'].items():
            require(digest(isolation.safe_artifact(repair_folder,name))==expected,'Saved repair artifact differs: '+name)
        require(previous['verified_base_changes']=={'jedi':{'before':None,'after':'0.20.0'}},
                'Saved repair actions differ from the returned Jedi-only result')
        base_path=EXPERIMENT/'COLAB_BASE_REPAIR_CONTRACT.json'
        isolated_path=EXPERIMENT/'ISOLATED_GPU_ENVIRONMENT_CONTRACT.json'
        policy_path=EXPERIMENT/'ISOLATED_CHILD_ENVIRONMENT_CONTRACT.json'
        require(digest(base_path)==previous['base_repair_contract_sha256'],'Base repair contract differs')
        base,isolated,policy=read(base_path),read(isolated_path),read(policy_path)
        require(base['format']=='ATML_TASK4_COLAB_BASE_REPAIR_CONTRACT_V2' and
                base['base_kernel_restart_required'] is True and
                base['source_manifest_sha256']==SOURCES['base_repair_recheck'] and
                base['isolated_environment_contract_sha256']==digest(isolated_path)==previous['isolated_environment_contract_sha256'] and
                base['isolated_child_environment_contract_sha256']==digest(policy_path)==previous['isolated_child_environment_contract_sha256'] and
                base['approval_sha256']==report['approval_sha256'] and base['gpu_exceptions_accepted']==[],
                'Paired base/isolated validation contracts differ')
        require(LOCAL.is_dir() and not LOCAL.is_symlink(),'Local isolated environment missing; retain the same A100 runtime files')
        owner=read(LOCAL/'.task4_isolation_owner.json')
        require(owner['source_manifest_sha256']==SOURCES['isolated_gpu'] and owner['directory']==str(LOCAL) and
                owner['approval_sha256']==report['approval_sha256'] and
                owner['wheelhouse_contract_sha256']==isolated['wheelhouse_contract_sha256']==base['wheelhouse_contract_sha256'] and
                owner['system_site_packages'] is False,'Isolated owner differs')
        kernel=read(sys.argv[1])
        save(attempt/'RESTARTED_NOTEBOOK_KERNEL.json',kernel)
        kernel_result=validate_kernel(kernel,read(repair_folder/'NOTEBOOK_KERNEL_OBSERVATION.json'),base,owner)
        save(attempt/'KERNEL_RESTART_VALIDATION.json',kernel_result)
        pins=read(ROOT/'APPROVED_ISOLATED_VERSIONS.json')
        require(len(pins)==84 and pins==isolated['isolated_package_versions'],'Approved isolated versions differ')
        protocol=EXPERIMENT/'CPU_ORCHESTRATION_VALIDATION_CONTRACT.json'
        inputs=EXPERIMENT/'CPU_MODEL_INPUT_CONTRACT.json'
        require(digest(protocol)==isolated['cpu_orchestration_contract_sha256']==previous['cpu_orchestration_contract_sha256'] and
                digest(inputs)==isolated['model_input_contract_sha256']==read(protocol)['model_input_contract_sha256'] and
                read(protocol)['source_manifest_sha256']==SOURCES['orchestration'],'Frozen model/evaluation contracts differ')
        require(isolated['isolated_child_environment_policy']==policy and
                policy['source_manifest_sha256']==SOURCES['isolated_recheck'] and
                policy['original_sanitizer_source_manifest_sha256']==SOURCES['isolated_gpu'] and
                policy['recognized_removed_value']==isolation.NOTEBOOK_BACKEND and
                policy['replacement_backend_forced'] is False and policy['parent_environment_modified'] is False,
                'Finalized child environment policy differs')
        parent_backend=os.environ.get('MPLBACKEND')
        base_env=original.clean_environment(os.environ)
        isolated_env=isolation.child_environment(os.environ,original.clean_environment)
        report.update({'base_repair_report_sha256':digest(repair_folder/'REPORT.json'),
                       'base_repair_contract_sha256':digest(base_path),
                       'isolated_environment_contract_sha256':digest(isolated_path),
                       'isolated_child_environment_contract_sha256':digest(policy_path)})
        command(['nvidia-smi','--query-gpu=name,memory.total,driver_version,uuid','--format=csv,noheader,nounits'],
                'nvidia_inventory',base_env)
        hardware=gates.parse_a100_inventory((attempt/'nvidia_inventory.log').read_text())
        require(hardware==read(repair_folder/'A100_HARDWARE.json'),'A100 runtime/hardware differs after restart')
        save(attempt/'A100_HARDWARE.json',hardware)
        inspect=folders['isolated_gpu']/'inspect_python.py'
        details=read(folders['base_repair_recheck']/'REVIEWED_LAYOUT_DETAILS.json')
        reviewed=read(repair_folder/'BASE_LAYOUT_AFTER.json')

        def inspect_base(label):
            command([sys.executable,'-I','-B',inspect,attempt/(label+'_INVENTORY.json')],label+'_inventory',base_env)
            command([sys.executable,'-I','-B',folders['base_repair_recheck']/'scan_base_layout.py',
                     folders['base_layout_diagnostic']/'scan_layout.py',attempt/(label+'_LAYOUT.json')],label+'_layout',base_env)
            inventory,layout=read(attempt/(label+'_INVENTORY.json')),read(attempt/(label+'_LAYOUT.json'))
            versions=layout_guards.validate_reviewed_base_inventory(inventory,layout,reviewed,details,owner['base_python_executable'])
            require(versions==base['complete_base_package_versions'] and
                    layout['effective_metadata_versions']==base['effective_metadata_versions'] and layout==reviewed,
                    'Base metadata or selected versions changed after repair')
            return inventory,layout

        base_before,layout_before=inspect_base('BASE_BEFORE')
        command([sys.executable,'-I','-B','-m','pip','--disable-pip-version-check','check'],
                'base_full_dependency_check',base_env)
        require((attempt/'base_full_dependency_check.log').read_text().strip()=='No broken requirements found.',
                'A clean full base dependency check is required')
        command([sys.executable,'-I','-B','-u',folders['base_repair_recheck']/'probe_base.py',
                 repair_folder/'EXPECTED_BASE_TOOLS.json',attempt/'BASE_TOOLS_PROBE.json',attempt/'BASE_BEFORE_LAYOUT.json'],
                'fresh_base_tools_and_completion',base_env)
        python=LOCAL/'bin/python'
        command([python,'-I','-B',inspect,attempt/'ISOLATED_INVENTORY_BEFORE.json'],'inspect_isolated_before',isolated_env)
        iso_before=read(attempt/'ISOLATED_INVENTORY_BEFORE.json')
        original.validate_inventory(iso_before,pins,LOCAL,complete=True)
        require(iso_before==read(repair_folder/'ISOLATED_INVENTORY_AFTER.json'),'Isolated interpreter changed after repair')
        command([python,'-I','-B','-m','pip','--disable-pip-version-check','check'],
                'isolated_full_dependency_check',isolated_env)
        probe_directory=attempt/'fresh_probe';probe_directory.mkdir()
        command([python,'-I','-B','-u',folders['gpu_environment']/'probe_gpu.py',first,
                 folders['orchestration'],folders['diagnostic'],probe_directory],
                'fresh_isolated_a100_probe',isolated_env)
        probe=read(probe_directory/'GPU_PROBE.json')
        require(probe['all_required_package_versions']=={name:version for name,version in pins.items() if name!='pip'} and
                probe['required_distributions']==83 and probe['synthetic_semantic_checks_passed']==37 and
                probe['required_dependency_chain_passed'] and probe['fresh_process_imports_passed'] and
                probe['tiny_float16_cuda_check_passed'] and probe['tiny_nf4_cuda_backend_check_passed'] and
                probe['pretrained_model_weights_loaded'] is False,'Fresh isolated validation is incomplete')
        command([python,'-I','-B',inspect,attempt/'ISOLATED_INVENTORY_AFTER.json'],'inspect_isolated_after',isolated_env)
        iso_after=read(attempt/'ISOLATED_INVENTORY_AFTER.json')
        original.validate_inventory(iso_after,pins,LOCAL,complete=True)
        require(iso_before==iso_after,'Isolated inventory changed during recheck')
        base_after,layout_after=inspect_base('BASE_AFTER')
        require(base_before==base_after and layout_before==layout_after and
                os.environ.get('MPLBACKEND')==parent_backend and
                digest(base_path)==report['base_repair_contract_sha256'] and
                digest(isolated_path)==report['isolated_environment_contract_sha256'] and
                digest(policy_path)==report['isolated_child_environment_contract_sha256'],
                'Environment or historical contracts changed during validation')
        combined={'format':'ATML_TASK4_GPU_ENVIRONMENT_V2','source_manifest_sha256':identity,
            'approval_sha256':report['approval_sha256'],'environment_layout':'Isolated course interpreter plus repaired Colab base',
            'isolated_environment_contract_sha256':digest(isolated_path),'colab_base_repair_contract_sha256':digest(base_path),
            'isolated_child_environment_contract_sha256':digest(policy_path),
            'cpu_orchestration_contract_sha256':digest(protocol),'model_input_contract_sha256':digest(inputs),
            'course_requirements_sha256':digest(first/'course_reference/requirements.txt'),
            'python_executable':str(python),'base_python_executable':sys.executable,
            'isolated_package_versions':pins,'isolated_distributions':84,
            **{key:probe[key] for key in ['python','course_package_versions','all_required_package_versions',
                'required_distributions','required_dependency_chain_passed','fresh_process_imports_passed',
                'cuda_available','torch_cuda_version','tiny_float16_cuda_check_passed','tiny_nf4_cuda_backend_check_passed',
                'synthetic_semantic_checks_passed']},
            'base_full_dependency_check_passed':True,'isolated_full_dependency_check_passed':True,
            'base_tools_completion_and_selected_imports_passed':True,
            'kernel_restart_observed_and_notebook_tools_validated':True,
            'base_legacy_package_versions':base['complete_base_package_versions'],
            'base_effective_metadata_versions':base['effective_metadata_versions'],
            'reviewed_base_layout_preserved':True,'hardware_requirement':'A100, compute capability 8.0',
            'gpu_exceptions_accepted':[],'pretrained_model_weights_loaded':False,
            'gpu_model_loading_validation_pending':True}
        save(EXPERIMENT/'GPU_ENVIRONMENT_CONTRACT.json',combined)
        report.update({'status':'BOTH_INTERPRETERS_VALIDATED_AFTER_RESTART_NO_INFERENCE',
                       'kernel_restart_observed':True,'base_full_dependency_check_passed':True,
                       'isolated_full_dependency_check_passed':True,'isolated_packages':84,
                       'synthetic_checks_passed':37,'fresh_imports_cuda_and_nf4_passed':True,
                       'base_layout_and_isolated_inventory_unchanged':True,
                       'combined_gpu_environment_contract_sha256':digest(EXPERIMENT/'GPU_ENVIRONMENT_CONTRACT.json'),
                       'gpu_model_loading_validation_pending':True})
        print('Restarted notebook tools PASS; base and isolated full dependency checks PASS.',flush=True)
        print('Fresh isolated CUDA/NF4/course imports PASS; synthetic checks 37/37 PASS.',flush=True)
        print('Combined environment validated. Actual pretrained model loading remains pending.',flush=True)
        print('Responses 0/1800; judgments 0/1800; human labels 0/240. No package changes or inference.',flush=True)
    except BaseException as error:
        report.update({'status':'POST_RESTART_VALIDATION_FAILED_PRESERVED',
                       'error':{'type':type(error).__name__,'message':str(error)}})
        raise
    finally:
        report['artifact_sha256']={p.relative_to(attempt).as_posix():digest(p) for p in attempt.rglob('*') if p.is_file()}
        save(attempt/'REPORT.json',report)
        print('Saved post-restart validation report:',attempt/'REPORT.json',flush=True)
        print('Status:',report['status'],flush=True)


if __name__=='__main__':main()
