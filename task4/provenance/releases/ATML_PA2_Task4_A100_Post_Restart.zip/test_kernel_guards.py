"""Reject stale kernel evidence without touching any interpreter installation."""
import copy
import unittest
from kernel_guards import validate_kernel


class RestartEvidence(unittest.TestCase):
    def setUp(self):
        self.previous={'pid':100}
        self.owner={'base_python_executable':'/usr/bin/python3','target_python_full_version':'3.13.15'}
        self.base={'base_kernel_restart_required':True,'python':'3.13.15',
                   'effective_metadata_versions':{'ipython':'7.34.0','jedi':'0.20.0','numpy':'2.1.3'}}
        self.current={'pid':101,'python_executable':'/usr/bin/python3','python':'3.13.15',
            'ipython_version':'7.34.0','jedi_version':'0.20.0','jedi_completion_passed':True,
            'already_loaded_modules':{'ipython':{'version':'7.34.0'},'jedi':{'version':'0.20.0'},
                                      'numpy':{'version':'2.1.3'},'trl':None}}

    def check(self): return validate_kernel(self.current,self.previous,self.base,self.owner)

    def test_restarted_kernel_and_repaired_actual_notebook_tools_pass(self):
        result=self.check()
        self.assertTrue(result['different_kernel_pid_observed'])
        self.assertTrue(result['notebook_ipython_jedi_and_completion_passed'])

    def test_unchanged_invalid_or_missing_restart_pid_is_rejected(self):
        for pid in [100,0,-1,'101',True]:
            self.current['pid']=pid
            with self.subTest(pid=pid),self.assertRaises(RuntimeError):self.check()

    def test_replacement_interpreter_or_python_version_is_rejected(self):
        for field,value in [('python_executable','/content/other/bin/python'),('python','3.13.16')]:
            self.setUp();self.current[field]=value
            with self.subTest(field=field),self.assertRaises(RuntimeError):self.check()

    def test_missing_repaired_jedi_or_failed_actual_completion_is_rejected(self):
        for field,value in [('jedi_version','0.19.0'),('ipython_version','9.0.0'),('jedi_completion_passed',False)]:
            self.setUp();self.current[field]=value
            with self.subTest(field=field),self.assertRaises(RuntimeError):self.check()

    def test_loaded_numpy_must_match_selected_metadata_not_legacy_duplicate(self):
        self.current['already_loaded_modules']['numpy']['version']='1.26.4'
        with self.assertRaises(RuntimeError):self.check()

    def test_removed_global_course_package_must_not_remain_loaded(self):
        self.current['already_loaded_modules']['trl']={'version':'0.27.2'}
        with self.assertRaises(RuntimeError):self.check()


if __name__=='__main__':unittest.main(verbosity=2)
