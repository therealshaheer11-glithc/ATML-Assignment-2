"""Require actual restarted kernel evidence before final environment validation."""
from pathlib import Path


def require(value,message):
    if not value: raise RuntimeError(message)


def validate_kernel(current, previous, base_contract, owner):
    require(type(current['pid']) is int and current['pid']>0 and type(previous['pid']) is int,
            'Notebook PID evidence differs')
    if base_contract['base_kernel_restart_required']:
        require(current['pid'] != previous['pid'],
                'Notebook kernel has not restarted. Use an ordinary Restart session, retaining local runtime files.')
    require(str(Path(current['python_executable']).resolve()) == owner['base_python_executable'] and
            current['python'] == base_contract['python'] == owner['target_python_full_version'],
            'Restarted notebook interpreter differs from the validated base')
    require(current['ipython_version'] == '7.34.0' and current['jedi_version'] == '0.20.0' and
            current['jedi_completion_passed'] is True, 'Repaired tools do not work in the actual notebook kernel')
    versions=base_contract['effective_metadata_versions']
    for package, value in current['already_loaded_modules'].items():
        if value is None: continue
        require(package in versions, 'Removed global package remains loaded in the notebook: '+package)
        require(value['version'] == versions[package], 'Notebook has a stale loaded package: '+package)
    return {'restart_required_by_saved_repair':base_contract['base_kernel_restart_required'],
            'different_kernel_pid_observed':current['pid'] != previous['pid'],
            'notebook_ipython_jedi_and_completion_passed':True,
            'already_loaded_package_versions_match_selected_base_metadata':True}
