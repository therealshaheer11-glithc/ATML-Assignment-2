"""Synthetic integrity and interruption tests; no network or model weights."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import download as stage


def metadata(payload, lfs=False):
    return {'bytes': len(payload), 'lfs_sha256': hashlib.sha256(payload).hexdigest() if lfs else None,
            'git_blob_id': hashlib.sha1(b'blob ' + str(len(payload)).encode() + b'\0' + payload).hexdigest()}


def save(path, value):
    payload = (json.dumps(value, indent=2) + '\n').encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_bytes() != payload:
        raise RuntimeError('Existing receipt differs')
    path.write_bytes(payload)


class DownloadBoundaries(unittest.TestCase):
    def test_git_blob_identity_includes_header(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / 'config.json'
            path.write_bytes(b'{"synthetic":true}')
            expected = metadata(path.read_bytes())
            self.assertEqual(stage.verify_file(path, expected)['remote_identity_verified_by'], 'GIT_BLOB_SHA1')
            expected['git_blob_id'] = hashlib.sha1(path.read_bytes()).hexdigest()
            with self.assertRaisesRegex(RuntimeError, 'Git blob checksum differs'):
                stage.verify_file(path, expected)

    def test_lfs_and_size_corruption_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / 'model.safetensors'
            payload = b'synthetic bytes'
            path.write_bytes(payload)
            expected = metadata(payload, lfs=True)
            self.assertEqual(stage.verify_file(path, expected)['sha256'], expected['lfs_sha256'])
            path.write_bytes(b'S' + payload[1:])
            with self.assertRaisesRegex(RuntimeError, 'LFS checksum differs'):
                stage.verify_file(path, expected)
            path.write_bytes(b'short')
            with self.assertRaisesRegex(RuntimeError, 'size differs'):
                stage.verify_file(path, expected)

    def test_all_saved_files_checked_before_new_download(self):
        with tempfile.TemporaryDirectory() as root:
            folder, receipts = Path(root) / 'model', Path(root) / 'receipts'
            folder.mkdir()
            (folder / 'z.json').write_bytes(b'bad')
            files = {'a.json': metadata(b'new'), 'z.json': metadata(b'old')}
            with self.assertRaisesRegex(RuntimeError, 'checksum differs'):
                stage.check_existing(folder, files, receipts)
            self.assertFalse((folder / 'a.json').exists())
            self.assertEqual((folder / 'z.json').read_bytes(), b'bad')

    def test_interrupted_run_reuses_only_verified_complete_files(self):
        with tempfile.TemporaryDirectory() as root:
            folder, receipts = Path(root) / 'model', Path(root) / 'receipts'
            payloads = {'a.json': b'first', 'b.safetensors': b'second'}
            files = {name: metadata(payload, name.endswith('.safetensors')) for name, payload in payloads.items()}
            calls = []
            def interrupted(name, destination):
                calls.append(name)
                if name.startswith('b'):
                    raise ConnectionError('synthetic interrupted transfer')
                path = destination / name
                path.write_bytes(payloads[name])
                return str(path)
            with self.assertRaises(ConnectionError):
                stage.transfer_files(folder, files, receipts, save, interrupted, {}, lambda *_: None)
            self.assertTrue((receipts / 'a.json.json').is_file())
            checked = stage.check_existing(folder, files, receipts)
            resumed = []
            def finish(name, destination):
                resumed.append(name)
                path = destination / name
                path.write_bytes(payloads[name])
                return str(path)
            verified, reused = stage.transfer_files(folder, files, receipts, save, finish, checked, lambda *_: None)
            self.assertEqual(resumed, ['b.safetensors'])
            self.assertEqual(reused, ['a.json'])
            self.assertEqual(set(verified), set(payloads))
            self.assertEqual(calls, ['a.json', 'b.safetensors'])
            # Complete reruns must make no download calls.
            checked = stage.check_existing(folder, files, receipts)
            stage.transfer_files(folder, files, receipts, save,
                lambda *_: self.fail('Unexpected repeated download'), checked, lambda *_: None)

    def test_changed_or_missing_receipted_file_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            folder, receipts = Path(root) / 'model', Path(root) / 'receipts'
            folder.mkdir()
            path = folder / 'config.json'
            path.write_bytes(b'{}')
            files = {'config.json': metadata(b'{}')}
            receipt = stage.verify_file(path, files['config.json'])
            receipt['sha256'] = 'f' * 64
            save(receipts / 'config.json.json', receipt)
            with self.assertRaisesRegex(RuntimeError, 'receipt differs'):
                stage.check_existing(folder, files, receipts)
            path.unlink()
            with self.assertRaisesRegex(RuntimeError, 'Receipted snapshot file is missing'):
                stage.check_existing(folder, files, receipts)

    def test_unexpected_files_and_path_escapes_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            folder = Path(root)
            (folder / 'extra.txt').write_text('unapproved')
            with self.assertRaisesRegex(RuntimeError, 'Unexpected saved snapshot file'):
                stage.check_existing(folder, {}, folder / 'receipts')
            for name in ['../outside', '/outside', '', '.', 'sub/file', 'sub\\file']:
                with self.subTest(name=name), self.assertRaises(RuntimeError):
                    stage.root_file(folder, name)
            (folder / 'link').symlink_to(folder / 'extra.txt')
            with self.assertRaisesRegex(RuntimeError, 'escapes'):
                stage.root_file(folder, 'link')

    def test_weight_index_must_cover_exact_verified_shards(self):
        with tempfile.TemporaryDirectory() as root:
            folder, receipts = Path(root) / 'model', Path(root) / 'receipts'
            payloads = {'model.safetensors': b'synthetic weights',
                        'model.safetensors.index.json': b'{"weight_map":{"x":"missing.safetensors"}}'}
            files = {name: metadata(payload, name.endswith('.safetensors')) for name, payload in payloads.items()}
            def write(name, destination):
                path = destination / name
                path.write_bytes(payloads[name])
                return path
            with self.assertRaisesRegex(RuntimeError, 'index does not match'):
                stage.transfer_files(folder, files, receipts, save, write, {}, lambda *_: None)

    def test_proposal_is_bound_to_approved_revision_bytes_and_hashes(self):
        names = ['config.json', 'generation_config.json', 'tokenizer_config.json', 'tokenizer.json',
                 'merges.txt', 'vocab.json', 'model.safetensors.index.json',
                 'model-1.safetensors', 'model-2.safetensors']
        files = {name: metadata(b'x', name.endswith('.safetensors')) for name in names}
        files['model-1.safetensors']['bytes'] += stage.EXPECTED_BYTES - 9
        candidate = {'model_id': stage.JUDGE, 'observed_revision': stage.REVISION,
            'revision_selected_for_experiment': False, 'weight_download_performed': False,
            'proposed_snapshot_files': files, 'proposed_download_bytes': stage.EXPECTED_BYTES}
        stage.validate_proposal(candidate)
        for key, value in [('observed_revision', 'a' * 40), ('proposed_download_bytes', 10),
                           ('revision_selected_for_experiment', True)]:
            changed = copy.deepcopy(candidate)
            changed[key] = value
            with self.subTest(key=key), self.assertRaises(RuntimeError):
                stage.validate_proposal(changed)
        changed = copy.deepcopy(candidate)
        changed['proposed_snapshot_files']['config.json']['git_blob_id'] = None
        with self.assertRaisesRegex(RuntimeError, 'Missing Git blob checksum'):
            stage.validate_proposal(changed)

    def test_approval_cannot_select_another_revision(self):
        approval = {'approved': True, 'user_message': 'approve', 'judge_model': stage.JUDGE,
                    'judge_revision': stage.REVISION, 'snapshot_files': 9,
                    'snapshot_bytes': stage.EXPECTED_BYTES,
                    'destination': str(stage.EXPERIMENT / 'models/judge'), 'base_reuse_read_only': True}
        stage.validate_approval(approval)
        approval['judge_revision'] = 'a' * 40
        with self.assertRaisesRegex(RuntimeError, 'scope differs'):
            stage.validate_approval(approval)


if __name__ == '__main__':
    unittest.main(verbosity=2)
