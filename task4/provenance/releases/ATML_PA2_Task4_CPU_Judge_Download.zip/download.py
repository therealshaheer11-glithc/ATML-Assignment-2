"""Approved, pinned CPU judge snapshot preparation; no model construction."""
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import importlib.util
import json
from pathlib import Path, PurePosixPath
import platform
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
EXPERIMENT = Path('/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1')
STAGE1 = '9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65'
RECOVERY = '6629e696e04632096dcd79e3f41fe1e28fb55e7aee8c95ec17e33f383928dda8'
RECOVERY_ATTEMPT = '20261011T112205.775509Z'
INVENTORY = 'd9e3eb2cd1d9c5cafc4956313553209d0581a07ed9d204c92529be56755e22de'
INVENTORY_ATTEMPT = '20261011T113929.803036Z'
JUDGE = 'Qwen/Qwen2.5-3B-Instruct'
REVISION = 'aa8e72537993ba99e69dfaafa59ed015b17504d1'
EXPECTED_BYTES = 6183451098
EXPECTED_FILES = 9


def require(value, message):
    if not value:
        raise RuntimeError(message)


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def root_file(folder, name):
    relative = PurePosixPath(name)
    require(name not in {'', '.', '..', '.cache'} and len(relative.parts) == 1
            and not relative.is_absolute() and '\\' not in name,
            'Unsafe snapshot filename: ' + name)
    target = folder / name
    require(not target.is_symlink() and folder.resolve() == target.resolve().parent,
            'Snapshot file escapes its folder: ' + name)
    return target


def validate_proposal(candidate):
    require(candidate['model_id'] == JUDGE and candidate['observed_revision'] == REVISION,
            'Judge model/revision differs from approval')
    require(candidate['revision_selected_for_experiment'] is False and
            candidate['weight_download_performed'] is False, 'Inventory proposal was changed')
    files = candidate['proposed_snapshot_files']
    require(len(files) == EXPECTED_FILES, 'Approved judge file count differs')
    require(candidate['proposed_download_bytes'] == EXPECTED_BYTES ==
            sum(item['bytes'] for item in files.values()), 'Approved judge byte count differs')
    required = {'config.json', 'generation_config.json', 'tokenizer_config.json', 'tokenizer.json'}
    require(required <= set(files), 'Judge configuration/tokenizer files are missing')
    weights = {name for name in files if name.endswith('.safetensors')}
    require(bool(weights), 'Judge weights are missing')
    for name, item in files.items():
        root_file(Path('/tmp/task4_filename_validation'), name)
        require(type(item['bytes']) is int and item['bytes'] > 0, 'Invalid file size: ' + name)
        if item.get('lfs_sha256') is not None:
            require(re.fullmatch(r'[0-9a-f]{64}', item['lfs_sha256']) is not None,
                    'Invalid LFS checksum: ' + name)
        else:
            require(re.fullmatch(r'[0-9a-f]{40}', item.get('git_blob_id') or '') is not None,
                    'Missing Git blob checksum: ' + name)
        if name in weights:
            require(item.get('lfs_sha256') is not None, 'Weight LFS checksum missing: ' + name)
    return files


def verify_file(path, expected):
    require(path.is_file() and not path.is_symlink(), 'Snapshot file missing: ' + path.name)
    size = path.stat().st_size
    require(size == expected['bytes'], 'Snapshot size differs; preserved: ' + path.name)
    sha = hashlib.sha256()
    git = hashlib.sha1(b'blob ' + str(size).encode('ascii') + b'\0')
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            sha.update(block)
            git.update(block)
    if expected.get('lfs_sha256') is not None:
        require(sha.hexdigest() == expected['lfs_sha256'],
                'Snapshot LFS checksum differs; preserved: ' + path.name)
        method = 'LFS_SHA256'
    else:
        require(git.hexdigest() == expected['git_blob_id'],
                'Snapshot Git blob checksum differs; preserved: ' + path.name)
        method = 'GIT_BLOB_SHA1'
    return {'filename': path.name, 'bytes': size, 'sha256': sha.hexdigest(),
            'remote_metadata': expected, 'remote_identity_verified_by': method}


def folder_files(folder):
    if not folder.exists():
        return set()
    require(folder.is_dir() and not folder.is_symlink(), 'Snapshot folder is invalid')
    result = set()
    for path in folder.rglob('*'):
        relative = path.relative_to(folder)
        if relative.parts[0] == '.cache':
            continue
        require(not path.is_symlink(), 'Snapshot contains a symlink')
        if path.is_file():
            result.add(relative.as_posix())
    return result


def check_existing(folder, files, receipts):
    """Check every complete file before downloading anything new."""
    require(folder_files(folder) <= set(files), 'Unexpected saved snapshot file; preserved')
    found = {}
    if receipts.exists():
        require({path.name for path in receipts.iterdir()} <= {name + '.json' for name in files},
                'Unexpected file receipt; preserved')
    for name, expected in sorted(files.items()):
        path = root_file(folder, name)
        receipt_path = receipts / (name + '.json')
        require(not receipt_path.exists() or path.is_file(), 'Receipted snapshot file is missing: ' + name)
        if path.exists():
            print('Checking saved complete file:', name, flush=True)
            value = verify_file(path, expected)
            if receipt_path.exists():
                require(read_json(receipt_path) == value, 'Saved file receipt differs: ' + name)
            found[name] = value
    return found


def transfer_files(folder, files, receipts, save, download_one, checked, on_verified):
    folder.mkdir(parents=True, exist_ok=True)
    verified = dict(checked)
    reused = set(checked)
    for index, (name, expected) in enumerate(sorted(files.items()), 1):
        path = root_file(folder, name)
        if name not in verified:
            print('Downloading judge file', str(index) + '/' + str(len(files)) + ':', name, flush=True)
            require(not path.exists(), 'Another writer created a snapshot file')
            downloaded = Path(download_one(name, folder))
            require(downloaded.resolve() == path.resolve(), 'Downloader returned an unexpected path')
            print('Verifying downloaded file:', name, flush=True)
            verified[name] = verify_file(path, expected)
        save(receipts / (name + '.json'), verified[name])
        on_verified(dict(verified), sorted(reused))
        print('Judge files verified:', str(len(verified)) + '/' + str(len(files)), flush=True)
    require(folder_files(folder) == set(files), 'Completed snapshot file coverage differs')
    for name in files:
        if name.endswith('.safetensors.index.json'):
            mapping = read_json(folder / name)['weight_map']
            weights = {item for item in files if item.endswith('.safetensors')}
            require(bool(mapping) and set(mapping.values()) == weights,
                    'Judge weight index does not match the verified shards')
    return verified, sorted(reused)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verified_release(path, expected, preflight):
    require(digest(path / 'MANIFEST.json') == expected, 'Historical source manifest differs')
    preflight.verify_source(path)


def verified_inventory(path):
    report = read_json(path / 'REPORT.json')
    require(report['status'] == 'BASE_FILES_VERIFIED_JUDGE_METADATA_READY' and
            report['source_manifest_sha256'] == INVENTORY, 'Completed inventory identity differs')
    for name, expected in report['artifact_sha256'].items():
        require(digest(root_file(path, name)) == expected, 'Inventory artifact changed: ' + name)
    for name, field in [('BASE_MODEL_INVENTORY.json', 'base_inventory_sha256'),
                        ('JUDGE_METADATA_PROPOSAL.json', 'judge_metadata_proposal_sha256')]:
        require(digest(path / name) == report[field], 'Inventory receipt changed: ' + name)
    require(report['judge_observed_revision'] == REVISION and
            report['judge_proposed_download_bytes'] == EXPECTED_BYTES, 'Returned judge inventory differs')
    for field in ['model_weights_downloaded', 'model_weights_loaded', 'generation_performed',
                  'judging_performed', 'training_performed', 'judge_revision_selected_for_experiment']:
        require(report[field] is False, 'Unexpected prior inventory action: ' + field)
    return report


def validate_approval(approval):
    require(approval['approved'] is True and approval['user_message'] == 'approve', 'Download approval missing')
    require(approval['judge_model'] == JUDGE and approval['judge_revision'] == REVISION and
            approval['snapshot_files'] == EXPECTED_FILES and approval['snapshot_bytes'] == EXPECTED_BYTES,
            'Download approval scope differs')
    require(approval['destination'] == str(EXPERIMENT / 'models/judge') and
            approval['base_reuse_read_only'] is True, 'Approved model paths differ')


def main():
    stage1 = EXPERIMENT / 'preflight_releases' / STAGE1
    require(digest(stage1 / 'MANIFEST.json') == STAGE1, 'Preflight source identity differs')
    source = read_json(stage1 / 'MANIFEST.json')
    require(digest(stage1 / 'scripts/preflight.py') == source['scripts/preflight.py'], 'Preflight helper differs')
    preflight = load_module('task4_download_preflight', stage1 / 'scripts/preflight.py')
    preflight.verify_source(stage1)
    own = preflight.verify_source(ROOT)
    preflight.require_cpu()
    approval = read_json(ROOT / 'APPROVAL.json')
    validate_approval(approval)
    require(digest(ROOT / 'APPROVED_PROPOSAL.md') == approval['approved_proposal_sha256'],
            'Reviewed download proposal differs')
    require(read_json(EXPERIMENT / 'OWNER.json')['approval_sha256'] == digest(stage1 / 'docs/approval.json'),
            'Experiment owner differs')
    save, save_bytes = preflight.immutable_json, preflight.immutable_bytes
    identity = own['manifest_sha256']
    release = EXPERIMENT / 'judge_download_releases' / identity
    for name in [*read_json(ROOT / 'MANIFEST.json'), 'MANIFEST.json']:
        save_bytes(release / name, (ROOT / name).read_bytes())
    attempt_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    attempt = EXPERIMENT / 'judge_download_attempts' / attempt_id
    attempt.mkdir(parents=True, exist_ok=False)
    report = {'format': 'ATML_TASK4_JUDGE_DOWNLOAD_ATTEMPT_V1', 'status': 'RUNNING',
              'attempt_utc': attempt_id, 'source_manifest_sha256': identity,
              'approval_sha256': digest(ROOT / 'APPROVAL.json'), 'judge_model': JUDGE,
              'judge_revision': REVISION, 'verified_files': {}, 'reused_complete_files': [],
              'download_calls_started': [], 'package_changes_performed': False,
              'model_weights_loaded': False, 'generation_performed': False,
              'judging_performed': False, 'training_performed': False}
    try:
        save(attempt / 'START.json', report)
        recovery_source = EXPERIMENT / 'recovery_releases' / RECOVERY
        inventory_source = EXPERIMENT / 'model_inventory_releases' / INVENTORY
        verified_release(recovery_source, RECOVERY, preflight)
        verified_release(inventory_source, INVENTORY, preflight)
        recovery_path = EXPERIMENT / 'recovery_attempts' / RECOVERY_ATTEMPT / 'REPORT.json'
        recovery = read_json(recovery_path)
        require(recovery['status'] == 'CPU_ENVIRONMENT_AND_AUDIT_FINALIZED_WITH_APPROVED_EXCEPTIONS' and
                recovery['source_manifest_sha256'] == RECOVERY, 'Environment recovery identity differs')
        for name, field in [('CPU_ENVIRONMENT_CONTRACT.json', 'cpu_environment_contract_sha256'),
                            ('AUDIT_ID_CONTRACT.json', 'audit_id_contract_sha256')]:
            require(digest(EXPERIMENT / name) == recovery[field], 'Finalized contract changed: ' + name)
        env = read_json(EXPERIMENT / 'CPU_ENVIRONMENT_CONTRACT.json')
        require(env['format'] == 'ATML_TASK4_CPU_ENVIRONMENT_V2' and
                env['required_dependency_chain_passed'] is True and env['required_distributions'] == 64 and
                env['global_dependency_check_passed'] is False, 'Approved CPU environment differs')
        require(env['recovery_source_manifest_sha256'] == RECOVERY and
                env['preflight_source_manifest_sha256'] == STAGE1, 'CPU contract source identity differs')
        require(platform.python_version() == env['python'], 'Python version changed')
        require(digest(EXPERIMENT / 'INPUT_IDENTITY_CONTRACT.json') == env['input_contract_sha256'] and
                digest(EXPERIMENT / 'ENVIRONMENT_RECOVERY_APPROVAL.json') == env['recovery_approval_sha256'],
                'Input or recovery approval contract changed')
        require(env['approval_sha256'] == digest(stage1 / 'docs/approval.json'), 'Original approval identity differs')
        require(len(env['all_required_package_versions']) == 64, 'Required package count differs')
        for name, version in env['all_required_package_versions'].items():
            require(importlib.metadata.version(name) == version, 'Required package version changed: ' + name)
        inventory_folder = EXPERIMENT / 'model_inventory_attempts' / INVENTORY_ATTEMPT
        inventory_report = verified_inventory(inventory_folder)
        require(inventory_report['environment_contract_sha256'] == digest(EXPERIMENT / 'CPU_ENVIRONMENT_CONTRACT.json')
                and inventory_report['recovery_report_sha256'] == digest(recovery_path),
                'Inventory environment provenance differs')
        base = read_json(inventory_folder / 'BASE_MODEL_INVENTORY.json')
        require(base['model_id'] == 'Qwen/Qwen2.5-1.5B-Instruct' and
                base['revision'] == '989aa7980e4cf806f80c7fef2b1adb7bc71aa306' and
                base['all_saved_files_verified'] is True and len(base['verified_files']) == 7 and
                base['total_bytes'] == 3098955668, 'Verified base inventory differs')
        expected_base = Path('/content/drive/MyDrive/ATML-Assignment-2/task3/experiment_v1/models/policy')
        require(base['directory'] == str(expected_base), 'Base reuse path differs')
        candidate = read_json(inventory_folder / 'JUDGE_METADATA_PROPOSAL.json')
        files = validate_proposal(candidate)
        inventory = load_module('task4_verified_model_inventory', inventory_source / 'inventory.py')
        from huggingface_hub import HfApi, hf_hub_download
        print('Rechecking public metadata at approved judge commit:', REVISION, flush=True)
        fresh = inventory.judge_metadata(HfApi(token=False).model_info(
            JUDGE, revision=REVISION, files_metadata=True, timeout=30))
        require(fresh == candidate, 'Pinned public judge metadata differs from the saved inventory')
        save(attempt / 'PINNED_REMOTE_METADATA.json', fresh)
        report['inventory_report_sha256'] = digest(inventory_folder / 'REPORT.json')
        report['environment_contract_sha256'] = digest(EXPERIMENT / 'CPU_ENVIRONMENT_CONTRACT.json')
        folder = EXPERIMENT / 'models/judge'
        receipts = EXPERIMENT / 'judge_file_receipts' / REVISION
        checked = check_existing(folder, files, receipts)
        revision_contract = {'format': 'ATML_TASK4_JUDGE_REVISION_V1', 'model_id': JUDGE,
            'revision': REVISION, 'directory': str(folder), 'files': files,
            'total_bytes': EXPECTED_BYTES, 'inventory_report_sha256': report['inventory_report_sha256'],
            'approval_sha256': report['approval_sha256']}
        pending_contracts = {'JUDGE_DOWNLOAD_APPROVAL.json': approval,
            'JUDGE_REVISION_CONTRACT.json': revision_contract, 'BASE_MODEL_REFERENCE.json': base}
        for name, value in pending_contracts.items():
            target = EXPERIMENT / name
            require(not target.exists() or target.read_bytes() == preflight.json_bytes(value),
                    'Existing model preparation contract differs; preserved: ' + name)
        complete = EXPERIMENT / 'JUDGE_SNAPSHOT_CONTRACT.json'
        if complete.exists():
            expected_complete = {**revision_contract, 'format': 'ATML_TASK4_JUDGE_SNAPSHOT_V1',
                'verified_files': checked, 'all_files_verified': True,
                'model_weights_loaded': False, 'inference_validation_pending': True}
            require(set(checked) == set(files) and read_json(complete) == expected_complete,
                    'Existing completed judge contract differs; preserved')
        for name, value in pending_contracts.items():
            save(EXPERIMENT / name, value)
        print('Approved judge snapshot:', len(files), 'files;', EXPECTED_BYTES, 'bytes. Stay on CPU.', flush=True)
        def download_one(name, destination):
            report['download_calls_started'].append(name)
            save(attempt / (str(len(report['download_calls_started'])) + '_DOWNLOAD_STARTED.json'),
                 {'filename': name, 'revision': REVISION})
            return hf_hub_download(repo_id=JUDGE, filename=name, revision=REVISION,
                local_dir=str(destination), token=False, force_download=False)
        def on_verified(values, reused):
            report.update({'verified_files': values, 'reused_complete_files': reused})
            save(attempt / ('FILES_' + str(len(values)).zfill(2) + '.json'), values)
        verified, reused = transfer_files(folder, files, receipts, save, download_one, checked, on_verified)
        snapshot = {**revision_contract, 'format': 'ATML_TASK4_JUDGE_SNAPSHOT_V1',
                    'verified_files': verified, 'all_files_verified': True,
                    'model_weights_loaded': False, 'inference_validation_pending': True}
        save(complete, snapshot)
        report.update({'status': 'JUDGE_FILES_VERIFIED_NO_INFERENCE', 'verified_file_count': len(verified),
            'verified_bytes': sum(value['bytes'] for value in verified.values()),
            'reused_complete_files': reused, 'judge_snapshot_contract_sha256': digest(complete),
            'judge_revision_contract_sha256': digest(EXPERIMENT / 'JUDGE_REVISION_CONTRACT.json'),
            'base_model_reference_sha256': digest(EXPERIMENT / 'BASE_MODEL_REFERENCE.json')})
        print('Judge snapshot VERIFIED:', str(len(verified)) + '/' + str(len(files)), 'files;', EXPECTED_BYTES, 'bytes.', flush=True)
        print('Reused complete files:', len(reused), '; download calls:', len(report['download_calls_started']), flush=True)
        print('Base snapshot reused by read-only reference; no base files copied or modified.', flush=True)
        print('No model loading, generation, judging or training was performed.', flush=True)
        print('Remaining: generation 1800; judging 1800; human labels 240. Stay on CPU.', flush=True)
    except BaseException as error:
        report['status'] = 'JUDGE_PREPARATION_FAILED_PRESERVED'
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        report['artifact_sha256'] = {p.name: digest(p) for p in attempt.iterdir() if p.is_file()}
        save(attempt / 'REPORT.json', report)
        print('Saved judge preparation report:', attempt / 'REPORT.json', flush=True)
        print('Status:', report['status'], flush=True)


if __name__ == '__main__':
    main()
