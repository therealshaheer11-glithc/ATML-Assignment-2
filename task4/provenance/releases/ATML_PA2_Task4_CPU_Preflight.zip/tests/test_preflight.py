"""Synthetic provenance/persistence checks; these are not experiment results."""
from contextlib import redirect_stdout
import hashlib
import io
import json
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch
import zipfile

from scripts import preflight as p


def config():
    return {"base_model_name_or_path": "Qwen/Qwen2.5-1.5B-Instruct", "r": 8,
            "lora_alpha": 16, "lora_dropout": 0.05, "target_modules": ["q_proj", "v_proj"],
            "peft_type": "LORA", "task_type": "CAUSAL_LM"}


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(p.json_bytes(value))


def csv_fixture(path, duplicate=False, bad_class=False):
    rows = ["xstest_id,prompt,benchmark_class,type"]
    for index in range(60):
        identifier = 1000 - index
        if duplicate and index == 59:
            identifier = 1000
        label = "SAFE" if index < 30 else "UNSAFE"
        if bad_class and index == 59:
            label = "other"
        rows.append(f"{identifier},Fixture prompt {index},{label},fixture_type")
    Path(path).write_text("\n".join(rows) + "\n")
    return p.sha256(path)


def dpo_fixture(folder, complete=True):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "adapter_model.safetensors").write_bytes(b"synthetic adapter bytes; not a model")
    write_json(folder / "adapter_config.json", config())
    write_json(folder / "run_record.json", {
        "status": "COMPLETE_RELOAD_VERIFIED" if complete else "FAILED",
        "plan": {"name": "standard", "epochs": 1, "pairs": 1500},
        "completed_pairs": 1500, "completed_updates": 94, "seed": 6304})
    write_json(folder / "reload_verification.json", {"status": "PASS"})
    return {"files_sha256": {name: p.sha256(folder / name) for name in
            ["adapter_model.safetensors", "adapter_config.json", "run_record.json", "reload_verification.json"]}}


def archive_fixture(path, updates=20, selected=True, corrupt_internal=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payloads = {"policy/adapter_config.json": p.json_bytes(config()),
                "policy/adapter_model.safetensors": b"synthetic adapter bytes; not a model",
                "summary.json": p.json_bytes({"status": "COMPLETE", "completed_updates": updates,
                                             "final_policy_for_task4": selected})}
    manifest = {name: hashlib.sha256(data).hexdigest() for name, data in payloads.items()}
    expected = {"files_sha256": dict(manifest)}
    if corrupt_internal:
        manifest["policy/adapter_model.safetensors"] = "0" * 64
    with zipfile.ZipFile(path, "w") as archive:
        for name, data in payloads.items():
            archive.writestr(name, data)
        archive.writestr("FILES_SHA256.json", p.json_bytes(manifest))
    receipt = {"archive": path.name, "sha256": p.sha256(path), "bytes": path.stat().st_size}
    write_json(path.with_suffix(".sha256.json"), receipt)
    expected["archive_receipt"] = receipt
    return expected


class InputTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)

    def tearDown(self):
        self.temporary.cleanup()

    def test_csv_preserves_exact_original_order_and_counts(self):
        path = self.root / "xstest.csv"
        value = p.verify_csv(path, csv_fixture(path))
        self.assertEqual(value["ordered_prompt_ids"], list(range(1000, 940, -1)))
        self.assertEqual(value["class_counts"], {"SAFE": 30, "UNSAFE": 30})

    def test_changed_course_csv_is_rejected(self):
        path = self.root / "xstest.csv"
        digest = csv_fixture(path)
        path.write_text(path.read_text() + "\n")
        with self.assertRaisesRegex(RuntimeError, "checksum"):
            p.verify_csv(path, digest)

    def test_duplicate_prompt_id_is_rejected(self):
        path = self.root / "xstest.csv"
        with self.assertRaisesRegex(RuntimeError, "Duplicate"):
            p.verify_csv(path, csv_fixture(path, duplicate=True))

    def test_unknown_benchmark_class_is_rejected(self):
        path = self.root / "xstest.csv"
        with self.assertRaisesRegex(RuntimeError, "Unexpected XSTest class"):
            p.verify_csv(path, csv_fixture(path, bad_class=True))

    def test_complete_dpo_identity_is_accepted(self):
        folder = self.root / "dpo"
        value = p.verify_dpo(folder, dpo_fixture(folder))
        self.assertEqual(value["epochs"], 1)

    def test_incomplete_dpo_run_rejected_even_with_matching_file_hashes(self):
        folder = self.root / "dpo"
        expected = dpo_fixture(folder, complete=False)
        with self.assertRaisesRegex(RuntimeError, "incomplete"):
            p.verify_dpo(folder, expected)

    def test_mismatched_dpo_adapter_bytes_rejected(self):
        folder = self.root / "dpo"
        expected = dpo_fixture(folder)
        (folder / "adapter_model.safetensors").write_bytes(b"other adapter")
        with self.assertRaisesRegex(RuntimeError, "file differs"):
            p.verify_dpo(folder, expected)

    def test_complete_standard_archive_accepted_without_model_loading(self):
        path = self.root / "final.zip"
        value = p.verify_final_archive(path, archive_fixture(path), "fixture")
        self.assertEqual(value["completed_updates"], 20)
        self.assertFalse(value["model_weights_loaded"])

    def test_eight_update_ablation_rejected_with_valid_archive_hashes(self):
        path = self.root / "final.zip"
        expected = archive_fixture(path, updates=8)
        with self.assertRaisesRegex(RuntimeError, "incomplete"):
            p.verify_final_archive(path, expected, "fixture")

    def test_endpoint_not_reserved_for_task4_rejected(self):
        path = self.root / "final.zip"
        expected = archive_fixture(path, selected=False)
        with self.assertRaisesRegex(RuntimeError, "not marked"):
            p.verify_final_archive(path, expected, "fixture")

    def test_internal_archive_corruption_rejected_even_with_valid_outer_receipt(self):
        path = self.root / "final.zip"
        expected = archive_fixture(path, corrupt_internal=True)
        with self.assertRaisesRegex(RuntimeError, "internal checksum"):
            p.verify_final_archive(path, expected, "fixture")

    def test_handoff_identity_mismatch_rejected(self):
        path = self.root / "final.zip"
        expected = archive_fixture(path)
        expected["files_sha256"]["policy/adapter_model.safetensors"] = "0" * 64
        with self.assertRaisesRegex(RuntimeError, "endpoint identity"):
            p.verify_final_archive(path, expected, "fixture")

    def test_outer_archive_receipt_mismatch_rejected(self):
        path = self.root / "final.zip"
        expected = archive_fixture(path)
        receipt = p.read_json(path.with_suffix(".sha256.json"))
        receipt["sha256"] = "0" * 64
        write_json(path.with_suffix(".sha256.json"), receipt)
        with self.assertRaisesRegex(RuntimeError, "existing Drive receipt"):
            p.verify_final_archive(path, expected, "fixture")

    def test_archive_traversal_rejected(self):
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, "w") as archive:
            archive.writestr("../escape", b"bad")
        stream.seek(0)
        with zipfile.ZipFile(stream) as archive, self.assertRaisesRegex(RuntimeError, "Unsafe"):
            p.validated_archive_names(archive)

    def test_archive_symlink_rejected(self):
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, "w") as archive:
            info = zipfile.ZipInfo("link")
            info.create_system = 3
            info.external_attr = (stat.S_IFLNK | 0o777) << 16
            archive.writestr(info, b"target")
        stream.seek(0)
        with zipfile.ZipFile(stream) as archive, self.assertRaisesRegex(RuntimeError, "symlink"):
            p.validated_archive_names(archive)

    def test_immutable_rerun_preserves_same_evidence_and_rejects_changed_value(self):
        path = self.root / "record.json"
        p.immutable_json(path, {"value": 1})
        before = path.read_bytes()
        p.immutable_json(path, {"value": 1})
        with self.assertRaisesRegex(RuntimeError, "preserved"):
            p.immutable_json(path, {"value": 2})
        self.assertEqual(path.read_bytes(), before)

    def test_source_change_rejected(self):
        (self.root / "source.py").write_text("original\n")
        write_json(self.root / "MANIFEST.json", {"source.py": p.sha256(self.root / "source.py")})
        p.verify_source(self.root)
        (self.root / "source.py").write_text("changed\n")
        with self.assertRaisesRegex(RuntimeError, "Source checksum"):
            p.verify_source(self.root)

    def make_integration_fixture(self):
        package, drive = self.root / "package", self.root / "drive"
        drive.mkdir()
        approval = {"approved": True, "drive_relative_root": "task4/experiment_v1"}
        expected = {"xstest": {"drive_relative_path": "course.csv", "sha256": csv_fixture(drive / "course.csv")},
                    "dpo": {"drive_relative_path": "dpo", **dpo_fixture(drive / "dpo")},
                    "ppo": {"drive_relative_path": "ppo/final.zip", **archive_fixture(drive / "ppo/final.zip")},
                    "grpo": {"drive_relative_path": "grpo/final.zip", **archive_fixture(drive / "grpo/final.zip")}}
        write_json(package / "docs/approval.json", approval)
        write_json(package / "provenance/expected_inputs.json", expected)
        write_json(package / "MANIFEST.json", {path.relative_to(package).as_posix(): p.sha256(path)
                   for path in package.rglob("*") if path.is_file()})
        return package, drive, drive / "task4/experiment_v1"

    def test_full_preflight_roundtrip_and_matching_rerun(self):
        package, drive, experiment = self.make_integration_fixture()
        with patch.object(p, "ROOT", package), patch.object(p, "require_cpu"), redirect_stdout(io.StringIO()):
            first = p.run(drive)
            contract_before = (experiment / "INPUT_IDENTITY_CONTRACT.json").read_bytes()
            second = p.run(drive)
        self.assertEqual(first["status"], "INPUT_IDENTITIES_VERIFIED")
        self.assertEqual(second["planned_units"]["responses"], 240)
        self.assertEqual(second["planned_units"]["manual_response_labels"], 240)
        self.assertEqual((experiment / "INPUT_IDENTITY_CONTRACT.json").read_bytes(), contract_before)
        self.assertEqual(len(list((experiment / "preflight_attempts").glob("*/REPORT.json"))), 2)

    def test_failed_attempt_preserves_three_successes_and_can_resume_after_input_restored(self):
        package, drive, experiment = self.make_integration_fixture()
        archive_path = drive / "grpo/final.zip"
        saved_bytes = archive_path.read_bytes()
        archive_path.unlink()
        with patch.object(p, "ROOT", package), patch.object(p, "require_cpu"), redirect_stdout(io.StringIO()):
            with self.assertRaises(FileNotFoundError):
                p.run(drive)
            reports = list((experiment / "preflight_attempts").glob("*/REPORT.json"))
            failed = p.read_json(reports[0])
            self.assertEqual(failed["status"], "FAILED_PRESERVED")
            self.assertEqual(len(failed["checks"]), 3)
            self.assertFalse((experiment / "INPUT_IDENTITY_CONTRACT.json").exists())
            archive_path.write_bytes(saved_bytes)
            success = p.run(drive)
        self.assertEqual(success["status"], "INPUT_IDENTITIES_VERIFIED")
        self.assertEqual(p.read_json(reports[0]), failed)

    def test_existing_unowned_experiment_is_preserved(self):
        package, drive, experiment = self.make_integration_fixture()
        experiment.mkdir(parents=True)
        sentinel = experiment / "existing.txt"
        sentinel.write_text("preserve me")
        with patch.object(p, "ROOT", package), patch.object(p, "require_cpu"), redirect_stdout(io.StringIO()):
            with self.assertRaisesRegex(RuntimeError, "ownership"):
                p.run(drive)
        self.assertEqual(sentinel.read_text(), "preserve me")
        self.assertFalse((experiment / "OWNER.json").exists())


if __name__ == "__main__":
    unittest.main()
