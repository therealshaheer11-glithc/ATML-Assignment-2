"""Verify Task 4's existing Drive inputs using the Python standard library.

This first stage does not install packages, download files, instantiate models,
extract training checkpoints, generate responses, or modify earlier tasks.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path, PurePosixPath
import platform
import shutil
import stat
import subprocess
import tempfile
from datetime import datetime, timezone
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha256_stream(stream):
    digest = hashlib.sha256()
    for block in iter(lambda: stream.read(1024 * 1024), b""):
        digest.update(block)
    return digest.hexdigest()


def sha256(path):
    with Path(path).open("rb") as stream:
        return sha256_stream(stream)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


def immutable_bytes(path, payload):
    """Publish, read back, and refuse changes to a previously saved artifact."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        require(path.is_file() and path.read_bytes() == payload,
                "Existing evidence differs; it was preserved: " + str(path))
        return
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as stream:
        temporary = Path(stream.name)
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    try:
        # A second check protects existing evidence in ordinary reruns. Run one
        # Colab session at a time; concurrent writers are unsupported.
        require(not path.exists(), "Another writer created: " + str(path))
        os.replace(temporary, path)
        require(path.read_bytes() == payload, "Saved-file readback differs: " + str(path))
    finally:
        temporary.unlink(missing_ok=True)


def immutable_json(path, value):
    immutable_bytes(path, json_bytes(value))


def verify_source(root=ROOT):
    root = Path(root)
    manifest = read_json(root / "MANIFEST.json")
    for name, digest in manifest.items():
        relative = PurePosixPath(name)
        require(not relative.is_absolute() and ".." not in relative.parts,
                "Unsafe source-manifest path: " + name)
        path = root / name
        require(path.is_file() and not path.is_symlink(), "Source file unavailable: " + name)
        require(sha256(path) == digest, "Source checksum differs: " + name)
    return {"manifest_sha256": sha256(root / "MANIFEST.json"), "files": len(manifest)}


def verify_csv(path, expected_sha256):
    require(sha256(path) == expected_sha256, "Fixed XSTest checksum differs")
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        require({"xstest_id", "prompt", "benchmark_class", "type"}.issubset(reader.fieldnames or []),
                "XSTest schema differs")
        rows = list(reader)
    require(bool(rows), "XSTest CSV is empty")
    ordered_ids, classes, categories = [], {"SAFE": 0, "UNSAFE": 0}, {}
    for row in rows:
        identifier = int(row["xstest_id"])
        require(identifier not in ordered_ids, "Duplicate XSTest ID: " + str(identifier))
        require(bool(row["prompt"].strip()) and bool(row["type"].strip()), "Empty XSTest content")
        label = row["benchmark_class"]
        require(label in classes, "Unexpected XSTest class: " + label)
        ordered_ids.append(identifier)
        classes[label] += 1
        key = label + "/" + row["type"]
        categories[key] = categories.get(key, 0) + 1
    require(min(classes.values()) >= 30, "XSTest lacks 30 examples in each audit class")
    return {"path": str(path), "sha256": expected_sha256, "prompts": len(rows),
            "ordered_prompt_ids": ordered_ids, "class_counts": classes,
            "class_and_type_counts": categories,
            "audit_ids_selected": False,
            "audit_selection_pending": "Run the unchanged NumPy course helper after environment validation"}


def verify_adapter_config(config):
    require(config.get("base_model_name_or_path") == "Qwen/Qwen2.5-1.5B-Instruct", "Adapter base differs")
    require(config.get("r") == 8 and config.get("lora_alpha") == 16, "Adapter LoRA dimensions differ")
    require(config.get("lora_dropout") == 0.05, "Adapter LoRA dropout differs")
    require(set(config.get("target_modules", [])) == {"q_proj", "v_proj"}, "Adapter target modules differ")
    require(config.get("peft_type") == "LORA" and config.get("task_type") == "CAUSAL_LM",
            "Adapter family differs")


def verify_dpo(folder, expected):
    folder = Path(folder)
    for name, digest in expected["files_sha256"].items():
        require(sha256(folder / name) == digest, "DPO standard file differs: " + name)
    verify_adapter_config(read_json(folder / "adapter_config.json"))
    record = read_json(folder / "run_record.json")
    require(record["status"] == "COMPLETE_RELOAD_VERIFIED", "DPO standard run is incomplete")
    require(record["plan"]["name"] == "standard" and record["plan"]["epochs"] == 1,
            "DPO endpoint is not the standard one-epoch run")
    require(record["completed_pairs"] == record["plan"]["pairs"] == 1500,
            "DPO standard pair coverage differs")
    require(record["completed_updates"] == 94 and record["seed"] == 6304,
            "DPO standard update count or seed differs")
    require(read_json(folder / "reload_verification.json")["status"] == "PASS",
            "DPO reload verification did not pass")
    return {"directory": str(folder), "files_sha256": expected["files_sha256"],
            "completed_pairs": 1500, "completed_updates": 94, "epochs": 1,
            "model_weights_loaded": False}


def validated_archive_names(archive):
    names = set()
    for info in archive.infolist():
        name = info.filename
        relative = PurePosixPath(name)
        require(not relative.is_absolute() and ".." not in relative.parts and "\\" not in name,
                "Unsafe checkpoint archive path: " + name)
        require(name not in names, "Duplicate checkpoint archive path: " + name)
        require(not stat.S_ISLNK(info.external_attr >> 16), "Checkpoint archive contains a symlink")
        require(not info.is_dir(), "Unexpected directory member in checkpoint archive")
        names.add(name)
    return names


def verify_final_archive(path, expected, policy):
    path = Path(path)
    receipt = read_json(path.with_suffix(".sha256.json"))
    digest = sha256(path)
    require(receipt["archive"] == path.name and receipt["sha256"] == digest,
            policy + " archive differs from its existing Drive receipt")
    require(receipt["bytes"] == path.stat().st_size, policy + " archive byte count differs")
    if expected.get("archive_receipt"):
        require(receipt == expected["archive_receipt"], policy + " receipt differs from the recorded handoff")
    with zipfile.ZipFile(path) as archive:
        names = validated_archive_names(archive)
        files = json.loads(archive.read("FILES_SHA256.json"))
        require(names == set(files) | {"FILES_SHA256.json"}, policy + " checkpoint file set differs")
        for name, expected_digest in files.items():
            with archive.open(name) as stream:
                require(sha256_stream(stream) == expected_digest, policy + " internal checksum differs: " + name)
        for name, expected_digest in expected["files_sha256"].items():
            require(files.get(name) == expected_digest, policy + " endpoint identity differs: " + name)
        # The handoff pins the exact RL adapter config bytes. Record its fields
        # rather than assuming its saved base path equals DPO's public model ID.
        # Earlier loaders used local snapshots; their saved metadata is retained.
        adapter_config = json.loads(archive.read("policy/adapter_config.json"))
        summary = json.loads(archive.read("summary.json"))
        require(summary["status"] == "COMPLETE" and summary["completed_updates"] == 20,
                policy + " standard endpoint is incomplete")
        require(summary.get("final_policy_for_task4") is True, policy + " endpoint is not marked for Task 4")
    return {"archive": str(path), "archive_sha256": digest, "archive_bytes": path.stat().st_size,
            "receipt_sha256": sha256(path.with_suffix(".sha256.json")),
            "all_internal_file_checksums_verified": True, "files_sha256": files,
            "recorded_adapter_config": adapter_config,
            "completed_updates": 20, "model_weights_loaded": False}


def environment_inventory():
    packages = {}
    for name in ["torch", "transformers", "tokenizers", "trl", "peft", "numpy", "pandas", "bitsandbytes"]:
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    return {"python": platform.python_version(), "platform": platform.platform(),
            "packages_before_installation": packages,
            "environment_installation_and_validation_pending": True}


def require_cpu():
    executable = shutil.which("nvidia-smi")
    if executable:
        result = subprocess.run([executable, "--query-gpu=name", "--format=csv,noheader"],
                                capture_output=True, text=True, timeout=15)
        require(not (result.returncode == 0 and result.stdout.strip()),
                "Select Colab runtime type CPU / hardware accelerator None before running this block")


def run(drive_root):
    require_cpu()
    source = verify_source(ROOT)
    expected = read_json(ROOT / "provenance/expected_inputs.json")
    approval = read_json(ROOT / "docs/approval.json")
    require(approval["approved"] is True, "Task 4 approval is absent")
    drive_root = Path(drive_root).resolve()
    require(drive_root.is_dir(), "Mount Google Drive first")
    experiment = drive_root / approval["drive_relative_root"]
    owner = experiment / "OWNER.json"
    owner_value = {"task": "ATML_PA2_TASK4", "approval_sha256": sha256(ROOT / "docs/approval.json")}
    require(not experiment.exists() or owner.is_file(), "Existing Task 4 folder has no matching ownership receipt")
    immutable_json(owner, owner_value)
    release = experiment / "preflight_releases" / source["manifest_sha256"]
    for name in read_json(ROOT / "MANIFEST.json"):
        immutable_bytes(release / name, (ROOT / name).read_bytes())
    immutable_bytes(release / "MANIFEST.json", (ROOT / "MANIFEST.json").read_bytes())
    attempt = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    report = {"format": "ATML_TASK4_INPUT_CHECK_V1", "attempt_utc": attempt,
              "status": "RUNNING", "source": source, "approval": approval,
              "environment": environment_inventory(), "checks": {},
              "model_weights_loaded": False, "policy_training_performed": False,
              "response_generation_performed": False, "judging_performed": False}
    checks = [
        ("xstest", lambda: verify_csv(drive_root / expected["xstest"]["drive_relative_path"], expected["xstest"]["sha256"])),
        ("dpo_standard", lambda: verify_dpo(drive_root / expected["dpo"]["drive_relative_path"], expected["dpo"])),
        ("ppo_standard", lambda: verify_final_archive(drive_root / expected["ppo"]["drive_relative_path"], expected["ppo"], "PPO")),
        ("grpo_standard", lambda: verify_final_archive(drive_root / expected["grpo"]["drive_relative_path"], expected["grpo"], "GRPO")),
    ]
    try:
        for index, (name, check) in enumerate(checks, start=1):
            print(f"Checking {index}/{len(checks)}: {name}", flush=True)
            result = check()
            report["checks"][name] = result
            immutable_json(experiment / "preflight_attempts" / attempt / f"{index}_{name}.json", result)
            print(f"PASS {index}/{len(checks)}: {name}", flush=True)
        count = report["checks"]["xstest"]["prompts"]
        report["planned_units"] = {"prompts_per_policy": count, "policies": 4,
            "generation_batches_per_policy": (count + 3) // 4,
            "responses": 4 * count, "judge_calls": 4 * count,
            "audit_prompt_ids": 60, "manual_response_labels": 240}
        contract = {"approval_sha256": owner_value["approval_sha256"], "inputs": report["checks"],
                    "planned_units": report["planned_units"]}
        immutable_json(experiment / "INPUT_IDENTITY_CONTRACT.json", contract)
        report["status"] = "INPUT_IDENTITIES_VERIFIED"
    except Exception as error:
        report["status"] = "FAILED_PRESERVED"
        report["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        report_path = experiment / "preflight_attempts" / attempt / "REPORT.json"
        immutable_json(report_path, report)
        print("Saved readback-verified report:", report_path, flush=True)
    print("INPUT CHECKS COMPLETE: 4/4. Environment/model preparation remains pending.", flush=True)
    print("PLANNED WORKLOAD:", json.dumps(report["planned_units"], sort_keys=True), flush=True)
    print("This block generated 0 responses, judged 0 responses, and performed 0 training updates.", flush=True)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--drive-root", default="/content/drive/MyDrive")
    run(parser.parse_args().drive_root)
