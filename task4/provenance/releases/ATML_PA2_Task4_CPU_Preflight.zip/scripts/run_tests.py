"""Run synthetic CPU checks and save actual outcomes and tested source hashes."""
import hashlib
import io
import json
from pathlib import Path
import sys
import unittest
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main():
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    validation = ROOT / "validation"
    validation.mkdir(exist_ok=True)
    transcript = stream.getvalue()
    (validation / "local_tests.txt").write_text(transcript)
    source_hashes = {path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
                     for directory in ["scripts", "tests"] for path in sorted((ROOT / directory).glob("*.py"))}
    report = {"utc": datetime.now(timezone.utc).isoformat(), "tests_run": result.testsRun,
              "failures": len(result.failures), "errors": len(result.errors), "skips": len(result.skipped),
              "passed": result.wasSuccessful(), "synthetic_fixtures_only": True,
              "actual_colab_or_drive_verified": False, "model_inference_or_training": False,
              "tested_source_sha256": source_hashes,
              "transcript_sha256": hashlib.sha256(transcript.encode()).hexdigest()}
    (validation / "local_tests.json").write_text(json.dumps(report, indent=2) + "\n")
    print(transcript, end="")
    print(json.dumps(report, indent=2))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
