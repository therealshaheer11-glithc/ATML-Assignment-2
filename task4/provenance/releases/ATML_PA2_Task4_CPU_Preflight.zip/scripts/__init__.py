"""Task 4 reproducibility entry points."""
