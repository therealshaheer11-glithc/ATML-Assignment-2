# ATML PA2 Task 4: safety calibration

This is the approved first CPU input-verification stage. It is not the completed Task 4 evaluation pipeline.

The user approved recommendations 1-4 on 11 October 2026 and explicitly requested documentation of everything. Exact approval wording is in `docs/approval.json`. Synced project references under `sources/` remain unchanged.

Read `docs/REQUIREMENTS.md`, `docs/DECISIONS.md`, `docs/PROGRESS.md`, and `docs/CHANGELOG.md`. The supplied code under `course_reference/` is preserved byte-for-byte for provenance; its student TODOs are not completed by this release.

## First Colab block

Use CPU / hardware accelerator None. Upload `ATML_PA2_Task4_CPU_Preflight.zip` when the single launch cell requests it, authorize your own Google Drive mount, and return the complete output. The cell verifies the ZIP SHA-256, extracts a new local working copy, and runs `scripts/preflight.py` in a separate process.

The script checks the fixed course XSTest CSV and the standard DPO, PPO and GRPO endpoints at their recorded Drive paths. It reads adapter/archive bytes for checksums but never instantiates model weights or deserializes pickle/checkpoint tensors. It does not install packages, download data, run generation, invoke the judge, or alter prior-task files.

It saves the approval, documentation and exact preflight release under the approved Drive root. Successful checks are saved individually. Each attempt gets a distinct report; a failure preserves earlier successful checks and its error. A matching rerun is safe. A conflicting existing file or experiment owner causes a stop and leaves that file unchanged. Run one Colab session at a time.

Missing or moved inputs cause a stop for review. No substitute checkpoint, new download, receipt repair, or relaxed checksum is attempted automatically.

## Exact entry point

`python scripts/preflight.py --drive-root /content/drive/MyDrive`

Run from this release's root. This uses only Python's standard library. Environment versions are inventoried without importing model libraries; installing and validating the released model environment remains a later CPU block.

## Persistence

Drive root: `MyDrive/ATML-Assignment-2/task4/experiment_v1`.

- `OWNER.json`: approval identity for this experiment.
- `preflight_releases/<manifest SHA-256>/`: immutable source, documentation, provenance, local test evidence, and source manifest.
- `preflight_attempts/<UTC attempt>/`: individual successful check records and `REPORT.json`, including failures.
- `INPUT_IDENTITY_CONTRACT.json`: written only after all four input groups pass; changed identities are rejected.

This first release creates no policy responses, judge labels, or manual annotations. A successful input check is not a claim that the full environment, base-policy weights, judge weights, or Task 4 experiment has been validated.

## Source attribution

Course authors provide the preserved model/data/generation helpers, fixed judge and audit-ID function at commit `1d64ac65acd5e45d1e4e1f415edc80455e21274e`. Large course assets are from dataset `AbDu11aHHH/ATML-PA2-assets`, revision `0b350481fb03f5525a35bcdec4131bd4fe487f98`. The existing Task 1-3 evidence supplies adapter identities; it is metadata about the user's completed runs, not a new experiment.

The first-stage verifier, release packaging, documentation and synthetic CPU checks were created with OpenAI Codex coding assistance under the recorded approval. The student remains responsible for understanding submitted code. No public weights or raw course dataset is included in this package.
