"""Verify saved successful restart, then load the approved models sequentially."""
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from loading_guards import require,verify_snapshot,POLICIES
EXPERIMENT=Path('/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1')
LOCAL=Path('/content/task4_isolated_runtime_v1')
SOURCES={
 'preflight':'9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65',
 'isolated_gpu':'7a5673003062448f66a3c43763340483968234f42d2659d517c47d7e33de6e8a',
 'isolated_recheck':'999b26996654587e6ddfda1a146cac4ac38b421f0856f6134abd2ac61433c363',
 'post_restart':'b05d32bf434b196d2b01b3477319fbdb32d71cd33f281d57c820e8a61b7577cc',
 'base_repair_recheck':'4955a6f76dfbfc5b2f92825fce309eabbe4c209cf576b73a7d182ff0b101f09a',
 'base_layout_diagnostic':'961b9825e7a34823a8f3930e597149c425427d494f8d9c9b10652e5998a734be',
 'gpu_environment':'d941ecb6c16ec91a942b319167826007f5124b0dedc10d2a337b3b783ff4015b',
 'orchestration':'35ca690761d2bfda0992ff37855b16fc72c03ffd4b47afaa81edc533ab7a5f65',
 'model_inputs':'50696b4becd13a8f1594896d384e718fa8d3984e4fb5785bec977a6b35eeac7d'}
POST_RESTART_ATTEMPT='20261011T165139.982919Z'


def read(path):return json.loads(Path(path).read_text())


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module
    spec.loader.exec_module(module);return module


def main():
    first=EXPERIMENT/'preflight_releases'/SOURCES['preflight']
    require(hashlib.sha256((first/'MANIFEST.json').read_bytes()).hexdigest()==SOURCES['preflight'] and
            hashlib.sha256((first/'scripts/preflight.py').read_bytes()).hexdigest()==read(first/'MANIFEST.json')['scripts/preflight.py'],
            'Original sealed source/helper differs')
    preflight=load('task4_model_validation_persistence',first/'scripts/preflight.py')
    digest,save,save_bytes=preflight.sha256,preflight.immutable_json,preflight.immutable_bytes
    preflight.verify_source(first)
    identity=preflight.verify_source(ROOT)['manifest_sha256']
    require(read(EXPERIMENT/'OWNER.json')['approval_sha256']==digest(first/'docs/approval.json'),'Task owner differs')
    require(digest(ROOT/'TASK4_APPROVAL.json')==digest(first/'docs/approval.json') and
            read(ROOT/'TASK4_APPROVAL.json')['approved'] is True,'Original model preparation approval differs')
    release=EXPERIMENT/'model_loading_releases'/identity
    for name in [*read(ROOT/'MANIFEST.json'),'MANIFEST.json']:save_bytes(release/name,(ROOT/name).read_bytes())
    attempt_id=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    attempt=EXPERIMENT/'model_loading_attempts'/attempt_id;attempt.mkdir(parents=True,exist_ok=False)
    report={'format':'ATML_TASK4_MODEL_LOADING_ATTEMPT_V1','status':'RUNNING','attempt_utc':attempt_id,
            'source_manifest_sha256':identity,'commands':[],'model_load_attempts_started':[],
            'models_successfully_validated':[],'model_load_calls_returned':0,
            'package_changes_downloads_or_training_performed':False,
            'forward_passes':0,'task4_responses_generated':0,'task4_judgments_produced':0,'human_labels_assigned':0,
            'gpu_exceptions_accepted':[]}

    def command(argv,name,env):
        event={'stage':name,'argv':[str(value) for value in argv]};save(attempt/(name+'_COMMAND.json'),event)
        print('Task 4 model validation:',name,flush=True)
        with (attempt/(name+'.log')).open('x') as log:
            process=subprocess.Popen(event['argv'],cwd='/content',env=env,stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT,text=True,bufsize=1)
            for line in process.stdout:log.write(line);log.flush();print(line,end='',flush=True)
            event['returncode']=process.wait()
        event['log_sha256']=digest(attempt/(name+'.log'));save(attempt/(name+'_RESULT.json'),event)
        report['commands'].append(event)
        require(event['returncode']==0,name+' failed; review saved output before continuing; no automatic fallback')

    try:
        save(attempt/'START.json',report)
        folders={}
        for kind,source in SOURCES.items():
            folder=EXPERIMENT/(kind+'_releases')/source
            require(digest(folder/'MANIFEST.json')==source,'Sealed source differs: '+kind)
            preflight.verify_source(folder);folders[kind]=folder
        original=load('task4_model_isolation_guards',folders['isolated_gpu']/'guards.py')
        isolation=load('task4_model_child_policy',folders['isolated_recheck']/'isolation.py')
        load('repair_guards',folders['base_repair_recheck']/'repair_guards.py')
        layout_guards=load('task4_model_base_layout',folders['base_repair_recheck']/'layout_guards.py')
        gates=load('task4_model_gpu_gates',folders['gpu_environment']/'gates.py')
        previous_folder=EXPERIMENT/'post_restart_attempts'/POST_RESTART_ATTEMPT
        previous=read(previous_folder/'REPORT.json')
        require(previous['status']=='BOTH_INTERPRETERS_VALIDATED_AFTER_RESTART_NO_INFERENCE' and
                previous['source_manifest_sha256']==SOURCES['post_restart'] and previous['kernel_restart_observed'] is True and
                previous['base_full_dependency_check_passed'] and previous['isolated_full_dependency_check_passed'] and
                previous['synthetic_checks_passed']==37 and previous['gpu_exceptions_accepted']==[],
                'Saved post-restart success differs')
        for name,expected in previous['artifact_sha256'].items():
            require(digest(isolation.safe_artifact(previous_folder,name))==expected,'Saved post-restart artifact differs: '+name)
        environment_path=EXPERIMENT/'GPU_ENVIRONMENT_CONTRACT.json'
        require(digest(environment_path)==previous['combined_gpu_environment_contract_sha256'],
                'Combined GPU environment contract differs')
        environment=read(environment_path)
        require(environment['format']=='ATML_TASK4_GPU_ENVIRONMENT_V2' and environment['source_manifest_sha256']==SOURCES['post_restart'] and
                environment['base_full_dependency_check_passed'] and environment['isolated_full_dependency_check_passed'] and
                environment['kernel_restart_observed_and_notebook_tools_validated'] and
                environment['gpu_model_loading_validation_pending'] and environment['gpu_exceptions_accepted']==[],
                'Combined GPU environment validation incomplete')
        required_contracts={
            'ISOLATED_GPU_ENVIRONMENT_CONTRACT.json':environment['isolated_environment_contract_sha256'],
            'COLAB_BASE_REPAIR_CONTRACT.json':environment['colab_base_repair_contract_sha256'],
            'ISOLATED_CHILD_ENVIRONMENT_CONTRACT.json':environment['isolated_child_environment_contract_sha256'],
            'CPU_ORCHESTRATION_VALIDATION_CONTRACT.json':environment['cpu_orchestration_contract_sha256'],
            'CPU_MODEL_INPUT_CONTRACT.json':environment['model_input_contract_sha256']}
        for name,expected in required_contracts.items():require(digest(EXPERIMENT/name)==expected,'Bound contract differs: '+name)
        inputs_path=EXPERIMENT/'CPU_MODEL_INPUT_CONTRACT.json';inputs=read(inputs_path)
        require(inputs['source_manifest_sha256']==SOURCES['model_inputs'] and inputs['policy_order']==POLICIES and
                inputs['sft_adapter'] is None,'Frozen model inputs differ')
        for filename,field in [('BASE_MODEL_REFERENCE.json','base_model_reference_sha256'),
                               ('JUDGE_SNAPSHOT_CONTRACT.json','judge_snapshot_contract_sha256'),
                               ('INPUT_IDENTITY_CONTRACT.json','input_contract_sha256'),
                               ('AUDIT_ID_CONTRACT.json','audit_id_contract_sha256')]:
            require(digest(EXPERIMENT/filename)==inputs[field],'Frozen input identity differs: '+filename)
            required_contracts[filename]=inputs[field]
        require(digest(first/'course_reference/requirements.txt')==environment['course_requirements_sha256'],
                'Course requirements differ')
        require(LOCAL.is_dir() and not LOCAL.is_symlink(),'Owned isolated runtime missing; keep same A100 connected')
        owner=read(LOCAL/'.task4_isolation_owner.json')
        isolated=read(EXPERIMENT/'ISOLATED_GPU_ENVIRONMENT_CONTRACT.json')
        require(owner['source_manifest_sha256']==SOURCES['isolated_gpu'] and owner['directory']==str(LOCAL) and
                owner['approval_sha256']==environment['approval_sha256'] and
                owner['wheelhouse_contract_sha256']==isolated['wheelhouse_contract_sha256'] and
                owner['system_site_packages'] is False and environment['python_executable']==str(LOCAL/'bin/python') and
                sys.executable==environment['base_python_executable'],'Owned interpreter identity differs')
        policy=read(EXPERIMENT/'ISOLATED_CHILD_ENVIRONMENT_CONTRACT.json')
        require(policy==isolated['isolated_child_environment_policy'] and
                policy['source_manifest_sha256']==SOURCES['isolated_recheck'] and
                policy['recognized_removed_value']==isolation.NOTEBOOK_BACKEND and
                policy['replacement_backend_forced'] is False and policy['parent_environment_modified'] is False,
                'Child environment policy differs')
        parent_backend=os.environ.get('MPLBACKEND');base_env=original.clean_environment(os.environ)
        child_env=isolation.child_environment(os.environ,original.clean_environment)
        pins=environment['isolated_package_versions'];python=LOCAL/'bin/python'
        command(['nvidia-smi','--query-gpu=name,memory.total,driver_version,uuid','--format=csv,noheader,nounits'],
                'nvidia_inventory',base_env)
        hardware=gates.parse_a100_inventory((attempt/'nvidia_inventory.log').read_text())
        require(hardware==read(previous_folder/'A100_HARDWARE.json'),'A100 hardware/runtime differs')
        save(attempt/'A100_HARDWARE.json',hardware)
        inspect=folders['isolated_gpu']/'inspect_python.py'
        details=read(folders['base_repair_recheck']/'REVIEWED_LAYOUT_DETAILS.json')
        reviewed=read(previous_folder/'BASE_AFTER_LAYOUT.json')
        base_contract=read(EXPERIMENT/'COLAB_BASE_REPAIR_CONTRACT.json')

        def inspect_base(label):
            command([sys.executable,'-I','-B',inspect,attempt/(label+'_INVENTORY.json')],label+'_inventory',base_env)
            command([sys.executable,'-I','-B',folders['base_repair_recheck']/'scan_base_layout.py',
                     folders['base_layout_diagnostic']/'scan_layout.py',attempt/(label+'_LAYOUT.json')],label+'_layout',base_env)
            inventory,layout=read(attempt/(label+'_INVENTORY.json')),read(attempt/(label+'_LAYOUT.json'))
            versions=layout_guards.validate_reviewed_base_inventory(inventory,layout,reviewed,details,owner['base_python_executable'])
            require(versions==base_contract['complete_base_package_versions'] and layout==reviewed,
                    'Base environment differs from successful restart')
            return inventory,layout

        base_before,layout_before=inspect_base('BASE_BEFORE')
        command([python,'-I','-B',inspect,attempt/'ISOLATED_BEFORE.json'],'isolated_before',child_env)
        iso_before=read(attempt/'ISOLATED_BEFORE.json');original.validate_inventory(iso_before,pins,LOCAL,complete=True)
        require(iso_before==read(previous_folder/'ISOLATED_INVENTORY_AFTER.json'),'Isolated inventory changed after restart')
        for label,executable,env in [('base',sys.executable,base_env),('isolated',python,child_env)]:
            command([executable,'-I','-B','-m','pip','--disable-pip-version-check','check'],label+'_full_dependency_check',env)
            require((attempt/(label+'_full_dependency_check.log')).read_text().strip()=='No broken requirements found.',
                    'Clean full dependency check required: '+label)
        snapshots={}
        for role,filename in [('policy','BASE_MODEL_REFERENCE.json'),('judge','JUDGE_SNAPSHOT_CONTRACT.json')]:
            entry=read(EXPERIMENT/filename)
            require(entry['revision']==('989aa7980e4cf806f80c7fef2b1adb7bc71aa306' if role=='policy' else
                                        'aa8e72537993ba99e69dfaafa59ed015b17504d1'),'Pinned model revision differs')
            print('Rehashing saved model snapshot:',role,'; files:',len(entry['verified_files']),flush=True)
            snapshots[role]=verify_snapshot(entry['directory'],entry['verified_files'],digest)
            print('Saved model snapshot SHA-256 verified:',role,flush=True)
        save(attempt/'VERIFIED_MODEL_FILES.json',snapshots)
        for role,entry in inputs['prepared_adapters'].items():
            require(role in POLICIES[1:] and set(entry['files_sha256'])=={'adapter_model.safetensors','adapter_config.json'},
                    'Adapter file coverage differs')
            folder=Path(entry['directory'])
            require(folder==EXPERIMENT/'prepared_adapters'/role and folder.is_dir() and not folder.is_symlink() and
                    {p.name for p in folder.iterdir()}==set(entry['files_sha256']),'Prepared adapter directory differs')
            for name,expected in entry['files_sha256'].items():
                require(not (folder/name).is_symlink() and digest(folder/name)==expected,'Prepared adapter bytes differ: '+role+'/'+name)
        require(set(inputs['prepared_adapters'])==set(POLICIES[1:]),'Prepared adapter role coverage differs')
        signatures={}
        for role in [*POLICIES,'judge']:
            report['model_load_attempts_started'].append(role)
            save(attempt/(role.upper()+'_LOAD_STARTED.json'),{'role':role,'source_manifest_sha256':identity})
            output=attempt/(role.upper()+'_MODEL.json')
            try:
                command([python,'-I','-B','-u',ROOT/'probe_models.py',first/'course_reference',inputs_path,role,output],
                        role+'_model_loading',child_env)
            finally:
                if output.exists() and read(output)['model_load_completed']:report['model_load_calls_returned']+=1
            result=read(output)
            require(result['status']=='MODEL_LOADED_AND_INSPECTED_NO_INFERENCE' and
                    result['forward_passes']==result['generate_calls']==result['responses_generated']==result['judgments_produced']==0,
                    'Model load validation incomplete')
            signatures[role]={key:value for key,value in result.items() if not key.startswith('cuda_peak_')}
            report['models_successfully_validated'].append(role)
            save(attempt/('MODELS_COMPLETED_'+str(len(signatures))+'.json'),{'roles':report['models_successfully_validated'],
                   'inspection_sha256':{name:digest(attempt/(name.upper()+'_MODEL.json')) for name in signatures}})
            print('Models validated:',len(signatures),'/5; responses 0/1800; judgments 0/1800.',flush=True)
        command([python,'-I','-B',inspect,attempt/'ISOLATED_AFTER.json'],'isolated_after',child_env)
        iso_after=read(attempt/'ISOLATED_AFTER.json');original.validate_inventory(iso_after,pins,LOCAL,complete=True)
        base_after,layout_after=inspect_base('BASE_AFTER')
        require(iso_after==iso_before and base_after==base_before and layout_after==layout_before and
                os.environ.get('MPLBACKEND')==parent_backend,'Environments changed during model validation')
        for filename,expected in required_contracts.items():require(digest(EXPERIMENT/filename)==expected,'Historical contract changed: '+filename)
        require(digest(environment_path)==previous['combined_gpu_environment_contract_sha256'],'Combined environment contract changed')
        contract={'format':'ATML_TASK4_MODEL_LOADING_VALIDATION_V1','source_manifest_sha256':identity,
                  'task4_approval_sha256':digest(first/'docs/approval.json'),
                  'gpu_environment_contract_sha256':digest(environment_path),
                  'model_input_contract_sha256':digest(inputs_path),
                  'cpu_orchestration_contract_sha256':environment['cpu_orchestration_contract_sha256'],
                  'post_restart_report_sha256':digest(previous_folder/'REPORT.json'),
                  'policy_order':POLICIES,'model_validation_order':[*POLICIES,'judge'],
                  'validated_models':signatures,'all_five_models_loaded_and_inspected':True,
                  'snapshot_and_adapter_checksums_verified':True,'all_loaded_adapter_tensors_verified':True,
                  'base_and_isolated_environment_unchanged':True,'gpu_exceptions_accepted':[],
                  'forward_passes_performed':False,'generation_or_judging_performed':False,
                  'actual_inference_execution_pending':True}
        save(EXPERIMENT/'MODEL_LOADING_VALIDATION_CONTRACT.json',contract)
        report.update({'status':'FIVE_MODELS_LOADED_AND_VALIDATED_NO_INFERENCE',
                       'model_loading_validation_contract_sha256':digest(EXPERIMENT/'MODEL_LOADING_VALIDATION_CONTRACT.json'),
                       'gpu_environment_contract_sha256':digest(environment_path),
                       'model_input_contract_sha256':digest(inputs_path),
                       'post_restart_report_sha256':digest(previous_folder/'REPORT.json'),
                       'base_and_isolated_environment_unchanged':True})
        print('Four policies and original NF4 judge: load-only validation PASS, 5/5.',flush=True)
        print('No forward passes/generation/judging/training. Responses 0/1800; judgments 0/1800; human labels 0/240.',flush=True)
    except BaseException as error:
        report.update({'status':'MODEL_LOADING_VALIDATION_FAILED_PRESERVED',
                       'error':{'type':type(error).__name__,'message':str(error)}})
        raise
    finally:
        report['artifact_sha256']={p.relative_to(attempt).as_posix():digest(p) for p in attempt.rglob('*') if p.is_file()}
        save(attempt/'REPORT.json',report)
        print('Saved model-loading validation report:',attempt/'REPORT.json',flush=True)
        print('Status:',report['status'],flush=True)


if __name__=='__main__':main()
