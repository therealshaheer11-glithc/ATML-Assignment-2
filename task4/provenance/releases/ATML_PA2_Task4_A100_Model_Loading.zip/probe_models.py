"""Fresh isolated process: load exactly one approved model, inspect, then exit."""
import gc
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

# -I intentionally omits this directory; add only our verified release explicitly.
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from loading_guards import (require,validate_defaults,validate_parameter_summary,
                            validate_adapter_keys,validate_judge_quantization)


def read(path):return json.loads(Path(path).read_text())


def main():
    course,inputs_path,role,output=Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3],Path(sys.argv[4])
    require(role in {'sft','dpo','ppo','grpo','judge'},'Unknown model role')
    sys.path.insert(0,str(course))
    # Use the original source helper for atomic immutable reports.
    spec=importlib.util.spec_from_file_location('task4_model_probe_persistence',course.parent/'scripts/preflight.py')
    persistence=importlib.util.module_from_spec(spec);spec.loader.exec_module(persistence)
    save=persistence.immutable_json
    import torch
    from common.models import load_policy,load_tokenizer
    from task4_safety.judge_responses import load_judge
    from peft import PeftModel,get_peft_model_state_dict
    from safetensors.torch import load_file
    import bitsandbytes as bnb
    inputs=read(inputs_path)
    cfg=dict(inputs['course_configuration'])
    experiment=inputs_path.parent
    base,judge=read(experiment/'BASE_MODEL_REFERENCE.json'),read(experiment/'JUDGE_SNAPSHOT_CONTRACT.json')
    cfg['base_model']=base['directory'];cfg['ai_judge_model']=judge['directory']
    require(torch.cuda.is_available() and torch.cuda.get_device_capability(0)==(8,0) and
            'A100' in torch.cuda.get_device_name(0),'A100 required')
    torch.cuda.reset_peak_memory_stats()
    model=None;tokenizer=None
    result={'format':'ATML_TASK4_MODEL_LOAD_PROBE_V1','role':role,'status':'RUNNING',
            'forward_passes':0,'generate_calls':0,'responses_generated':0,'judgments_produced':0,
            'training_performed':False,'loader_settings_changed':False,'model_load_completed':False}
    try:
        print('Loading approved model with original course helper:',role,flush=True)
        if role=='judge':
            tokenizer,model=load_judge(cfg)
        else:
            adapter=None if role=='sft' else inputs['prepared_adapters'][role]['directory']
            tokenizer=load_tokenizer(cfg['base_model'])
            model=load_policy(cfg,adapter_path=adapter,trainable=False)
        result['model_load_completed']=True
        require(not model.training and all(not module.training for module in model.modules()),
                'Loaded model or submodule is not in evaluation mode')
        metadata=inputs['tokenizer_and_generation_metadata']['judge' if role=='judge' else 'policy']
        tok=metadata['tokenizer']
        require(tokenizer.is_fast and tokenizer.padding_side=='left' and
                tokenizer.pad_token_id==tok['pad_token_id'] and tokenizer.eos_token_id==tok['eos_token_id'],
                'Loaded tokenizer settings differ from frozen CPU checks')
        defaults=model.generation_config.to_dict()
        validate_defaults(defaults,metadata['generation_defaults_from_pinned_transformers'])
        summary={}
        for name,parameter in model.named_parameters():
            key=(str(parameter.dtype),str(parameter.device),'lora_' in name,bool(parameter.requires_grad))
            item=summary.setdefault(key,{'dtype':key[0],'device':key[1],'is_lora':key[2],
                                        'requires_grad':key[3],'tensors':0,'count':0})
            item['tensors']+=1;item['count']+=parameter.numel()
        summary=sorted(summary.values(),key=lambda item:(item['is_lora'],item['dtype'],item['device'],item['requires_grad']))
        validate_parameter_summary(summary,role)
        result.update({'eval_mode_verified':True,'tokenizer_settings_verified':True,
                       'parameter_summary':summary,'loaded_generation_defaults':defaults,
                       'inherited_generation_defaults_match_frozen_cpu_preview':True,
                       'fixed_course_generate_kwargs':metadata['fixed_course_generate_kwargs'],
                       'effective_generation_config_preview':{**defaults,**metadata['fixed_course_generate_kwargs']}})
        if role=='sft':
            require(not isinstance(model,PeftModel) and not any('lora_' in name for name,_ in model.named_parameters()),
                    'SFT must be the untouched base with no adapter')
            result['adapter']=None
        elif role!='judge':
            require(isinstance(model,PeftModel),'Expected standard adapter was not loaded')
            active=list(model.active_adapters)
            require(active==['default'] and set(model.peft_config)=={'default'},'Unexpected active/multiple adapters')
            expected=load_file(str(Path(inputs['prepared_adapters'][role]['directory'])/'adapter_model.safetensors'),device='cpu')
            actual=get_peft_model_state_dict(model,adapter_name='default',save_embedding_layers=False)
            validate_adapter_keys(actual,expected)
            tensor_metadata={}
            for name,saved in expected.items():
                loaded=actual[name].detach().cpu()
                require(tuple(saved.shape)==tuple(loaded.shape) and
                        torch.equal(loaded,saved.to(dtype=loaded.dtype)),
                        'Loaded adapter tensor differs from checkpoint after the course loader dtype conversion: '+name)
                tensor_metadata[name]={'shape':list(loaded.shape),'saved_dtype':str(saved.dtype),'loaded_dtype':str(loaded.dtype)}
            result['adapter']={'active':active,'tensor_count':len(actual),
                'all_tensor_values_match_saved_checkpoint_after_inherited_dtype_conversion':True,
                'tensor_metadata':tensor_metadata,'saved_config_unchanged':True}
            del expected,actual,loaded
        else:
            require(bool(getattr(model,'is_loaded_in_4bit',False)),'Judge is not actually loaded in 4-bit')
            qconfig=model.config.quantization_config.to_dict()
            modules=[]
            for name,module in model.named_modules():
                if isinstance(module,bnb.nn.Linear4bit):
                    modules.append({'name':name,'compute_dtype':str(module.compute_dtype),
                                    'quant_type':module.weight.quant_type,'device':str(module.weight.device),
                                    'quant_state_present':module.weight.quant_state is not None})
            validate_judge_quantization(qconfig,modules)
            result.update({'quantization_config':qconfig,'quantized_modules':modules,
                           'device_map':getattr(model,'hf_device_map',None)})
        torch.cuda.synchronize()
        result.update({'status':'MODEL_LOADED_AND_INSPECTED_NO_INFERENCE',
                       'cuda_peak_allocated_bytes':torch.cuda.max_memory_allocated(),
                       'cuda_peak_reserved_bytes':torch.cuda.max_memory_reserved()})
        print('Model load/placement/eval/settings verified:',role,'; no forward pass or generation.',flush=True)
    except BaseException as error:
        result.update({'status':'MODEL_LOAD_VALIDATION_FAILED_PRESERVED',
                       'error':{'type':type(error).__name__,'message':str(error)}})
        raise
    finally:
        save(output,result)
        del model,tokenizer
        gc.collect()
        if torch.cuda.is_available():torch.cuda.empty_cache()
        print('Saved model inspection:',output,flush=True)


if __name__=='__main__':main()
