import ast
import hashlib
from pathlib import Path
import tempfile
import unittest
from loading_guards import (verify_snapshot,validate_defaults,validate_parameter_summary,
                            validate_adapter_keys,validate_judge_quantization)

class LoadingIntegrity(unittest.TestCase):
    def test_weight_bytes_must_match_not_just_size(self):
        with tempfile.TemporaryDirectory() as directory:
            folder=Path(directory);path=folder/'model.safetensors';path.write_bytes(b'abcd')
            files={path.name:{'bytes':4,'sha256':hashlib.sha256(b'abcd').hexdigest()}}
            digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
            self.assertEqual(verify_snapshot(folder,files,digest),files)
            path.write_bytes(b'bad!')
            with self.assertRaisesRegex(RuntimeError,'checksum'):verify_snapshot(folder,files,digest)

    def test_missing_extra_and_symlinked_files_stop(self):
        with tempfile.TemporaryDirectory() as directory:
            folder=Path(directory);path=folder/'config.json';path.write_bytes(b'{}')
            files={'config.json':{'bytes':2,'sha256':hashlib.sha256(b'{}').hexdigest()}}
            digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
            extra=folder/'extra.json';extra.write_bytes(b'{}')
            with self.assertRaisesRegex(RuntimeError,'coverage'):verify_snapshot(folder,files,digest)
            extra.unlink();path.unlink()
            with self.assertRaisesRegex(RuntimeError,'coverage'):verify_snapshot(folder,files,digest)
            outside=folder.parent/(folder.name+'_target');outside.write_bytes(b'{}')
            try:
                path.symlink_to(outside)
                with self.assertRaisesRegex(RuntimeError,'size or path'):verify_snapshot(folder,files,digest)
            finally:outside.unlink()

    def test_inherited_generation_drift_requires_review(self):
        expected={'num_return_sequences':1,'temperature':0.6,'repetition_penalty':1.05}
        validate_defaults(dict(expected),expected)
        with self.assertRaisesRegex(RuntimeError,'defaults differ'):
            validate_defaults({**expected,'repetition_penalty':1.0},expected)

    def test_cpu_offload_and_policy_precision_drift_rejected(self):
        item={'device':'cuda:0','dtype':'torch.float16','is_lora':False,'count':2}
        validate_parameter_summary([item],'sft')
        with self.assertRaisesRegex(RuntimeError,'not on CUDA'):
            validate_parameter_summary([{**item,'device':'cpu'}],'sft')
        with self.assertRaisesRegex(RuntimeError,'precision differs'):
            validate_parameter_summary([{**item,'dtype':'torch.float32'}],'sft')

    def test_inherited_lora_upcasting_is_preserved(self):
        validate_parameter_summary([
            {'device':'cuda:0','dtype':'torch.float16','is_lora':False,'count':2},
            {'device':'cuda:0','dtype':'torch.float32','is_lora':True,'count':2}],'dpo')

    def test_missing_and_substituted_adapter_keys_rejected(self):
        keys={str(i):None for i in range(112)};validate_adapter_keys(keys,keys)
        with self.assertRaisesRegex(RuntimeError,'coverage'):
            validate_adapter_keys({**keys,'other':None},keys)
        changed=dict(keys);del changed['0'];changed['other']=None
        with self.assertRaisesRegex(RuntimeError,'coverage'):validate_adapter_keys(changed,keys)

    def test_actual_quantization_backend_must_match_course(self):
        config={'load_in_4bit':True,'bnb_4bit_quant_type':'nf4','bnb_4bit_compute_dtype':'float16'}
        item={'quant_type':'nf4','compute_dtype':'torch.float16','device':'cuda:0','quant_state_present':True}
        validate_judge_quantization(config,[item])
        for changed in [{**item,'quant_type':'fp4'},{**item,'device':'cpu'},{**item,'quant_state_present':False}]:
            with self.assertRaisesRegex(RuntimeError,'module configuration'):validate_judge_quantization(config,[changed])
        with self.assertRaisesRegex(RuntimeError,'quantization differs'):
            validate_judge_quantization({**config,'bnb_4bit_compute_dtype':'float32'},[item])

    def test_probe_has_no_inference_training_or_substitute_loader(self):
        source=Path(__file__).with_name('probe_models.py').read_text();tree=ast.parse(source)
        calls=[node for node in ast.walk(tree) if isinstance(node,ast.Call)]
        forbidden={'generate','forward','backward','step','from_pretrained','train','half','bfloat16'}
        self.assertFalse(any(isinstance(node.func,ast.Attribute) and node.func.attr in forbidden for node in calls))
        names={node.func.id for node in calls if isinstance(node.func,ast.Name)}
        self.assertTrue({'load_policy','load_tokenizer','load_judge'}<=names)
        policy=next(node for node in calls if isinstance(node.func,ast.Name) and node.func.id=='load_policy')
        self.assertEqual({node.arg for node in policy.keywords},{'adapter_path','trainable'})
        self.assertFalse(next(node.value.value for node in policy.keywords if node.arg=='trainable'))

if __name__=='__main__':unittest.main(verbosity=2)
