"""Load-only checks: preserve the course's model and generation behavior."""
from pathlib import Path

POLICIES=['sft','dpo','ppo','grpo']

def require(value,message):
    if not value:raise RuntimeError(message)


def validate_defaults(actual,expected):
    require(actual==expected,'Loaded model generation defaults differ from the frozen CPU preview; review required')
    require(actual.get('num_return_sequences')==1,'Loaded model returns multiple sequences')


def verify_snapshot(folder,files,digest):
    folder=Path(folder)
    require(folder.is_dir() and not folder.is_symlink(),'Saved model directory is missing or symlinked')
    actual={p.relative_to(folder).as_posix() for p in folder.rglob('*')
            if p.is_file() and '.cache' not in p.relative_to(folder).parts}
    require(actual==set(files),'Saved model file coverage differs')
    verified={}
    for name,entry in files.items():
        path=folder/name
        require(not Path(name).is_absolute() and '..' not in Path(name).parts and '\\' not in name,
                'Unsafe saved model filename')
        require(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(folder.resolve()) and
                path.stat().st_size==entry['bytes'],'Saved model size or path differs: '+name)
        require(digest(path)==entry['sha256'],'Saved model checksum differs: '+name)
        verified[name]={'bytes':entry['bytes'],'sha256':entry['sha256']}
    return verified


def validate_parameter_summary(summary,role):
    require(summary and all(item['device'].startswith('cuda:') for item in summary),
            'A loaded parameter is not on CUDA; CPU/disk offload is not accepted silently')
    if role!='judge':
        require(all(item['dtype']=='torch.float16' for item in summary if not item['is_lora']),
                'Policy base parameter precision differs from the released float16 loader')
    require(all(item['count']>0 for item in summary),'Empty parameter summary')


def validate_adapter_keys(actual,expected):
    require(set(actual)==set(expected) and len(actual)==112,
            'Loaded adapter tensor keys/coverage differ from the frozen 112-tensor checkpoint')


def validate_judge_quantization(config,modules):
    require(config.get('load_in_4bit') is True and config.get('bnb_4bit_quant_type')=='nf4' and
            config.get('bnb_4bit_compute_dtype')=='float16','Judge quantization differs from original NF4/float16 loader')
    require(modules and all(item['quant_type']=='nf4' and item['compute_dtype']=='torch.float16' and
                           item['device'].startswith('cuda:') and item['quant_state_present']
                           for item in modules),'Actual judge quantized module configuration differs')
