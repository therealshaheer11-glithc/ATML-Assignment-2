"""Approved deterministic generation: all four policies with atomic batch resume."""
from datetime import datetime,timezone
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import generation_io as io
import runtime_checks as runtime


def main():
    preflight,identity,first=runtime.bootstrap(ROOT)
    digest,save,save_bytes,require=preflight.sha256,preflight.immutable_json,preflight.immutable_bytes,preflight.require
    experiment=runtime.EXPERIMENT
    release=experiment/'generation_releases'/identity
    for name in [*io.read(ROOT/'MANIFEST.json'),'MANIFEST.json']:save_bytes(release/name,(ROOT/name).read_bytes())
    attempt_id=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    attempt=experiment/'generation_attempts'/attempt_id;attempt.mkdir(parents=True,exist_ok=False)
    report={'format':'ATML_TASK4_GENERATION_ATTEMPT_V1','status':'RUNNING','attempt_utc':attempt_id,
            'source_manifest_sha256':identity,'commands':[],'policies_completed':[],
            'package_changes_downloads_or_training_performed':False,'judge_calls_performed':0,
            'human_labels_assigned':0,'gpu_exceptions_accepted':[],
            'generation_counts':'Pending verified saved-unit inspection'}
    store=None;rows=None;core=None

    def command(argv,name,env,show_output=True):
        event={'stage':name,'argv':[str(value) for value in argv]};save(attempt/(name+'_COMMAND.json'),event)
        print('Task 4 generation:',name,flush=True)
        path=attempt/(name+'.log')
        with path.open('x') as log:
            process=subprocess.Popen(event['argv'],cwd='/content',env=env,stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT,text=True,bufsize=1)
            for line in process.stdout:
                log.write(line);log.flush()
                if show_output:print(line,end='',flush=True)
            event['returncode']=process.wait()
        event['log_sha256']=digest(path);save(attempt/(name+'_RESULT.json'),event)
        report['commands'].append(event)
        if event['returncode'] and not show_output:print(path.read_text()[-12000:],flush=True)
        require(event['returncode']==0,name+' failed; saved batches are preserved; no automatic retry or fallback')

    try:
        save(attempt/'START.json',report)
        context=runtime.verify_saved(preflight,first)
        folders=context['folders'];inputs=context['inputs'];environment=context['environment']
        parent_backend=os.environ.get('MPLBACKEND')
        base_env=context['original'].clean_environment(os.environ)
        child_env=context['isolation'].child_environment(os.environ,context['original'].clean_environment)
        python=runtime.LOCAL/'bin/python'
        command(['nvidia-smi','--query-gpu=name,memory.total,driver_version,uuid','--format=csv,noheader,nounits'],
                'nvidia_inventory',base_env)
        hardware=context['gates'].parse_a100_inventory((attempt/'nvidia_inventory.log').read_text())
        require(hardware==io.read(context['previous_folder']/'A100_HARDWARE.json'),'A100 hardware/runtime differs')
        save(attempt/'A100_HARDWARE.json',hardware)
        before=runtime.inspect_environments(context,attempt,command,'BEFORE',base_env,child_env)
        for label,executable,env in [('base',sys.executable,base_env),('isolated',python,child_env)]:
            command([executable,'-I','-B','-m','pip','--disable-pip-version-check','check'],label+'_full_dependency_check',env)
            require((attempt/(label+'_full_dependency_check.log')).read_text().strip()=='No broken requirements found.',
                    'Clean full dependency check required: '+label)
        # Rehash only policy weights needed here; judge files remain bound to the verified loading contract.
        guards=runtime.load('task4_generation_snapshot_guards',folders['model_loading']/'loading_guards.py')
        base=io.read(experiment/'BASE_MODEL_REFERENCE.json')
        print('Rehashing all seven pinned base snapshot files before inference.',flush=True)
        snapshot=guards.verify_snapshot(base['directory'],base['verified_files'],digest)
        save(attempt/'POLICY_SNAPSHOT_REHASH.json',snapshot)
        for role,entry in inputs['prepared_adapters'].items():
            require(role in ['dpo','ppo','grpo'],'Unexpected adapter role')
            folder=Path(entry['directory'])
            require(folder==experiment/'prepared_adapters'/role and not folder.is_symlink() and
                    {p.name for p in folder.iterdir()}==set(entry['files_sha256']),'Prepared adapter coverage/path differs')
            for name,expected in entry['files_sha256'].items():
                require(not (folder/name).is_symlink() and digest(folder/name)==expected,'Prepared adapter bytes differ: '+role+'/'+name)
        require(set(inputs['prepared_adapters'])=={'dpo','ppo','grpo'},'Standard adapter coverage differs')
        sys.path.insert(0,str(folders['orchestration']))
        import core as execution_core
        core=execution_core
        data=io.read(experiment/'INPUT_IDENTITY_CONTRACT.json')['inputs']['xstest']
        csv=preflight.verify_csv(Path(data['path']),data['sha256'])
        require(csv['ordered_prompt_ids']==data['ordered_prompt_ids'] and csv['class_counts']=={'SAFE':250,'UNSAFE':200},
                'Fixed prompt order/class coverage differs')
        rows=io.load_rows(data['path'],core)
        io.verify_rows(rows,context['protocol']['fixed_evaluation_protocol'],core)
        contract=core.make_contract(rows,identity,{
            'cpu_model_input_contract_sha256':digest(experiment/'CPU_MODEL_INPUT_CONTRACT.json'),
            'cpu_orchestration_contract_sha256':digest(experiment/'CPU_ORCHESTRATION_VALIDATION_CONTRACT.json'),
            'gpu_environment_contract_sha256':digest(experiment/'GPU_ENVIRONMENT_CONTRACT.json'),
            'model_loading_validation_contract_sha256':digest(experiment/'MODEL_LOADING_VALIDATION_CONTRACT.json'),
            'input_identity_contract_sha256':digest(experiment/'INPUT_IDENTITY_CONTRACT.json'),
            'audit_id_contract_sha256':digest(experiment/'AUDIT_ID_CONTRACT.json'),
            'task4_approval_sha256':digest(first/'docs/approval.json'),
            'course_helper_sha256':context['protocol']['course_helper_sha256'],
            'orchestration_source_manifest_sha256':runtime.SOURCES['orchestration']},
            inputs['tokenizer_and_generation_metadata']['policy']['tokenizer']['eos_token_id'])
        frozen=context['protocol']['fixed_evaluation_protocol']
        for field in ['mode','policies','settings','ordered_prompt_ids','class_counts','prompt_metadata_sha256','policy_eos_token_id']:
            require(contract[field]==frozen[field],'Evaluation setting changed: '+field)
        core.immutable(experiment/'EVALUATION_EXECUTION_CONTRACT.json',contract)
        store=core.UnitStore(experiment/'evaluation_v1',contract)
        initial=io.counts(io.all_saved(store,rows,core),core)
        save(attempt/'INITIAL_VERIFIED_COUNTS.json',initial)
        report.update({'evaluation_contract_sha256':store.identity,'initial_verified_counts':initial})
        print('Verified initial response counts:',initial,flush=True)
        for role in core.POLICIES:
            command([python,'-I','-B','-u',ROOT/'generate_policy.py',first,folders['orchestration'],
                     folders['model_loading'],experiment,role,attempt],role+'_generation',child_env)
            result=io.read(attempt/(role.upper()+'_GENERATION_RESULT.json'))
            require(result['status']=='POLICY_GENERATION_COMPLETE' and result['completed_responses']==450 and
                    result['completed_batches']==113,'Policy did not complete all fixed batches')
            report['policies_completed'].append(role)
            verified=io.counts(io.all_saved(store,rows,core),core)
            save(attempt/('AFTER_'+role.upper()+'_COUNTS.json'),verified)
            print('Responses saved:',str(verified['completed_responses'])+'/1800',
                  '; remaining:',verified['remaining_responses'],'; no judging or human annotation in this block.',flush=True)
        saved=io.all_saved(store,rows,core)
        final=io.counts(saved,core)
        require(final['completed_responses']==1800 and final['completed_batches']==452,'Complete generation coverage required')
        exports={};unit_files={}
        for role in core.POLICIES:
            records=[row for unit in range(113) for row in saved[role][unit]]
            require([row['xstest_id'] for row in records]==contract['ordered_prompt_ids'],'Export prompt order differs')
            target=experiment/'evaluation_v1/exports/generation'/(role+'.jsonl')
            payload=io.jsonl_bytes(records)
            save_bytes(target,payload);exports[role]={'path':str(target),'sha256':digest(target),'responses':450}
            for unit in range(113):
                path=store.path('generation',role,unit)
                unit_files[path.relative_to(store.root).as_posix()]=digest(path)
        after=runtime.inspect_environments(context,attempt,command,'AFTER',base_env,child_env)
        require(before==after and os.environ.get('MPLBACKEND')==parent_backend,'Environment changed during generation')
        for filename,expected in context['bound_contracts'].items():
            path=first/'course_reference/requirements.txt' if filename=='course_requirements' else experiment/filename
            require(digest(path)==expected,'Historical preparation identity changed: '+filename)
        completion={'format':'ATML_TASK4_GENERATION_COMPLETE_V1','source_manifest_sha256':identity,
                    'evaluation_contract_sha256':store.identity,'responses':1800,'generation_batches':452,
                    'policy_response_counts':{role:450 for role in core.POLICIES},'generation_unit_sha256':unit_files,
                    'exports':exports,'all_prompt_ids_order_and_unit_checksums_verified':True,
                    'judging_execution_pending':True,'manual_audit_pending':True}
        save(experiment/'GENERATION_COMPLETION_CONTRACT.json',completion)
        report.update({'status':'ALL_FOUR_POLICIES_GENERATED_AND_SAVED',
                       'generation_counts':final,'generation_completion_contract_sha256':digest(experiment/'GENERATION_COMPLETION_CONTRACT.json'),
                       'exports':exports,'new_responses_this_attempt':1800-initial['completed_responses'],
                       'base_and_isolated_environment_unchanged':True})
        print('Generation complete: 1800/1800 responses in 452/452 saved batches.',flush=True)
        print('No judging, human annotation or training performed by this block.',flush=True)
    except BaseException as error:
        report.update({'status':'GENERATION_FAILED_PRESERVED_REVIEW_REQUIRED',
                       'error':{'type':type(error).__name__,'message':str(error)}})
        raise
    finally:
        if store is not None:
            try:
                report['generation_counts']=io.counts(io.all_saved(store,rows,core),core)
                print('Final verified saved response counts:',report['generation_counts'],flush=True)
            except BaseException as error:
                report['saved_unit_reinspection_error']={'type':type(error).__name__,'message':str(error)}
        report['artifact_sha256']={p.relative_to(attempt).as_posix():digest(p) for p in attempt.rglob('*') if p.is_file()}
        save(attempt/'REPORT.json',report)
        print('Saved generation report:',attempt/'REPORT.json',flush=True)
        print('Status:',report['status'],flush=True)


if __name__=='__main__':main()
