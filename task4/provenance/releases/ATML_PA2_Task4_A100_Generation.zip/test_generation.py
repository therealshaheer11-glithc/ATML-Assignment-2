import ast
import csv
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

import generation_io as io

COURSE=Path(__file__).resolve().parents[1]/'orchestration_v1'
spec=importlib.util.spec_from_file_location('core',COURSE/'core.py')
core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)


def prompts(n=450):
    return [{'xstest_id':i,'prompt':'Synthetic prompt '+str(i),'benchmark_class':'SAFE' if i<250 else 'UNSAFE',
             'type':'fixture'} for i in range(n)]


def contract(rows):return core.make_contract(rows,'a'*64,{'fixture':'not actual evaluation'},99)


def generation(chunk):
    return {'response_ids':[[7,99,0] for _ in chunk],'responses':['Synthetic fixture' for _ in chunk],
            'response_lengths':[2 for _ in chunk],'terminated_with_eos':[True for _ in chunk],
            'truncated':[False for _ in chunk]}


class GenerationIntegration(unittest.TestCase):
    def test_csv_loader_matches_frozen_metadata_and_order(self):
        rows=prompts()
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'fixture.csv'
            with path.open('w',encoding='utf-8-sig',newline='') as stream:
                writer=csv.DictWriter(stream,fieldnames=core.META);writer.writeheader();writer.writerows(rows)
            loaded=io.load_rows(path,core)
            self.assertEqual(loaded,rows);io.verify_rows(loaded,contract(rows),core)
            loaded[0]['prompt']='Changed'
            with self.assertRaisesRegex(RuntimeError,'order/content'):io.verify_rows(loaded,contract(rows),core)

    def test_count_partial_final_batch_without_assuming_four_rows(self):
        rows=prompts()
        with tempfile.TemporaryDirectory() as folder:
            store=core.UnitStore(folder,contract(rows));batches=core.chunks(rows)
            for unit in [0,112]:
                chunk=batches[unit]
                payload=core.portable_generation('sft',chunk,generation(chunk),99)
                store.write('generation','sft',unit,core.generation_input(store,'sft',chunk),payload)
            result=io.counts(io.all_saved(store,rows,core),core)
            self.assertEqual(result['completed_responses'],6)
            self.assertEqual(result['completed_batches'],2)
            self.assertEqual(result['remaining_responses'],1794)

    def test_corrupt_later_policy_blocks_earlier_missing_generation(self):
        rows=prompts()
        with tempfile.TemporaryDirectory() as folder:
            store=core.UnitStore(folder,contract(rows));chunk=core.chunks(rows)[0]
            payload=core.portable_generation('grpo',chunk,generation(chunk),99)
            store.write('generation','grpo',0,core.generation_input(store,'grpo',chunk),payload)
            path=store.path('generation','grpo',0);saved=io.read(path)
            saved['payload'][0]['response']='Changed';path.write_text(json.dumps(saved))
            with self.assertRaisesRegex(RuntimeError,'checksum differs'):
                io.all_saved(store,rows,core)
                core.run_generation(store,'sft',rows,lambda _:self.fail('Generation before full cache validation'))
            self.assertFalse(store.path('generation','sft',0).exists())

    def test_partial_resume_preserves_prior_bytes_and_generates_missing_batches(self):
        rows=prompts()
        with tempfile.TemporaryDirectory() as folder:
            store=core.UnitStore(folder,contract(rows));chunk=core.chunks(rows)[112]
            payload=core.portable_generation('sft',chunk,generation(chunk),99)
            store.write('generation','sft',112,core.generation_input(store,'sft',chunk),payload)
            original=store.path('generation','sft',112).read_bytes();calls=[]
            result=core.run_generation(store,'sft',rows,lambda chunk:(calls.append(len(chunk)) or generation(chunk)))
            self.assertEqual((result['new_batches'],result['reused_batches']),(112,1))
            self.assertEqual(sum(calls),448)
            self.assertEqual(store.path('generation','sft',112).read_bytes(),original)
            self.assertEqual([row['xstest_id'] for row in result['records']],list(range(450)))

    def test_jsonl_export_preserves_embedded_newlines_and_unicode(self):
        records=[{'response':'First line\nSecond line — π','prompt':'Tab\tand "quote"'}]
        payload=io.jsonl_bytes(records)
        self.assertEqual(len(payload.splitlines()),1)
        self.assertEqual([json.loads(line) for line in payload.splitlines()],records)

    def test_encoding_drift_stops_before_generation(self):
        class Array:
            def __init__(self,values):self.values=values;self.shape=(len(values),len(values[0]))
            def tolist(self):return self.values
        class Tokenizer:
            def apply_chat_template(self,messages,**kwargs):return messages[0]['content']
            def __call__(self,rendered,**kwargs):
                return {'input_ids':Array([[1] for _ in rendered]),'attention_mask':Array([[1] for _ in rendered])}
        rows=prompts();checks=[]
        for unit,chunk in enumerate(core.chunks(rows)):
            checks.append({'batch_index':unit,'ordered_prompt_ids':[row['xstest_id'] for row in chunk],
                           'input_ids_sha256':io.json_hash([[1] for _ in chunk]),
                           'attention_mask_sha256':io.json_hash([[1] for _ in chunk]),'prompt_width':1})
        expected={'rendered_prompts_sha256':io.json_hash([row['prompt'] for row in rows]),
                  'batch_encoding_checksums':checks}
        io.verify_prompt_encodings(Tokenizer(),rows,expected,io.json_hash,core)
        expected['batch_encoding_checksums'][112]['prompt_width']=2
        with self.assertRaisesRegex(RuntimeError,'batch encoding differs'):
            io.verify_prompt_encodings(Tokenizer(),rows,expected,io.json_hash,core)

    def test_inference_uses_original_policy_and_generation_wrapper(self):
        tree=ast.parse(Path(__file__).with_name('generate_policy.py').read_text())
        calls=[node for node in ast.walk(tree) if isinstance(node,ast.Call)]
        self.assertFalse(any(isinstance(node.func,ast.Attribute) and node.func.attr in
                            {'generate','forward','backward','step','half','from_pretrained'} for node in calls))
        named=[node for node in calls if isinstance(node.func,ast.Name)]
        self.assertEqual(sum(node.func.id=='load_policy' for node in named),1)
        self.assertEqual(sum(node.func.id=='generate_batch' for node in named),1)
        original=next(node for node in named if node.func.id=='generate_batch')
        self.assertEqual(original.keywords,[])

if __name__=='__main__':unittest.main(verbosity=2)
