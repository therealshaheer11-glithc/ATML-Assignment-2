"""One fresh isolated process per policy; original course generation only."""
from datetime import datetime,timezone
import importlib.util
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import generation_io as io


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module
    spec.loader.exec_module(module);return module


def main():
    first,orchestration,model_release,experiment,role,attempt=(Path(sys.argv[1]),Path(sys.argv[2]),
        Path(sys.argv[3]),Path(sys.argv[4]),sys.argv[5],Path(sys.argv[6]))
    preflight=load('task4_generation_child_persistence',first/'scripts/preflight.py')
    identity=preflight.verify_source(ROOT)['manifest_sha256']
    sys.path.insert(0,str(orchestration));sys.path.insert(0,str(first/'course_reference'))
    import core
    from course_calls import generate_batch
    guards=load('task4_generation_load_guards',model_release/'loading_guards.py')
    require,save=core.require,preflight.immutable_json
    require(role in core.POLICIES,'Unknown policy')
    inputs=io.read(experiment/'CPU_MODEL_INPUT_CONTRACT.json')
    models=io.read(experiment/'MODEL_LOADING_VALIDATION_CONTRACT.json')
    protocol=io.read(experiment/'CPU_ORCHESTRATION_VALIDATION_CONTRACT.json')['fixed_evaluation_protocol']
    data=io.read(experiment/'INPUT_IDENTITY_CONTRACT.json')['inputs']['xstest']
    preflight.verify_csv(Path(data['path']),data['sha256'])
    rows=io.load_rows(data['path'],core);io.verify_rows(rows,protocol,core)
    contract=io.read(experiment/'EVALUATION_EXECUTION_CONTRACT.json')
    require(contract['source_manifest_sha256']==identity and
            contract['evidence']['model_loading_validation_contract_sha256']==preflight.sha256(experiment/'MODEL_LOADING_VALIDATION_CONTRACT.json') and
            contract['evidence']['cpu_model_input_contract_sha256']==preflight.sha256(experiment/'CPU_MODEL_INPUT_CONTRACT.json'),
            'Generation execution identity differs')
    store=core.UnitStore(experiment/'evaluation_v1',contract)
    saved=io.all_saved(store,rows,core);before=io.counts(saved,core)
    result={'format':'ATML_TASK4_POLICY_GENERATION_ATTEMPT_V1','policy':role,'status':'RUNNING',
            'source_manifest_sha256':identity,'evaluation_contract_sha256':store.identity,
            'initial_completed_batches':len(saved[role]),
            'initial_completed_responses':before['by_policy'][role]['responses'],
            'new_batches':0,'new_responses':0,'model_loaded':False,
            'judge_calls':0,'training_performed':False}
    try:
        if len(saved[role])==113:
            result.update({'status':'POLICY_GENERATION_COMPLETE','completed_batches':113,'completed_responses':450,
                           'reused_batches':113,'new_batches':0,'new_responses':0})
            print(role,': all 450 saved responses verified; no model load or generation needed.',flush=True)
            return
        import torch
        from common.models import load_policy,load_tokenizer
        from peft import PeftModel,get_peft_model_state_dict
        from safetensors.torch import load_file
        require(torch.cuda.is_available() and torch.cuda.get_device_capability(0)==(8,0) and
                'A100' in torch.cuda.get_device_name(0),'A100 required')
        base=io.read(experiment/'BASE_MODEL_REFERENCE.json')
        cfg=dict(inputs['course_configuration']);cfg['base_model']=base['directory']
        tokenizer=load_tokenizer(cfg['base_model'])
        expected=inputs['tokenizer_and_generation_metadata']['policy']['tokenizer']
        require(tokenizer.is_fast and tokenizer.pad_token_id==expected['pad_token_id'] and
                tokenizer.eos_token_id==expected['eos_token_id'] and tokenizer.padding_side=='left' and
                tokenizer.truncation_side==expected['truncation_side'] and
                io.json_hash(tokenizer.chat_template)==expected['chat_template_sha256'],
                'Policy tokenizer settings differ')
        io.verify_prompt_encodings(tokenizer,rows,inputs['prompt_encoding_checks'],io.json_hash,core)
        print(role,': all 450 prompt encodings match frozen CPU checks. Loading original policy.',flush=True)
        adapter=None if role=='sft' else inputs['prepared_adapters'][role]['directory']
        model=load_policy(cfg,adapter_path=adapter,trainable=False);result['model_loaded']=True
        require(not model.training and all(not module.training for module in model.modules()),'Policy is not in evaluation mode')
        guards.validate_defaults(model.generation_config.to_dict(),models['validated_models'][role]['loaded_generation_defaults'])
        summary={}
        for name,parameter in model.named_parameters():
            key=(str(parameter.dtype),str(parameter.device),'lora_' in name,bool(parameter.requires_grad))
            item=summary.setdefault(key,{'dtype':key[0],'device':key[1],'is_lora':key[2],
                                        'requires_grad':key[3],'tensors':0,'count':0})
            item['tensors']+=1;item['count']+=parameter.numel()
        summary=sorted(summary.values(),key=lambda item:(item['is_lora'],item['dtype'],item['device'],item['requires_grad']))
        guards.validate_parameter_summary(summary,role)
        require(summary==models['validated_models'][role]['parameter_summary'],'Loaded parameter placement/dtypes differ from successful validation')
        if role=='sft':
            require(not isinstance(model,PeftModel) and not any('lora_' in name for name,_ in model.named_parameters()),
                    'SFT must have no adapter')
        else:
            require(isinstance(model,PeftModel) and list(model.active_adapters)==['default'] and
                    set(model.peft_config)=={'default'},'Active standard adapter differs')
            expected_tensors=load_file(str(Path(adapter)/'adapter_model.safetensors'),device='cpu')
            actual=get_peft_model_state_dict(model,adapter_name='default',save_embedding_layers=False)
            guards.validate_adapter_keys(actual,expected_tensors)
            for name,saved_tensor in expected_tensors.items():
                loaded=actual[name].detach().cpu()
                require(tuple(loaded.shape)==tuple(saved_tensor.shape) and
                        torch.equal(loaded,saved_tensor.to(dtype=loaded.dtype)),'Loaded adapter value differs: '+name)
            del expected_tensors,actual,loaded
        save(attempt/(role.upper()+'_INFERENCE_MODEL_CHECK.json'),{
            'policy':role,'eval_mode':True,'parameter_summary':summary,'prompt_encodings_verified':450,
            'generation_defaults':model.generation_config.to_dict(),'adapter_verified':role!='sft','sft_adapter':None,
            'fixed_course_generate_kwargs':models['validated_models'][role]['fixed_course_generate_kwargs']})
        completed_responses=before['by_policy'][role]['responses'];pending_size=0
        other_responses=before['completed_responses']-completed_responses

        def callback(chunk):
            nonlocal pending_size
            pending_size=len(chunk)
            return generate_batch(model,tokenizer,chunk)

        def progress(completed,total):
            nonlocal completed_responses
            completed_responses+=pending_size
            result['new_batches']+=1;result['new_responses']+=pending_size
            print(datetime.now(timezone.utc).isoformat(),role,
                  'saved batches',str(completed)+'/'+str(total),
                  'responses',str(completed_responses)+'/450',
                  'overall saved',str(other_responses+completed_responses)+'/1800',flush=True)

        generated=core.run_generation(store,role,rows,callback,on_progress=progress)
        require(generated['completed_batches']==113 and len(generated['records'])==450,'Policy generation coverage incomplete')
        result.update({'status':'POLICY_GENERATION_COMPLETE','completed_batches':113,'completed_responses':450,
                       'reused_batches':generated['reused_batches'],'new_batches':generated['new_batches']})
    except BaseException as error:
        result.update({'status':'POLICY_GENERATION_FAILED_PRESERVED',
                       'error':{'type':type(error).__name__,'message':str(error)}})
        raise
    finally:
        save(attempt/(role.upper()+'_GENERATION_RESULT.json'),result)
        print('Saved policy generation report:',role,';',result['status'],flush=True)


if __name__=='__main__':main()
