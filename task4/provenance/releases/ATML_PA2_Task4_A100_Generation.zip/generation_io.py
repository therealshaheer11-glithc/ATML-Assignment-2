"""Shared read-only prompt and persisted-response checks for generation."""
import csv
import hashlib
import json
from pathlib import Path


def read(path):return json.loads(Path(path).read_text())


def load_rows(path,core):
    with Path(path).open(newline='',encoding='utf-8-sig') as stream:
        rows=[{key:int(row[key]) if key=='xstest_id' else str(row[key]) for key in core.META}
              for row in csv.DictReader(stream)]
    core.validate_rows(rows)
    return rows


def verify_rows(rows,protocol,core):
    core.require(core.validate_rows(rows)==protocol['ordered_prompt_ids'] and
                 core.checksum(rows)==protocol['prompt_metadata_sha256'] and
                 len(core.chunks(rows))==113,'Frozen XSTest prompt order/content/batch coverage differs')


def all_saved(store,rows,core):
    # Every policy is checked before any new call, including later policies.
    return {policy:core.saved_generations(store,policy,rows) for policy in core.POLICIES}


def counts(saved,core):
    by_policy={policy:{'batches':len(saved[policy]),
                       'responses':sum(len(chunk) for chunk in saved[policy].values())}
               for policy in core.POLICIES}
    return {'by_policy':by_policy,'completed_batches':sum(v['batches'] for v in by_policy.values()),
            'completed_responses':sum(v['responses'] for v in by_policy.values()),
            'remaining_batches':452-sum(v['batches'] for v in by_policy.values()),
            'remaining_responses':1800-sum(v['responses'] for v in by_policy.values())}


def verify_prompt_encodings(tokenizer,rows,expected,hash_value,core):
    rendered=[tokenizer.apply_chat_template([{'role':'user','content':row['prompt']}],
              tokenize=False,add_generation_prompt=True) for row in rows]
    core.require(hash_value(rendered)==expected['rendered_prompts_sha256'],
                 'Rendered prompt content differs from frozen CPU encodings')
    for unit,chunk in enumerate(core.chunks(rows)):
        start=unit*4
        encoded=tokenizer(rendered[start:start+len(chunk)],return_tensors='pt',padding=True,
                          truncation=True,max_length=256)
        actual={'batch_index':unit,'ordered_prompt_ids':[row['xstest_id'] for row in chunk],
                'input_ids_sha256':hash_value(encoded['input_ids'].tolist()),
                'attention_mask_sha256':hash_value(encoded['attention_mask'].tolist()),
                'prompt_width':int(encoded['input_ids'].shape[1])}
        core.require(actual==expected['batch_encoding_checksums'][unit],
                     'Prompt batch encoding differs from frozen CPU preview: '+str(unit))


def json_hash(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False).encode()).hexdigest()


def jsonl_bytes(records):
    return b''.join((json.dumps(row,sort_keys=True,ensure_ascii=False,allow_nan=False,
                               separators=(',',':'))+'\n').encode('utf-8') for row in records)
