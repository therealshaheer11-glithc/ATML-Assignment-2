"""Reuse sealed environment guards and verify the successful real-model stage."""
import hashlib
import importlib.util
from pathlib import Path
import sys
from generation_io import read

EXPERIMENT=Path('/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1')
LOCAL=Path('/content/task4_isolated_runtime_v1')
SOURCES={
 'preflight':'9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65',
 'isolated_gpu':'7a5673003062448f66a3c43763340483968234f42d2659d517c47d7e33de6e8a',
 'isolated_recheck':'999b26996654587e6ddfda1a146cac4ac38b421f0856f6134abd2ac61433c363',
 'model_loading':'20c7fb542b21e7d41afd36e2f2b2bb4fa6eb981994eda20ae1344bac4c06935d',
 'orchestration':'35ca690761d2bfda0992ff37855b16fc72c03ffd4b47afaa81edc533ab7a5f65',
 'base_repair_recheck':'4955a6f76dfbfc5b2f92825fce309eabbe4c209cf576b73a7d182ff0b101f09a',
 'base_layout_diagnostic':'961b9825e7a34823a8f3930e597149c425427d494f8d9c9b10652e5998a734be',
 'gpu_environment':'d941ecb6c16ec91a942b319167826007f5124b0dedc10d2a337b3b783ff4015b'}
MODEL_ATTEMPT='20261011T170515.343871Z'


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module
    spec.loader.exec_module(module);return module


def bootstrap(root):
    first=EXPERIMENT/'preflight_releases'/SOURCES['preflight']
    assert hashlib.sha256((first/'MANIFEST.json').read_bytes()).hexdigest()==SOURCES['preflight'],'Original source differs'
    assert hashlib.sha256((first/'scripts/preflight.py').read_bytes()).hexdigest()==read(first/'MANIFEST.json')['scripts/preflight.py'],'Original helper differs'
    preflight=load('task4_generation_persistence',first/'scripts/preflight.py')
    preflight.verify_source(first)
    identity=preflight.verify_source(root)['manifest_sha256']
    preflight.require(read(EXPERIMENT/'OWNER.json')['approval_sha256']==preflight.sha256(first/'docs/approval.json')==
                      preflight.sha256(root/'TASK4_APPROVAL.json') and read(root/'TASK4_APPROVAL.json')['approved'] is True,
                      'Task owner/approval differs')
    return preflight,identity,first


def verify_saved(preflight,first):
    digest,require=preflight.sha256,preflight.require
    folders={}
    for kind,source in SOURCES.items():
        folder=EXPERIMENT/(kind+'_releases')/source
        require(digest(folder/'MANIFEST.json')==source,'Sealed source differs: '+kind)
        preflight.verify_source(folder);folders[kind]=folder
    original=load('task4_generation_isolation_guards',folders['isolated_gpu']/'guards.py')
    isolation=load('task4_generation_child_policy',folders['isolated_recheck']/'isolation.py')
    load('repair_guards',folders['base_repair_recheck']/'repair_guards.py')
    layout=load('task4_generation_layout_guards',folders['base_repair_recheck']/'layout_guards.py')
    gates=load('task4_generation_gpu_gates',folders['gpu_environment']/'gates.py')
    previous_folder=EXPERIMENT/'model_loading_attempts'/MODEL_ATTEMPT
    previous=read(previous_folder/'REPORT.json')
    require(previous['source_manifest_sha256']==SOURCES['model_loading'] and
            previous['status']=='FIVE_MODELS_LOADED_AND_VALIDATED_NO_INFERENCE' and
            previous['models_successfully_validated']==['sft','dpo','ppo','grpo','judge'] and
            previous['model_load_calls_returned']==5 and previous['gpu_exceptions_accepted']==[] and
            previous['base_and_isolated_environment_unchanged'],'Saved model validation differs')
    for name,expected in previous['artifact_sha256'].items():
        require(digest(isolation.safe_artifact(previous_folder,name))==expected,'Saved model-validation artifact differs: '+name)
    model_path=EXPERIMENT/'MODEL_LOADING_VALIDATION_CONTRACT.json'
    require(digest(model_path)==previous['model_loading_validation_contract_sha256'],'Model validation contract differs')
    models=read(model_path)
    require(models['format']=='ATML_TASK4_MODEL_LOADING_VALIDATION_V1' and
            models['source_manifest_sha256']==SOURCES['model_loading'] and
            models['all_five_models_loaded_and_inspected'] and models['all_loaded_adapter_tensors_verified'] and
            models['gpu_exceptions_accepted']==[] and models['task4_approval_sha256']==digest(first/'docs/approval.json'),
            'Real-model validation is incomplete')
    bound={'GPU_ENVIRONMENT_CONTRACT.json':models['gpu_environment_contract_sha256'],
           'CPU_MODEL_INPUT_CONTRACT.json':models['model_input_contract_sha256'],
           'CPU_ORCHESTRATION_VALIDATION_CONTRACT.json':models['cpu_orchestration_contract_sha256']}
    for filename,expected in bound.items():require(digest(EXPERIMENT/filename)==expected,'Bound model/runtime contract differs: '+filename)
    environment=read(EXPERIMENT/'GPU_ENVIRONMENT_CONTRACT.json')
    require(environment['format']=='ATML_TASK4_GPU_ENVIRONMENT_V2' and environment['base_full_dependency_check_passed'] and
            environment['isolated_full_dependency_check_passed'] and environment['kernel_restart_observed_and_notebook_tools_validated'] and
            environment['gpu_exceptions_accepted']==[],'Combined GPU environment incomplete')
    for filename,field in [('ISOLATED_GPU_ENVIRONMENT_CONTRACT.json','isolated_environment_contract_sha256'),
                          ('COLAB_BASE_REPAIR_CONTRACT.json','colab_base_repair_contract_sha256'),
                          ('ISOLATED_CHILD_ENVIRONMENT_CONTRACT.json','isolated_child_environment_contract_sha256')]:
        bound[filename]=environment[field]
    inputs=read(EXPERIMENT/'CPU_MODEL_INPUT_CONTRACT.json')
    for filename,field in [('INPUT_IDENTITY_CONTRACT.json','input_contract_sha256'),
                          ('AUDIT_ID_CONTRACT.json','audit_id_contract_sha256'),
                          ('BASE_MODEL_REFERENCE.json','base_model_reference_sha256'),
                          ('JUDGE_SNAPSHOT_CONTRACT.json','judge_snapshot_contract_sha256')]:bound[filename]=inputs[field]
    bound['MODEL_LOADING_VALIDATION_CONTRACT.json']=digest(model_path)
    bound['course_requirements']=environment['course_requirements_sha256']
    for filename,expected in bound.items():
        path=first/'course_reference/requirements.txt' if filename=='course_requirements' else EXPERIMENT/filename
        require(digest(path)==expected,'Bound preparation identity differs: '+filename)
    require(LOCAL.is_dir() and not LOCAL.is_symlink(),'Owned isolated environment missing; retain same A100 runtime')
    owner=read(LOCAL/'.task4_isolation_owner.json');isolated=read(EXPERIMENT/'ISOLATED_GPU_ENVIRONMENT_CONTRACT.json')
    policy=read(EXPERIMENT/'ISOLATED_CHILD_ENVIRONMENT_CONTRACT.json')
    require(owner['source_manifest_sha256']==SOURCES['isolated_gpu'] and owner['directory']==str(LOCAL) and
            owner['approval_sha256']==environment['approval_sha256'] and
            owner['wheelhouse_contract_sha256']==isolated['wheelhouse_contract_sha256'] and
            owner['system_site_packages'] is False and environment['python_executable']==str(LOCAL/'bin/python') and
            environment['base_python_executable']==sys.executable,'Owned interpreter identity differs')
    require(policy==isolated['isolated_child_environment_policy'] and policy['recognized_removed_value']==isolation.NOTEBOOK_BACKEND and
            policy['replacement_backend_forced'] is False and policy['parent_environment_modified'] is False,'Child environment policy differs')
    protocol=read(EXPERIMENT/'CPU_ORCHESTRATION_VALIDATION_CONTRACT.json')
    require(protocol['source_manifest_sha256']==SOURCES['orchestration'] and protocol['tests_passed']==37 and
            inputs['policy_order']==['sft','dpo','ppo','grpo'] and inputs['sft_adapter'] is None,'Frozen protocol differs')
    for name,expected in protocol['course_helper_sha256'].items():
        require(digest(first/'course_reference'/name)==expected,'Original course helper differs: '+name)
    for name,expected in protocol['tested_scripts_sha256'].items():
        require(digest(folders['orchestration']/name)==expected,'Tested orchestration script differs: '+name)
    return {'folders':folders,'previous_folder':previous_folder,'previous':previous,
            'models':models,'environment':environment,'inputs':inputs,'bound_contracts':bound,
            'original':original,'isolation':isolation,'layout':layout,'gates':gates,'owner':owner,'protocol':protocol}


def inspect_environments(context,attempt,command,label,base_env,child_env):
    folders=context['folders'];require=context['original'].require
    inspect=folders['isolated_gpu']/'inspect_python.py'
    command([sys.executable,'-I','-B',inspect,attempt/(label+'_BASE_INVENTORY.json')],label+'_base_inventory',base_env)
    command([sys.executable,'-I','-B',folders['base_repair_recheck']/'scan_base_layout.py',
             folders['base_layout_diagnostic']/'scan_layout.py',attempt/(label+'_BASE_LAYOUT.json')],label+'_base_layout',base_env,False)
    inventory,layout=read(attempt/(label+'_BASE_INVENTORY.json')),read(attempt/(label+'_BASE_LAYOUT.json'))
    reviewed=read(context['previous_folder']/'BASE_AFTER_LAYOUT.json')
    details=read(folders['base_repair_recheck']/'REVIEWED_LAYOUT_DETAILS.json')
    versions=context['layout'].validate_reviewed_base_inventory(inventory,layout,reviewed,details,context['owner']['base_python_executable'])
    require(versions==context['environment']['base_legacy_package_versions'] and layout==reviewed,
            'Base versions/layout changed after successful model validation')
    command([LOCAL/'bin/python','-I','-B',inspect,attempt/(label+'_ISOLATED.json')],label+'_isolated_inventory',child_env)
    iso=read(attempt/(label+'_ISOLATED.json'))
    context['original'].validate_inventory(iso,context['environment']['isolated_package_versions'],LOCAL,complete=True)
    require(iso==read(context['previous_folder']/'ISOLATED_AFTER.json'),'Isolated inventory changed after successful model validation')
    return {'base_inventory':inventory,'base_layout':layout,'isolated_inventory':iso}
