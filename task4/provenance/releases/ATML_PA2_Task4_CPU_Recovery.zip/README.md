# Task 4 CPU recovery: approved exceptions and final contracts

The user approved the concrete recovery with “approve” after reviewing the confirmed diagnosis. APPROVAL.json records that approval, the three exact allowed global messages, and the SHA-256 of REVIEWED_DIAGNOSIS.md. The prior task approval remains unchanged.

## Operation

Run in the same CPU Colab runtime. This block installs, removes and upgrades no packages. It downloads no models and performs no inference, judging or training.

The recovery verifies the preserved preflight, environment and diagnostic source manifests; checks the approved diagnostic's saved artifacts; persists its own source and approval; and runs the unchanged diagnostic release again. That diagnostic freshly checks the complete required dependency graph, all current global dependency messages, course versions/imports and the original audit selection.

Recovery accepts only an unchanged, passing 64-distribution course dependency graph; exactly the same three global errors, with return code 1; all exception packages outside the required chain; successful fresh imports; and the same complete saved audit record and course package versions. Any new or changed dependency, error, version, platform metadata or audit ID stops and preserves the failure.

The previously verified diagnostic and its eight semantic tests are reused without modification. Seven new approval-boundary tests verify acceptance of the exact approved result and rejection of an extra global error, transitive version drift, a newly required exception package, changed audit IDs, a required dependency failure and a false global pass. Local tests are not a claim of actual Colab recovery.

## Finalized evidence after successful revalidation

Drive root: MyDrive/ATML-Assignment-2/task4/experiment_v1.

- recovery_releases/<source manifest SHA-256>/: immutable source, approval, reviewed diagnosis and validation evidence.
- diagnostic_attempts/<UTC timestamp>/: full fresh dependency graph, current metadata, inventories, imports/audit probe, logs and diagnostic report.
- recovery_attempts/<UTC timestamp>/: exact revalidation command, complete streamed output, result, hashes and REPORT.json linking that fresh diagnostic and finalized contracts.
- ENVIRONMENT_RECOVERY_APPROVAL.json: the exact scoped approval.
- AUDIT_ID_CONTRACT.json: the unchanged course helper's 60 IDs, 30 SAFE and 30 UNSAFE, common to all four policies. It assigns no human labels.
- CPU_ENVIRONMENT_CONTRACT.json: format ATML_TASK4_CPU_ENVIRONMENT_V2; required_dependency_chain_passed=true; global_dependency_check_passed=false; precisely three approved exceptions; complete required package versions; source, input, approval and original-report identities; model/GPU preparation still pending.

There is no generic claim that all of Colab passes. V2 makes the distinct validation scopes explicit. Stable contract contents support exact reruns, while fresh-attempt evidence remains separately linked in REPORT.json. Every existing target is checked for identical contents before publishing any root contract. Conflicting existing files are preserved and cause a stop. Historical source releases and original failed reports remain intact.

Expected success status: CPU_ENVIRONMENT_AND_AUDIT_FINALIZED_WITH_APPROVED_EXCEPTIONS. Unexpected failure status: RECOVERY_FAILED_PRESERVED.

## Current evidence boundary and remaining work

The verified diagnostic passed all 64 required distributions and reproduced the same 60 audit IDs. The global Colab check remains failed. This recovery has been prepared and tested locally; actual Colab execution remains pending. The final root contracts have not yet been created by this release.

Inputs 4/4 verified. Generation 0/1,800; AI judging 0/1,800; blind human labels 0/240. Model preparation, GPU loading/validation, generation, judging, manual audit, analysis and export remain later blocks. Stay on CPU and return the complete output before the next block.

New recovery orchestration was created with Codex assistance. Released course requirements, helpers, model settings, frozen input identities, sampling settings, metrics and workload are unchanged.
