"""Finalize the explicitly approved Task 4 CPU environment exception policy.

No packages are installed, removed or upgraded. All fresh validation is delegated
to the previously tested and checksummed diagnostic release.
"""
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
EXPERIMENT = Path("/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1")
DIAGNOSTIC_SOURCE = "71bdb7fdbe130c5adaef8328437371bcd89621d0a93e849bab61b7db8491c540"
APPROVED_DIAGNOSTIC = "20261011T111017.208160Z"
EXPECTED_MESSAGES = [
    "ipython 7.34.0 requires jedi, which is not installed.",
    "diffusers 0.40.0 has requirement huggingface-hub<2.0,>=1.23.0, but you have huggingface-hub 0.36.2.",
    "gradio 6.29.0 has requirement huggingface-hub<3.0,>=1.16.0, but you have huggingface-hub 0.36.2.",
]


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def validate(approved, fresh, old_graph, new_graph, old_probe, new_probe):
    """Accept only the exact approved exception set and unchanged required inputs."""
    for report in [approved, fresh]:
        require(report["status"] == "DIAGNOSIS_CONFLICTS_OUTSIDE_COURSE_CHAIN", "Diagnostic status changed")
        require(report["required_dependency_chain_passed"] is True, "Required dependency chain failed")
        require(report["required_dependency_issues"] == [], "A required dependency issue exists")
        require(report["required_distributions"] == 64, "Required package count changed")
        require(report["global_pip_check_returncode"] == 1, "Global dependency-check result changed")
        require(sorted(report["global_dependency_messages"]) == sorted(EXPECTED_MESSAGES),
                "Global failures differ from the three explicitly approved issues")
        for field in ["global_dependency_issues_unchanged", "fresh_probe_passed",
                      "audit_contract_matches_original_probe", "course_versions_match_original_probe",
                      "three_reported_packages_outside_required_chain"]:
            require(report[field] is True, "Diagnostic check failed: " + field)
    require(old_graph == new_graph, "Required dependency metadata or platform changed")
    require(new_graph["issues"] == [] and new_graph["required_chain_passed"] is True,
            "Required dependency graph contains a failure")
    require(len(new_graph["nodes"]) == 64, "Required graph package count changed")
    for name in ["ipython", "diffusers", "gradio", "jedi"]:
        require(name not in new_graph["nodes"], "An exception package is now a required dependency: " + name)
    require(old_probe == new_probe, "Course versions, imports or audit selection changed")
    audit = new_probe["audit"]
    ids = audit["ordered_audit_prompt_ids"]
    require(len(ids) == len(set(ids)) == 60 and ids == sorted(ids), "Audit ID contract differs")
    require(audit["class_counts"] == {"SAFE": 30, "UNSAFE": 30}, "Audit class counts differ")
    require(audit["manual_labels_assigned"] == 0, "Unexpected manual labels")


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    diagnostic_source = EXPERIMENT / "diagnostic_releases" / DIAGNOSTIC_SOURCE
    # Verify the helper before importing any of its code.
    import hashlib
    def digest(path):
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()
    require(digest(diagnostic_source / "MANIFEST.json") == DIAGNOSTIC_SOURCE, "Diagnostic source identity differs")
    manifest = json.loads((diagnostic_source / "MANIFEST.json").read_text())
    require(digest(diagnostic_source / "diagnose.py") == manifest["diagnose.py"], "Diagnostic helper differs")
    diagnostic = load_module("task4_verified_diagnostic", diagnostic_source / "diagnose.py")
    diagnostic.verify(diagnostic_source, DIAGNOSTIC_SOURCE)
    own_manifest = diagnostic.verify(ROOT)
    stage1 = EXPERIMENT / "preflight_releases" / diagnostic.STAGE1
    stage2 = EXPERIMENT / "environment_releases" / diagnostic.STAGE2
    diagnostic.verify(stage1, diagnostic.STAGE1)
    diagnostic.verify(stage2, diagnostic.STAGE2)
    preflight = load_module("task4_verified_preflight", stage1 / "scripts/preflight.py")
    preflight.require_cpu()
    save, save_bytes = preflight.immutable_json, preflight.immutable_bytes
    source_identity = digest(ROOT / "MANIFEST.json")
    persisted = EXPERIMENT / "recovery_releases" / source_identity
    for name in [*own_manifest, "MANIFEST.json"]:
        save_bytes(persisted / name, (ROOT / name).read_bytes())
    approval = diagnostic.read_json(ROOT / "APPROVAL.json")
    require(approval["approved"] is True and approval["user_message"] == "approve", "Recovery approval missing")
    require(sorted(approval["approved_global_messages"]) == sorted(EXPECTED_MESSAGES), "Approval scope differs")
    attempt_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    attempt = EXPERIMENT / "recovery_attempts" / attempt_id
    attempt.mkdir(parents=True, exist_ok=False)
    report = {"format": "ATML_TASK4_CPU_RECOVERY_ATTEMPT_V1", "attempt_utc": attempt_id,
              "status": "RUNNING", "source_manifest_sha256": source_identity,
              "recovery_approval_sha256": digest(ROOT / "APPROVAL.json"),
              "package_changes_performed": False, "model_downloads_performed": False,
              "generation_performed": False, "judging_performed": False, "training_performed": False}
    try:
        save(attempt / "START.json", report)
        def verified_attempt(folder):
            saved = diagnostic.read_json(folder / "REPORT.json")
            for name, expected in saved["artifact_sha256"].items():
                from pathlib import PurePosixPath
                path = PurePosixPath(name)
                require(not path.is_absolute() and ".." not in path.parts, "Unsafe saved artifact path")
                require(digest(folder / name) == expected, "Saved diagnostic artifact differs: " + name)
            return saved
        original = EXPERIMENT / "diagnostic_attempts" / APPROVED_DIAGNOSTIC
        approved_report = verified_attempt(original)
        require(approved_report["source_manifest_sha256"] == DIAGNOSTIC_SOURCE, "Approved diagnosis source differs")
        argv = [sys.executable, "-B", "-u", str(diagnostic_source / "diagnose.py")]
        save(attempt / "revalidate_command.json", {"argv": argv})
        print("Rechecking the approved diagnosis on CPU; all package versions stay unchanged.", flush=True)
        reported_paths = []
        with (attempt / "revalidate.log").open("x") as log:
            process = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in process.stdout:
                log.write(line)
                log.flush()
                print(line, end="", flush=True)
                if line.startswith("Saved diagnostic report: "):
                    reported_paths.append(Path(line.removeprefix("Saved diagnostic report: ").strip()))
            returncode = process.wait()
        save(attempt / "revalidate_result.json", {"returncode": returncode, "log_sha256": digest(attempt / "revalidate.log")})
        require(returncode == 0 and len(reported_paths) == 1, "Fresh diagnostic failed; full output preserved")
        fresh_report_path = reported_paths[0]
        require(fresh_report_path.name == "REPORT.json" and fresh_report_path.parent.parent == EXPERIMENT / "diagnostic_attempts",
                "Fresh diagnostic report path differs")
        fresh_folder = fresh_report_path.parent
        fresh_report = verified_attempt(fresh_folder)
        require(fresh_report["source_manifest_sha256"] == DIAGNOSTIC_SOURCE, "Fresh diagnosis source differs")
        old_graph = diagnostic.read_json(original / "required_dependency_chain.json")
        new_graph = diagnostic.read_json(fresh_folder / "required_dependency_chain.json")
        old_probe = diagnostic.read_json(original / "current_probe_results.json")
        probe = diagnostic.read_json(fresh_folder / "current_probe_results.json")
        validate(approved_report, fresh_report, old_graph, new_graph, old_probe, probe)

        failed = EXPERIMENT / "environment_attempts" / diagnostic.FAILED_ATTEMPT / "REPORT.json"
        task_approval_hash = digest(stage1 / "docs/approval.json")
        environment = {"format": "ATML_TASK4_CPU_ENVIRONMENT_V2",
            **{key: value for key, value in probe.items() if key != "audit"},
            "validation_status": "TASK4_CPU_VERIFIED_WITH_APPROVED_COLAB_EXCEPTIONS",
            "course_requirements_sha256": digest(stage1 / "course_reference/requirements.txt"),
            "approval_sha256": task_approval_hash,
            "recovery_approval_sha256": digest(ROOT / "APPROVAL.json"),
            "recovery_source_manifest_sha256": source_identity,
            "preflight_source_manifest_sha256": diagnostic.STAGE1,
            "input_contract_sha256": digest(EXPERIMENT / "INPUT_IDENTITY_CONTRACT.json"),
            "required_dependency_chain_passed": True, "required_distributions": 64,
            "all_required_package_versions": {name: node["version"] for name, node in new_graph["nodes"].items()},
            "required_dependency_graph_sha256": digest(original / "required_dependency_chain.json"),
            "global_dependency_check_passed": False, "global_dependency_check_returncode": 1,
            "approved_global_dependency_messages": sorted(EXPECTED_MESSAGES),
            "approved_exception_packages_outside_required_chain": ["diffusers", "gradio", "ipython"],
            "original_failed_environment_report_sha256": digest(failed),
            "approved_diagnostic_report_sha256": digest(original / "REPORT.json"),
            "complete_model_preparation_pending": True,
            "gpu_model_validation_pending": True}
        # Contract content excludes new-attempt timestamps so exact reruns can
        # reuse it. Each fresh validation is linked from its own recovery report.
        contracts = {"ENVIRONMENT_RECOVERY_APPROVAL.json": approval,
                     "AUDIT_ID_CONTRACT.json": probe["audit"],
                     "CPU_ENVIRONMENT_CONTRACT.json": environment}
        for name, value in contracts.items():
            target = EXPERIMENT / name
            if target.exists():
                require(target.is_file() and target.read_bytes() == preflight.json_bytes(value),
                        "Existing contract differs and was preserved: " + name)
        for name, value in contracts.items():
            save(EXPERIMENT / name, value)
        report.update({"status": "CPU_ENVIRONMENT_AND_AUDIT_FINALIZED_WITH_APPROVED_EXCEPTIONS",
            "fresh_diagnostic_report": str(fresh_report_path),
            "fresh_diagnostic_report_sha256": digest(fresh_report_path),
            "cpu_environment_contract_sha256": digest(EXPERIMENT / "CPU_ENVIRONMENT_CONTRACT.json"),
            "audit_id_contract_sha256": digest(EXPERIMENT / "AUDIT_ID_CONTRACT.json"),
            "required_dependency_chain_passed": True, "global_dependency_check_passed": False,
            "approved_exceptions": 3, "audit_prompt_ids": 60, "manual_labels_assigned": 0})
        print("\nApproved CPU recovery complete: required dependency chain PASS (64 packages).", flush=True)
        print("Global Colab dependency check: FAIL, with exactly 3 approved outside-chain exceptions.", flush=True)
        print("Audit contract finalized: 60/60 IDs (30 SAFE, 30 UNSAFE).", flush=True)
        print("Remaining: generation 1800; judging 1800; human labels 240.", flush=True)
        print("Model preparation and GPU inference validation remain pending. Stay on CPU.", flush=True)
    except BaseException as error:
        report["status"] = "RECOVERY_FAILED_PRESERVED"
        report["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        report["artifact_sha256"] = {path.name: digest(path) for path in attempt.iterdir() if path.is_file()}
        save(attempt / "REPORT.json", report)
        print("Saved recovery report:", attempt / "REPORT.json", flush=True)
        print("Status:", report["status"], flush=True)


if __name__ == "__main__":
    main()
