import copy
import unittest
from recover import EXPECTED_MESSAGES, validate


class RecoveryBoundary(unittest.TestCase):
    def setUp(self):
        self.report = {"status": "DIAGNOSIS_CONFLICTS_OUTSIDE_COURSE_CHAIN",
            "required_dependency_chain_passed": True, "required_dependency_issues": [],
            "required_distributions": 64, "global_pip_check_returncode": 1,
            "global_dependency_messages": list(EXPECTED_MESSAGES),
            **{name: True for name in ["global_dependency_issues_unchanged", "fresh_probe_passed",
                "audit_contract_matches_original_probe", "course_versions_match_original_probe",
                "three_reported_packages_outside_required_chain"]}}
        self.graph = {"nodes": {"package" + str(i): {"version": "1.0"} for i in range(64)},
                      "issues": [], "required_chain_passed": True}
        self.probe = {"audit": {"ordered_audit_prompt_ids": list(range(60)),
            "class_counts": {"SAFE": 30, "UNSAFE": 30}, "manual_labels_assigned": 0}}

    def run_gate(self, report=None, graph=None, probe=None):
        return validate(self.report, report or copy.deepcopy(self.report), self.graph,
                        graph or copy.deepcopy(self.graph), self.probe, probe or copy.deepcopy(self.probe))

    def test_exact_approved_diagnosis_is_accepted(self):
        self.run_gate()

    def test_additional_global_error_is_rejected(self):
        report = copy.deepcopy(self.report)
        report["global_dependency_messages"].append("required-package is missing")
        with self.assertRaisesRegex(RuntimeError, "three explicitly approved"):
            self.run_gate(report=report)

    def test_changed_required_transitive_version_is_rejected(self):
        graph = copy.deepcopy(self.graph)
        graph["nodes"]["package1"]["version"] = "2.0"
        with self.assertRaisesRegex(RuntimeError, "metadata or platform changed"):
            self.run_gate(graph=graph)

    def test_exception_entering_required_chain_is_rejected(self):
        self.graph["nodes"]["ipython"] = self.graph["nodes"].pop("package1")
        with self.assertRaisesRegex(RuntimeError, "now a required dependency"):
            self.run_gate()

    def test_different_audit_ids_are_rejected(self):
        probe = copy.deepcopy(self.probe)
        probe["audit"]["ordered_audit_prompt_ids"][-1] = 100
        with self.assertRaisesRegex(RuntimeError, "audit selection changed"):
            self.run_gate(probe=probe)

    def test_required_dependency_failure_is_rejected(self):
        report = copy.deepcopy(self.report)
        report["required_dependency_chain_passed"] = False
        with self.assertRaisesRegex(RuntimeError, "Required dependency chain failed"):
            self.run_gate(report=report)

    def test_global_check_not_reported_as_pass(self):
        report = copy.deepcopy(self.report)
        report["global_pip_check_returncode"] = 0
        with self.assertRaisesRegex(RuntimeError, "result changed"):
            self.run_gate(report=report)


if __name__ == "__main__":
    unittest.main(verbosity=2)
