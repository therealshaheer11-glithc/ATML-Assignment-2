"""Inspect distribution metadata and paths without importing installed libraries."""
import importlib.metadata as metadata
import json
from pathlib import Path
import platform
import re
import site
import sys


def collect():
    prefix = Path(sys.prefix).resolve()
    versions, groups = {}, {}
    for item in metadata.distributions():
        if not item.metadata.get('Name'): continue
        name = re.sub(r'[-_.]+', '-', item.metadata['Name']).lower()
        location = Path(item.locate_file('')).resolve()
        raw_metadata = getattr(item, '_path', None)
        entry = {'version': item.version, 'root': str(location),
                 'metadata_path': None if raw_metadata is None else str(Path(raw_metadata).resolve()),
                 'outside_prefix': not location.is_relative_to(prefix)}
        versions[name] = item.version
        groups.setdefault(name, []).append(entry)
    duplicates = {name: entries for name, entries in groups.items() if len(entries) > 1}
    return {'format': 'ATML_TASK4_BASE_LAYOUT_SCAN_V1', 'python': platform.python_version(),
            'executable': sys.executable, 'prefix': str(prefix), 'base_prefix': str(Path(sys.base_prefix).resolve()),
            'user_site_enabled': site.ENABLE_USER_SITE, 'sys_path': sys.path,
            'package_versions': dict(sorted(versions.items())),
            'all_distribution_entries': dict(sorted(groups.items())),
            'duplicate_distribution_entries': dict(sorted(duplicates.items())),
            'outside_prefix_distribution_entries': {name: entries for name, entries in sorted(groups.items())
                                                     if any(value['outside_prefix'] for value in entries)},
            'outside_prefix_site_paths': [value for value in sys.path if value and
                ('site-packages' in Path(value).parts or 'dist-packages' in Path(value).parts) and
                not Path(value).resolve().is_relative_to(prefix)]}


if __name__ == '__main__':
    print(json.dumps(collect(), indent=2, sort_keys=True))
