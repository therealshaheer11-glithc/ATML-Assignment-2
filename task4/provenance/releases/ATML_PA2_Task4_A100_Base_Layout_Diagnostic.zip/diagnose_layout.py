"""Read-only diagnosis of Block 11's rejected Colab base metadata/layout."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
EXPERIMENT = Path('/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1')
STAGE1 = '9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65'
REPAIR = '76963d33df89cd6439d988bd11808dd503a3724bde6d5c5ef02dec172037b47b'
RECHECK = '999b26996654587e6ddfda1a146cac4ac38b421f0856f6134abd2ac61433c363'
ATTEMPT = '20261011T161416.759661Z'


def require(value, message):
    if not value: raise RuntimeError(message)


def read(path): return json.loads(Path(path).read_text())


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    first = EXPERIMENT / 'preflight_releases' / STAGE1
    require(hashlib.sha256((first / 'MANIFEST.json').read_bytes()).hexdigest() == STAGE1,
            'Original source identity differs')
    require(hashlib.sha256((first / 'scripts/preflight.py').read_bytes()).hexdigest() ==
            read(first / 'MANIFEST.json')['scripts/preflight.py'], 'Original helper differs')
    preflight = load('task4_layout_preflight', first / 'scripts/preflight.py')
    digest, save, save_bytes = preflight.sha256, preflight.immutable_json, preflight.immutable_bytes
    preflight.verify_source(first)
    identity = preflight.verify_source(ROOT)['manifest_sha256']
    require(read(EXPERIMENT / 'OWNER.json')['approval_sha256'] == digest(first / 'docs/approval.json'),
            'Original Task 4 ownership differs')
    release = EXPERIMENT / 'base_layout_diagnostic_releases' / identity
    for name in [*read(ROOT / 'MANIFEST.json'), 'MANIFEST.json']:
        save_bytes(release / name, (ROOT / name).read_bytes())
    attempt_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    attempt = EXPERIMENT / 'base_layout_diagnostic_attempts' / attempt_id
    attempt.mkdir(parents=True, exist_ok=False)
    report = {'format': 'ATML_TASK4_BASE_LAYOUT_DIAGNOSTIC_ATTEMPT_V1', 'status': 'RUNNING',
              'attempt_utc': attempt_id, 'source_manifest_sha256': identity,
              'package_installation_or_removal_performed': False, 'downloads_performed': False,
              'repair_guards_changed': False, 'dependency_exceptions_accepted': [],
              'kernel_restart_performed': False, 'pretrained_models_loaded': 0,
              'task4_responses_generated': 0, 'task4_judgments_produced': 0,
              'human_labels_assigned': 0, 'training_performed': False}
    try:
        save(attempt / 'START.json', report)
        for kind, source in [('base_repair', REPAIR), ('isolated_recheck', RECHECK)]:
            folder = EXPERIMENT / (kind + '_releases') / source
            require(digest(folder / 'MANIFEST.json') == source, 'Referenced sealed source differs')
            preflight.verify_source(folder)
        isolation = load('task4_layout_artifact_guard',
                         EXPERIMENT / 'isolated_recheck_releases' / RECHECK / 'isolation.py')
        previous_folder = EXPERIMENT / 'base_repair_attempts' / ATTEMPT
        previous = read(previous_folder / 'REPORT.json')
        require(previous['status'] == 'BASE_REPAIR_FAILED_PRESERVED_REVIEW_REQUIRED' and
                previous['source_manifest_sha256'] == REPAIR and
                previous['error']['message'] == 'Base distribution paths/duplicates require review',
                'Saved failure differs from returned evidence')
        require(previous['base_package_mutation_commands_started'] == [] and
                not any(value['base_mutation'] for value in previous['commands']) and
                previous['gpu_exceptions_accepted'] == [] and previous['pretrained_models_loaded'] == 0,
                'Unexpected action in saved failed attempt')
        for name, expected in previous['artifact_sha256'].items():
            require(digest(isolation.safe_artifact(previous_folder, name)) == expected,
                    'Saved artifact differs: ' + name)
        saved = read(previous_folder / 'BASE_INVENTORY_BEFORE.json')
        save(attempt / 'SAVED_REJECTED_BASE_INVENTORY.json', saved)
        report['original_base_repair_report_sha256'] = digest(previous_folder / 'REPORT.json')
        print('Saved guard triggers:', json.dumps({
            'duplicate_distributions': saved['duplicate_distributions'],
            'outside_prefix_distributions': saved['outside_prefix_distributions'],
            'outside_prefix_site_paths': saved['outside_prefix_site_paths']}, indent=2), flush=True)
        base_contract = EXPERIMENT / 'ISOLATED_GPU_ENVIRONMENT_CONTRACT.json'
        require(digest(base_contract) == previous['isolated_environment_contract_sha256'],
                'Isolated validation contract changed')
        contract = read(base_contract)
        local = Path(contract['environment_directory'])
        require(local.is_dir() and not local.is_symlink(), 'Keep the same A100 runtime; installed isolated environment is missing')
        owner = read(local / '.task4_isolation_owner.json')
        require(str(Path(sys.executable).resolve()) == owner['base_python_executable'], 'Base interpreter changed')
        parent_backend = os.environ.get('MPLBACKEND')

        def scan(label):
            argv = [sys.executable, '-I', '-B', str(ROOT / 'scan_layout.py')]
            save(attempt / (label + '_COMMAND.json'), {'argv': argv,
                 'policy': 'Fresh isolated-mode base Python; inspect metadata only; no installed library imports or environment changes.'})
            result = subprocess.run(argv, cwd='/content', capture_output=True, text=True)
            save_bytes(attempt / (label + '_STDOUT.json'), result.stdout.encode())
            save_bytes(attempt / (label + '_STDERR.txt'), result.stderr.encode())
            save(attempt / (label + '_RESULT.json'), {'returncode': result.returncode})
            require(result.returncode == 0, 'Read-only fresh metadata scan failed')
            return json.loads(result.stdout)

        before = scan('FRESH_BASE_LAYOUT_BEFORE')
        require(before['package_versions'] == saved['package_versions'] and
                before['prefix'] == saved['prefix'] and before['base_prefix'] == saved['base_prefix'] and
                before['python'] == saved['python'], 'Base versions or interpreter changed since the failed guard')
        details = {'fresh_duplicate_distribution_entries': before['duplicate_distribution_entries'],
                   'fresh_outside_prefix_distribution_entries': before['outside_prefix_distribution_entries'],
                   'fresh_outside_prefix_site_paths': before['outside_prefix_site_paths'],
                   'base_prefix': before['prefix'], 'base_python': before['executable']}
        save(attempt / 'LAYOUT_DETAILS_FOR_REVIEW.json', details)
        print('Exact fresh metadata/path details for review:', json.dumps(details, indent=2), flush=True)
        print('No duplicate is accepted or removed by this diagnostic.', flush=True)
        after = scan('FRESH_BASE_LAYOUT_AFTER')
        require(before == after and os.environ.get('MPLBACKEND') == parent_backend and
                digest(base_contract) == previous['isolated_environment_contract_sha256'],
                'Metadata/layout or parent setting changed during read-only diagnosis')
        report.update({'status': 'BASE_LAYOUT_DIAGNOSIS_SAVED_REVIEW_PENDING',
                       'complete_base_versions_unchanged': True, 'metadata_and_paths_unchanged': True,
                       'parent_backend_unchanged': True, 'base_distribution_count': len(before['package_versions']),
                       'duplicate_package_names': sorted(before['duplicate_distribution_entries']),
                       'outside_prefix_package_names': sorted(before['outside_prefix_distribution_entries']),
                       'base_repair_or_guard_revision_performed': False})
        print('Diagnosis saved. Return complete output; keep the same A100 runtime connected.', flush=True)
        print('Responses 0/1800; judgments 0/1800; human labels 0/240.', flush=True)
    except BaseException as error:
        report.update({'status': 'BASE_LAYOUT_DIAGNOSIS_FAILED_PRESERVED',
                       'error': {'type': type(error).__name__, 'message': str(error)}})
        raise
    finally:
        report['artifact_sha256'] = {p.relative_to(attempt).as_posix(): digest(p)
                                    for p in attempt.rglob('*') if p.is_file()}
        save(attempt / 'REPORT.json', report)
        print('Saved base layout diagnostic report:', attempt / 'REPORT.json', flush=True)
        print('Status:', report['status'], flush=True)


if __name__ == '__main__': main()
