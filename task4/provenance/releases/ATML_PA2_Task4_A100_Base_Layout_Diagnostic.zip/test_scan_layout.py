"""A metadata fixture preserves the evidence needed to diagnose base layouts."""
from pathlib import Path
from unittest.mock import patch
import unittest
import scan_layout


class FixtureDistribution:
    def __init__(self, name, version, root, info):
        self.metadata = {'Name': name}
        self.version = version
        self.root = Path(root)
        self._path = Path(info)

    def locate_file(self, relative): return self.root / relative


class MetadataEvidence(unittest.TestCase):
    def test_repeated_path_separate_version_and_outside_prefix_evidence_is_preserved(self):
        values = [FixtureDistribution('Package_A', '1', '/fixture-base/lib/site-packages',
                                      '/fixture-base/lib/site-packages/a-1.dist-info'),
                  FixtureDistribution('package-a', '1', '/fixture-base/lib/site-packages',
                                      '/fixture-base/lib/site-packages/a-1.dist-info'),
                  FixtureDistribution('package-a', '2', '/outside/site-packages',
                                      '/outside/site-packages/a-2.dist-info'),
                  FixtureDistribution('single', '1', '/fixture-base/lib/site-packages',
                                      '/fixture-base/lib/site-packages/single-1.dist-info')]
        with patch.object(scan_layout.metadata, 'distributions', return_value=values), \
             patch.object(scan_layout.sys, 'prefix', '/fixture-base'), \
             patch.object(scan_layout.sys, 'base_prefix', '/fixture-base'), \
             patch.object(scan_layout.sys, 'path', ['/fixture-base/lib/site-packages', '/outside/site-packages']):
            result = scan_layout.collect()
        entries = result['duplicate_distribution_entries']['package-a']
        self.assertEqual(len(entries), 3)
        self.assertEqual(entries[0]['metadata_path'], entries[1]['metadata_path'])
        self.assertNotEqual(entries[1]['metadata_path'], entries[2]['metadata_path'])
        self.assertEqual({value['version'] for value in entries}, {'1', '2'})
        self.assertEqual(result['package_versions']['package-a'], '2')
        self.assertEqual(set(result['outside_prefix_distribution_entries']), {'package-a'})
        self.assertEqual(result['outside_prefix_site_paths'], ['/outside/site-packages'])
        self.assertNotIn('single', result['duplicate_distribution_entries'])


if __name__ == '__main__': unittest.main(verbosity=2)
