"""Fresh-process A100 imports and tiny CUDA/NF4 backend checks, without models."""
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
import os
from pathlib import Path
import platform
import sys

sys.dont_write_bytecode = True


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def lookup(name):
    try:
        distribution = metadata.distribution(name)
    except metadata.PackageNotFoundError:
        return None
    return {'name': distribution.metadata['Name'], 'version': distribution.version,
            'requires_dist': distribution.requires or [],
            'provides_extra': distribution.metadata.get_all('Provides-Extra', []),
            'requires_python': distribution.metadata.get('Requires-Python')}


def main():
    stage1, orchestration, diagnostic, attempt = map(Path, sys.argv[1:])
    course = stage1 / 'course_reference'
    sys.path.insert(0, str(course))
    sys.path.insert(0, str(orchestration))
    os.environ['TASK4_COURSE_REFERENCE'] = str(course)
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    spec = importlib.util.spec_from_file_location('task4_gpu_dependencies', diagnostic / 'dependencies.py')
    dependencies = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(dependencies)
    lines = (course / 'requirements.txt').read_text().splitlines()
    graph = dependencies.inspect_chain(lines, lookup)
    save(attempt / 'GPU_REQUIRED_DEPENDENCY_CHAIN.json', graph)
    if not graph['required_chain_passed']:
        raise RuntimeError('Required GPU dependency chain failed; inspect saved graph: ' + json.dumps(graph['issues']))
    from packaging.requirements import Requirement
    versions = {}
    for line in lines:
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        requirement = Requirement(line)
        version = metadata.version(requirement.name)
        if not requirement.specifier.contains(version, prereleases=False):
            raise RuntimeError('Course requirement differs: ' + line + ' installed=' + version)
        versions[requirement.name] = version

    import torch, transformers, tokenizers, peft, trl
    import datasets, accelerate, bitsandbytes, numpy, pandas
    import safetensors, yaml, matplotlib, sklearn, tqdm
    from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
    from peft import PeftModel
    from common.data import load_yaml
    from task4_safety.judge_responses import judge_one, parse_json, LABELS
    from task4_safety.make_audit_sheet import fixed_audit_ids
    if not torch.cuda.is_available() or torch.version.cuda is None:
        raise RuntimeError('The installed Torch build cannot use CUDA; no fallback is applied')
    devices = []
    for index in range(torch.cuda.device_count()):
        name, capability = torch.cuda.get_device_name(index), torch.cuda.get_device_capability(index)
        if 'A100' not in name.upper() or tuple(capability) != (8, 0):
            raise RuntimeError('Expected an A100 with compute capability 8.0: ' + name)
        devices.append({'name': name, 'compute_capability': list(capability),
                        'total_memory_bytes': torch.cuda.get_device_properties(index).total_memory})
    if not devices:
        raise RuntimeError('No CUDA devices are visible to Torch')
    # Two deliberately tiny backend checks, no model/prompt/data involved.
    device = torch.device('cuda:0')
    matrix = torch.tensor([[1., 2.], [3., 4.]], dtype=torch.float16, device=device)
    product = matrix @ torch.eye(2, dtype=torch.float16, device=device)
    if not torch.equal(matrix, product):
        raise RuntimeError('Tiny float16 CUDA matrix multiplication failed')
    fixture = torch.linspace(-1, 1, 256, dtype=torch.float16, device=device).reshape(16, 16)
    quantized, state = bitsandbytes.functional.quantize_4bit(fixture, quant_type='nf4')
    restored = bitsandbytes.functional.dequantize_4bit(quantized, quant_state=state)
    if (restored.shape != fixture.shape or restored.dtype != torch.float16 or
            state.quant_type != 'nf4' or not bool(torch.isfinite(restored).all())):
        raise RuntimeError('Tiny NF4 CUDA backend check failed')
    torch.cuda.synchronize()
    del matrix, product, fixture, quantized, state, restored
    configuration = load_yaml(str(course / 'configs/feedback.yaml'))
    if not (configuration['seed'] == 6304 and configuration['dtype'] == 'float16' and
            configuration['safety_max_new_tokens'] == 256 and configuration['judge_max_new_tokens'] == 64 and
            configuration['quantize_frozen_models'] is True and len(LABELS) == 5):
        raise RuntimeError('Released course configuration differs')
    print('A100 fresh imports, required dependency chain, float16 CUDA and tiny NF4 backend checks: PASS.', flush=True)
    import run_checks
    checks, transcript = run_checks.run()
    (attempt / 'GPU_SYNTHETIC_CHECKS.txt').write_text(transcript)
    save(attempt / 'GPU_SYNTHETIC_CHECKS.json', checks)
    print(transcript, end='', flush=True)
    if not checks['passed']:
        raise RuntimeError('The preserved 37-check synthetic suite failed in the A100 environment')
    probe = {'format': 'ATML_TASK4_A100_ENVIRONMENT_PROBE_V1', 'python': platform.python_version(),
             'course_package_versions': versions,
             'all_required_package_versions': {name: node['version'] for name, node in graph['nodes'].items()},
             'required_distributions': len(graph['nodes']), 'required_dependency_chain_passed': True,
             'fresh_process_imports_passed': True, 'cuda_available': True,
             'torch_cuda_version': torch.version.cuda, 'cuda_devices': devices,
             'tiny_float16_cuda_check_passed': True, 'tiny_nf4_cuda_backend_check_passed': True,
             'synthetic_semantic_checks_passed': checks['tests_run'],
             'course_configuration': configuration,
             'pretrained_model_weights_loaded': False, 'task4_responses_generated': 0,
             'task4_judgments_produced': 0, 'human_labels_assigned': 0,
             'gpu_model_loading_validation_pending': True}
    save(attempt / 'GPU_PROBE.json', probe)
    print('A100 synthetic orchestration checks: 37/37 PASS. Pretrained models loaded: 0.', flush=True)


if __name__ == '__main__':
    main()
