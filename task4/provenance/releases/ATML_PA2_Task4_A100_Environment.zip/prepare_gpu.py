"""Install unchanged course requirements in an A100 runtime and save evidence."""
from datetime import datetime, timezone
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

from gates import global_check_result, parse_a100_inventory, require

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
EXPERIMENT = Path('/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1')
STAGE1 = '9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65'
ORCHESTRATION = '35ca690761d2bfda0992ff37855b16fc72c03ffd4b47afaa81edc533ab7a5f65'
DIAGNOSTIC = '71bdb7fdbe130c5adaef8328437371bcd89621d0a93e849bab61b7db8491c540'
CPU_ATTEMPT = '20261011T123747.440376Z'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def main():
    stage1 = EXPERIMENT / 'preflight_releases' / STAGE1
    require(digest(stage1 / 'MANIFEST.json') == STAGE1, 'Preflight source identity differs')
    manifest = read(stage1 / 'MANIFEST.json')
    require(digest(stage1 / 'scripts/preflight.py') == manifest['scripts/preflight.py'], 'Preflight helper changed')
    spec = importlib.util.spec_from_file_location('task4_gpu_preflight', stage1 / 'scripts/preflight.py')
    preflight = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(preflight)
    preflight.verify_source(stage1)
    source = preflight.verify_source(ROOT)
    approval_hash = digest(stage1 / 'docs/approval.json')
    require(read(EXPERIMENT / 'OWNER.json')['approval_sha256'] == approval_hash and
            read(stage1 / 'docs/approval.json')['approved'] is True, 'Task 4 owner/approval differs')
    save, save_bytes = preflight.immutable_json, preflight.immutable_bytes
    persistent = EXPERIMENT / 'gpu_environment_releases' / source['manifest_sha256']
    for name in [*read(ROOT / 'MANIFEST.json'), 'MANIFEST.json']:
        save_bytes(persistent / name, (ROOT / name).read_bytes())
    attempt_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    attempt = EXPERIMENT / 'gpu_environment_attempts' / attempt_id
    attempt.mkdir(parents=True, exist_ok=False)
    report = {'format': 'ATML_TASK4_GPU_ENVIRONMENT_ATTEMPT_V1', 'status': 'RUNNING',
              'attempt_utc': attempt_id, 'source_manifest_sha256': source['manifest_sha256'],
              'approval_sha256': approval_hash, 'commands': [],
              'package_installation_attempted': False, 'model_downloads_performed': False,
              'pretrained_models_loaded': False, 'task4_responses_generated': 0,
              'task4_judgments_produced': 0, 'human_labels_assigned': 0, 'training_performed': False}

    def command(argv, name, display=True):
        event = {'stage': name, 'argv': [str(value) for value in argv]}
        save(attempt / (name + '_command.json'), event)
        print('A100 preparation:', name, flush=True)
        with (attempt / (name + '.log')).open('x') as log:
            process = subprocess.Popen(event['argv'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                       text=True, bufsize=1)
            for line in process.stdout:
                log.write(line)
                log.flush()
                if display:
                    print(line, end='', flush=True)
            event['returncode'] = process.wait()
        event['log_sha256'] = digest(attempt / (name + '.log'))
        save(attempt / (name + '_result.json'), event)
        report['commands'].append(event)
        return event['returncode']

    try:
        save(attempt / 'START.json', report)
        orchestration = EXPERIMENT / 'orchestration_releases' / ORCHESTRATION
        diagnostic = EXPERIMENT / 'diagnostic_releases' / DIAGNOSTIC
        for folder, identity in [(orchestration, ORCHESTRATION), (diagnostic, DIAGNOSTIC)]:
            require(digest(folder / 'MANIFEST.json') == identity, 'Saved source identity differs: ' + str(folder))
            preflight.verify_source(folder)
        previous_folder = EXPERIMENT / 'orchestration_attempts' / CPU_ATTEMPT
        previous = read(previous_folder / 'REPORT.json')
        require(previous['status'] == 'CPU_ORCHESTRATION_VALIDATED_NO_INFERENCE' and
                previous['source_manifest_sha256'] == ORCHESTRATION and
                previous['cpu_semantic_tests_passed'] == 37, 'Completed CPU orchestration result differs')
        for name, expected in previous['artifact_sha256'].items():
            require(Path(name).name == name and name not in {'.', '..'}, 'Unsafe saved report artifact')
            require(digest(previous_folder / name) == expected, 'Saved CPU artifact changed: ' + name)
        cpu_path = EXPERIMENT / 'CPU_ORCHESTRATION_VALIDATION_CONTRACT.json'
        require(digest(cpu_path) == previous['cpu_orchestration_validation_contract_sha256'], 'CPU protocol contract changed')
        cpu = read(cpu_path)
        require(cpu['format'] == 'ATML_TASK4_CPU_ORCHESTRATION_VALIDATION_V1' and cpu['tests_passed'] == 37 and
                cpu['source_manifest_sha256'] == ORCHESTRATION, 'CPU orchestration contract differs')
        inputs_path = EXPERIMENT / 'CPU_MODEL_INPUT_CONTRACT.json'
        require(digest(inputs_path) == cpu['model_input_contract_sha256'], 'Prepared model-input contract changed')
        inputs = read(inputs_path)
        for name, key in [('CPU_ENVIRONMENT_CONTRACT.json', 'environment_contract_sha256'),
                          ('INPUT_IDENTITY_CONTRACT.json', 'input_contract_sha256'),
                          ('AUDIT_ID_CONTRACT.json', 'audit_id_contract_sha256'),
                          ('BASE_MODEL_REFERENCE.json', 'base_model_reference_sha256'),
                          ('JUDGE_SNAPSHOT_CONTRACT.json', 'judge_snapshot_contract_sha256')]:
            require(digest(EXPERIMENT / name) == inputs[key], 'Frozen preparation contract changed: ' + name)
        require(inputs['sft_adapter'] is None and inputs['policy_order'] == ['sft', 'dpo', 'ppo', 'grpo'] and
                set(inputs['prepared_adapters']) == {'dpo', 'ppo', 'grpo'}, 'Frozen policy selection changed')
        for policy, adapter in inputs['prepared_adapters'].items():
            folder = Path(adapter['directory'])
            require(folder == EXPERIMENT / 'prepared_adapters' / policy and
                    set(adapter['files_sha256']) == {'adapter_config.json', 'adapter_model.safetensors'},
                    'Prepared adapter layout changed')
            for name, expected in adapter['files_sha256'].items():
                require(digest(folder / name) == expected, 'Prepared adapter changed: ' + policy + '/' + name)
        for name, expected in cpu['course_helper_sha256'].items():
            require(digest(stage1 / 'course_reference' / name) == expected, 'Tested course helper changed')
        data = read(EXPERIMENT / 'INPUT_IDENTITY_CONTRACT.json')['inputs']['xstest']
        csv = preflight.verify_csv(Path(data['path']), data['sha256'])
        require(csv['ordered_prompt_ids'] == data['ordered_prompt_ids'] and csv['prompts'] == 450 and
                csv['class_counts'] == {'SAFE': 250, 'UNSAFE': 200}, 'Fixed XSTest identity changed')
        audit = read(EXPERIMENT / 'AUDIT_ID_CONTRACT.json')
        require(len(audit['ordered_audit_prompt_ids']) == 60 and audit['manual_labels_assigned'] == 0,
                'Fixed audit contract changed')
        report['cpu_orchestration_report_sha256'] = digest(previous_folder / 'REPORT.json')
        report['cpu_orchestration_contract_sha256'] = digest(cpu_path)
        require(command(['nvidia-smi', '--query-gpu=name,memory.total,driver_version,uuid',
                         '--format=csv,noheader,nounits'], 'nvidia_inventory') == 0, 'NVIDIA driver query failed')
        hardware = parse_a100_inventory((attempt / 'nvidia_inventory.log').read_text())
        save(attempt / 'A100_HARDWARE.json', hardware)
        before = {item.metadata['Name'].lower().replace('_', '-'): item.version for item in metadata.distributions()
                  if item.metadata.get('Name')}
        save(attempt / 'PACKAGE_VERSIONS_BEFORE.json', before)
        requirements = stage1 / 'course_reference/requirements.txt'
        report['unchanged_course_requirements_sha256'] = digest(requirements)
        report['package_installation_attempted'] = True
        install_result = command([sys.executable, '-m', 'pip', 'install', '-r', requirements], 'install_unchanged_course_requirements')
        after = {item.metadata['Name'].lower().replace('_', '-'): item.version for item in metadata.distributions()
                 if item.metadata.get('Name')}
        save(attempt / 'PACKAGE_VERSIONS_AFTER.json', after)
        changes = {name: {'before': before.get(name), 'after': after.get(name)}
                   for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)}
        save(attempt / 'PACKAGE_CHANGES.json', changes)
        report['packages_changed'] = len(changes)
        require(install_result == 0, 'Course requirement installation failed; no workaround is applied')
        global_rc = command([sys.executable, '-m', 'pip', 'check'], 'global_dependency_check')
        cpu_environment = read(EXPERIMENT / 'CPU_ENVIRONMENT_CONTRACT.json')
        global_result = global_check_result(global_rc, (attempt / 'global_dependency_check.log').read_text(),
                                           cpu_environment['approved_global_dependency_messages'])
        save(attempt / 'GLOBAL_CHECK_ASSESSMENT.json', global_result)
        require(command([sys.executable, '-B', '-u', ROOT / 'probe_gpu.py', stage1,
                         orchestration, diagnostic, attempt], 'fresh_gpu_probe') == 0,
                'Fresh A100 probe failed; inspect preserved output. No fallback is applied.')
        probe = read(attempt / 'GPU_PROBE.json')
        require(probe['synthetic_semantic_checks_passed'] == 37, 'Synthetic check count differs')
        save(attempt / 'CPU_GPU_REQUIRED_PACKAGE_COMPARISON.json',
             {name: {'cpu': cpu_environment['all_required_package_versions'].get(name),
                     'gpu': probe['all_required_package_versions'].get(name)}
              for name in sorted(set(cpu_environment['all_required_package_versions']) |
                                 set(probe['all_required_package_versions']))})
        report.update({'required_dependency_chain_passed': True,
                       'required_distributions': probe['required_distributions'],
                       'a100_cuda_available': True, 'tiny_float16_cuda_check_passed': True,
                       'tiny_nf4_cuda_backend_check_passed': True, 'synthetic_checks_passed': 37,
                       'gpu_model_loading_validation_pending': True, **global_result})
        if global_result['review_required']:
            report['status'] = 'GPU_ENVIRONMENT_REVIEW_REQUIRED'
            report['gpu_environment_contract_finalized'] = False
            print('Task-required chain, A100 backends and 37 synthetic checks pass; global dependency messages require review.', flush=True)
            print('The earlier exception approval was CPU-specific. No GPU exceptions have been accepted.', flush=True)
        else:
            contract = {'format': 'ATML_TASK4_GPU_ENVIRONMENT_V1',
                'source_manifest_sha256': source['manifest_sha256'],
                'cpu_orchestration_contract_sha256': digest(cpu_path),
                'model_input_contract_sha256': digest(inputs_path),
                'approval_sha256': approval_hash, 'course_requirements_sha256': digest(requirements),
                **{key: probe[key] for key in ['python', 'course_package_versions', 'all_required_package_versions',
                    'required_distributions', 'required_dependency_chain_passed', 'fresh_process_imports_passed',
                    'cuda_available', 'torch_cuda_version', 'tiny_float16_cuda_check_passed',
                    'tiny_nf4_cuda_backend_check_passed', 'synthetic_semantic_checks_passed']},
                'hardware_requirement': 'A100, compute capability 8.0',
                'global_dependency_check_passed': True, 'gpu_exceptions_accepted': [],
                'pretrained_model_weights_loaded': False, 'gpu_model_loading_validation_pending': True}
            save(EXPERIMENT / 'GPU_ENVIRONMENT_CONTRACT.json', contract)
            report.update({'status': 'A100_ENVIRONMENT_VALIDATED_NO_INFERENCE',
                           'gpu_environment_contract_finalized': True,
                           'gpu_environment_contract_sha256': digest(EXPERIMENT / 'GPU_ENVIRONMENT_CONTRACT.json')})
        print('Remaining: generation 1800; judging 1800; human labels 240.', flush=True)
        print('No pretrained model loaded. Wait for the next reviewed block.', flush=True)
    except BaseException as error:
        report['status'] = 'GPU_ENVIRONMENT_FAILED_PRESERVED'
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        report['artifact_sha256'] = {path.name: digest(path) for path in attempt.iterdir() if path.is_file()}
        save(attempt / 'REPORT.json', report)
        print('Saved GPU environment report:', attempt / 'REPORT.json', flush=True)
        print('Status:', report['status'], flush=True)


if __name__ == '__main__':
    main()
