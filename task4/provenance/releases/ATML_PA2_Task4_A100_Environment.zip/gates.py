"""Small runtime gates; CPU-only exception approval is never extended to GPU."""
import csv
import io


def require(value, message):
    if not value:
        raise RuntimeError(message)


def parse_a100_inventory(text):
    rows = list(csv.reader(io.StringIO(text)))
    require(bool(rows), 'No NVIDIA GPU was reported. Select an A100 runtime.')
    result = []
    for row in rows:
        require(len(row) == 4, 'Unexpected nvidia-smi inventory format')
        name, memory, driver, uuid = [value.strip() for value in row]
        require('A100' in name.upper(), 'This stage requires an A100; found: ' + name)
        require(int(memory) > 0 and bool(driver) and bool(uuid), 'Incomplete GPU inventory')
        result.append({'name': name, 'total_memory_mib': int(memory),
                       'driver_version': driver, 'uuid': uuid})
    return result


def global_check_result(returncode, output, cpu_approved_messages):
    # The prior exception approval explicitly finalized the CPU environment.
    # Matching messages here are diagnostic context, never GPU acceptance.
    messages = sorted(line.strip() for line in output.splitlines() if line.strip())
    failed = returncode != 0
    return {'global_dependency_check_passed': not failed,
            'global_dependency_check_returncode': returncode,
            'global_dependency_messages': messages if failed else [],
            'messages_matching_prior_cpu_approval': sorted(set(messages) & set(cpu_approved_messages)) if failed else [],
            'gpu_exceptions_accepted': [],
            'review_required': failed}
