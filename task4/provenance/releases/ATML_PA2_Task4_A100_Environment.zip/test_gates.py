import unittest
from gates import global_check_result, parse_a100_inventory


class RuntimeGates(unittest.TestCase):
    def test_a100_inventory(self):
        value = parse_a100_inventory('NVIDIA A100-SXM4-40GB, 40960, 580.0, GPU-fixture\n')
        self.assertEqual(value[0]['total_memory_mib'], 40960)
        self.assertEqual(value[0]['name'], 'NVIDIA A100-SXM4-40GB')

    def test_other_gpu_is_rejected(self):
        with self.assertRaises(RuntimeError):
            parse_a100_inventory('Tesla T4, 15360, 580.0, GPU-fixture\n')

    def test_missing_or_malformed_inventory_is_rejected(self):
        for text in ['', 'NVIDIA A100, 40960\n', 'NVIDIA A100, 0, 580.0, GPU-fixture\n']:
            with self.subTest(text=text), self.assertRaises(RuntimeError):
                parse_a100_inventory(text)

    def test_clean_global_check_passes(self):
        value = global_check_result(0, 'No broken requirements found.\n', ['old CPU issue'])
        self.assertTrue(value['global_dependency_check_passed'])
        self.assertFalse(value['review_required'])
        self.assertEqual(value['global_dependency_messages'], [])

    def test_cpu_approved_issue_still_requires_gpu_review(self):
        value = global_check_result(1, 'old CPU issue\n', ['old CPU issue'])
        self.assertTrue(value['review_required'])
        self.assertEqual(value['messages_matching_prior_cpu_approval'], ['old CPU issue'])
        self.assertEqual(value['gpu_exceptions_accepted'], [])

    def test_new_or_unexplained_failure_requires_review(self):
        for message in ['new issue\n', '']:
            value = global_check_result(1, message, ['old CPU issue'])
            self.assertTrue(value['review_required'])
            self.assertEqual(value['gpu_exceptions_accepted'], [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
