# Task 4 Block 3: CPU model inventory

## Entered state

The returned recovery status is CPU_ENVIRONMENT_AND_AUDIT_FINALIZED_WITH_APPROVED_EXCEPTIONS from recovery_attempts/20261011T112205.775509Z. The CPU environment and 60-ID audit contracts were finalized. All 64 required dependency records pass; three approved outside-chain global Colab issues remain recorded as failures. Generation 0/1,800; judging 0/1,800; human labels 0/240. Model loading and inference validation remain pending.

## Scope

Run in the same CPU Colab runtime. The script verifies the finalized environment/audit contract hashes against the successful recovery report, the recovery approval, ownership, input identity, original/recovery source manifests and all 64 required package versions. It preserves its own source and current-state observation before inspecting model files.

The existing base policy is Qwen/Qwen2.5-1.5B-Instruct revision 989aa7980e4cf806f80c7fef2b1adb7bc71aa306. Task 3's exported preparation receipt supplies the expected model_manifest.json SHA-256 b00f63237dda95ad175983bf231ac52a4133242d831e13f07629fa247b353aa8. The script verifies the same manifest and model identity on Drive, hashes every recorded file in task3/experiment_v1/models/policy, checks exact file coverage excluding Hugging Face bookkeeping cache, and checks any safetensors index references. The base remains at its existing location and is not copied, altered, loaded or automatically replaced. Full hashing reads the saved weight bytes and may take several minutes on Drive.

The required categorical safety judge is Qwen/Qwen2.5-3B-Instruct. Public Hugging Face model_info calls inspect its default branch metadata and then the exact observed commit's metadata with files_metadata=True. Authentication is disabled for these public calls; no token is printed. The result records repository commit, all listed filenames, sizes, Git blob IDs and LFS weight hashes. A proposed standard Transformers snapshot consists of root-level JSON, safetensors, model, text and Jinja files. It reports the byte total for review. No model file or weight is downloaded, no repository revision is selected for the experiment, and no model is constructed. An optional read-only list of the specific judge's local Hub cache revisions records possible existing candidates, without asserting their integrity or choosing one.

All prior Task 3 inputs and Task 4 source releases, contracts and reports stay read only. No Task 3 time limit, disconnect setting, training setting or reward model is inherited. Missing/mismatched local files or incomplete/failed remote metadata stop and preserve the error. There is no alternate-model, alternate-path or download fallback.

## Saved evidence

Drive root: MyDrive/ATML-Assignment-2/task4/experiment_v1.

- model_inventory_releases/<source manifest SHA-256>: exact source, context, entered-state observation, Task 3 baseline and local validation.
- model_inventory_attempts/<UTC timestamp>: START.json, BASE_MODEL_INVENTORY.json, JUDGE_METADATA_PROPOSAL.json and REPORT.json with hashes and completed per-file integrity checks, including after catchable failures.

Expected success status: BASE_FILES_VERIFIED_JUDGE_METADATA_READY. It confirms base file integrity and availability of judge metadata, not successful model loading or inference. Judge revision/download selection remains pending explicit user approval after the returned metadata can be reviewed.

## Local validation and attribution

Four synthetic integrity/metadata tests pass: accepted matching files with corruption rejection; missing file rejection; path escape rejection; judge metadata remains a proposal with rejection of missing weight hashes. These are synthetic byte fixtures, not actual model weights. Source syntax, historical source identities and archive payloads are checked locally; actual Colab model hashing and remote metadata inspection remain pending.

Task 3 baseline comes from the previously exported task3/results/actual_run_20261011/results.json. Its source hash is recorded in TASK3_BASELINE.json. Task 4 model IDs/settings remain those of the preserved course configuration. Hugging Face metadata API reference: https://huggingface.co/docs/huggingface_hub/v0.36.0/en/package_reference/hf_api#huggingface_hub.HfApi.model_info . New inventory orchestration was created with Codex assistance.
