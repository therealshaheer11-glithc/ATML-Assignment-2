import hashlib
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from inventory import JUDGE, judge_metadata, safe_file, verify_files


class InventoryBoundaries(unittest.TestCase):
    def test_matching_model_files_pass_and_corruption_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            (folder / "config.json").write_bytes(b"{}")
            (folder / "model.safetensors").write_bytes(b"synthetic bytes, not model weights")
            expected = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir()}
            self.assertEqual(set(verify_files(folder, expected)), set(expected))
            (folder / "model.safetensors").write_bytes(b"corrupt")
            with self.assertRaisesRegex(RuntimeError, "checksum differs"):
                verify_files(folder, expected)

    def test_unrecorded_or_missing_model_file_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaisesRegex(RuntimeError, "files differ"):
                verify_files(Path(folder), {"missing.json": "0" * 64})

    def test_model_path_escape_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaisesRegex(RuntimeError, "Unsafe model file path"):
                safe_file(Path(folder), "../outside")

    def test_judge_metadata_remains_a_proposal_and_missing_hash_is_rejected(self):
        siblings = [SimpleNamespace(rfilename=name, size=10, blob_id="a" * 40,
                       lfs={"sha256": "b" * 64} if name.endswith(".safetensors") else None)
                    for name in ["config.json", "tokenizer_config.json", "model.safetensors"]]
        info = SimpleNamespace(id=JUDGE, sha="c" * 40, siblings=siblings)
        result = judge_metadata(info)
        self.assertEqual(result["proposed_download_bytes"], 30)
        self.assertFalse(result["revision_selected_for_experiment"])
        self.assertFalse(result["weight_download_performed"])
        siblings[-1].lfs = None
        with self.assertRaisesRegex(RuntimeError, "weight hash unavailable"):
            judge_metadata(info)


if __name__ == "__main__":
    unittest.main(verbosity=2)
