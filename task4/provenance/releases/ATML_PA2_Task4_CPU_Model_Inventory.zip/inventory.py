"""CPU integrity inventory; no model downloads, loading, inference or selection."""
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
EXPERIMENT = Path("/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1")
STAGE1 = "9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65"
RECOVERY = "6629e696e04632096dcd79e3f41fe1e28fb55e7aee8c95ec17e33f383928dda8"
RECOVERY_ATTEMPT = "20261011T112205.775509Z"
BASE = "Qwen/Qwen2.5-1.5B-Instruct"
BASE_REVISION = "989aa7980e4cf806f80c7fef2b1adb7bc71aa306"
JUDGE = "Qwen/Qwen2.5-3B-Instruct"


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def safe_file(folder, name):
    relative = PurePosixPath(name)
    require(not relative.is_absolute() and ".." not in relative.parts, "Unsafe model file path: " + name)
    target = folder / name
    require(folder.resolve() in target.resolve().parents, "Model file escapes its folder: " + name)
    return target


def verify_files(folder, expected, progress=None):
    actual = {p.relative_to(folder).as_posix() for p in folder.rglob("*")
              if p.is_file() and ".cache" not in p.relative_to(folder).parts}
    require(actual == set(expected), "Model folder files differ from the frozen manifest")
    result = {}
    for index, (name, expected_hash) in enumerate(sorted(expected.items()), 1):
        path = safe_file(folder, name)
        print("Hash-checking base file", str(index) + "/" + str(len(expected)) + ":", name, flush=True)
        require(path.is_file() and digest(path) == expected_hash, "Base model checksum differs: " + name)
        result[name] = {"sha256": expected_hash, "bytes": path.stat().st_size}
        if progress is not None:
            progress(result)
    require("config.json" in result and any(name.endswith(".safetensors") for name in result),
            "Verified model configuration or weights are missing")
    for name in result:
        if name.endswith(".safetensors.index.json"):
            referenced = set(read_json(folder / name)["weight_map"].values())
            require(referenced <= set(result), "Weight index references an unverified shard")
    return result


def field(obj, name):
    return obj.get(name) if isinstance(obj, dict) else getattr(obj, name, None)


def judge_metadata(info):
    require(info.id == JUDGE and re.fullmatch(r"[0-9a-f]{40}", info.sha or ""), "Judge repository identity is invalid")
    files = {}
    for item in info.siblings or []:
        name = item.rfilename
        relative = PurePosixPath(name)
        require(not relative.is_absolute() and ".." not in relative.parts, "Unsafe remote file path")
        lfs = field(item, "lfs")
        files[name] = {"bytes": field(item, "size") if field(item, "size") is not None else field(lfs, "size"),
                       "git_blob_id": field(item, "blob_id"), "lfs_sha256": field(lfs, "sha256")}
    # A proposed standard Transformers snapshot, not an authorized download.
    suffixes = {".json", ".safetensors", ".model", ".txt", ".jinja"}
    proposed = {name: value for name, value in files.items()
                if len(PurePosixPath(name).parts) == 1 and PurePosixPath(name).suffix in suffixes}
    weights = {name: value for name, value in proposed.items() if name.endswith(".safetensors")}
    require("config.json" in proposed and "tokenizer_config.json" in proposed and weights,
            "Judge configuration, tokenizer or safetensors metadata is missing")
    for name, value in proposed.items():
        require(isinstance(value["bytes"], int) and value["bytes"] >= 0, "Remote file size unavailable: " + name)
    for name, value in weights.items():
        require(re.fullmatch(r"[0-9a-f]{64}", value["lfs_sha256"] or ""), "Remote weight hash unavailable: " + name)
    return {"model_id": JUDGE, "observed_revision": info.sha, "all_repository_files": files,
            "proposed_snapshot_files": proposed,
            "proposed_download_bytes": sum(value["bytes"] for value in proposed.values()),
            "weights_bytes": sum(value["bytes"] for value in weights.values()),
            "weight_files": len(weights), "revision_selected_for_experiment": False,
            "weight_download_performed": False}


def main():
    release = EXPERIMENT / "preflight_releases" / STAGE1
    require(digest(release / "MANIFEST.json") == STAGE1, "Preflight source identity differs")
    manifest = read_json(release / "MANIFEST.json")
    require(digest(release / "scripts/preflight.py") == manifest["scripts/preflight.py"], "Preflight helper differs")
    spec = importlib.util.spec_from_file_location("task4_inventory_preflight", release / "scripts/preflight.py")
    preflight = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(preflight)
    preflight.verify_source(release)
    preflight.verify_source(ROOT)
    preflight.require_cpu()
    save, save_bytes = preflight.immutable_json, preflight.immutable_bytes
    environment = read_json(EXPERIMENT / "CPU_ENVIRONMENT_CONTRACT.json")
    require(environment["format"] == "ATML_TASK4_CPU_ENVIRONMENT_V2" and
            environment["required_dependency_chain_passed"] is True and
            environment["global_dependency_check_passed"] is False, "Approved environment contract differs")
    require(environment["recovery_source_manifest_sha256"] == RECOVERY, "Recovery source identity differs")
    recovery_source = EXPERIMENT / "recovery_releases" / RECOVERY
    require(digest(recovery_source / "MANIFEST.json") == RECOVERY, "Recovery manifest differs")
    preflight.verify_source(recovery_source)
    recovery_report_path = EXPERIMENT / "recovery_attempts" / RECOVERY_ATTEMPT / "REPORT.json"
    recovery_report = read_json(recovery_report_path)
    require(recovery_report["status"] == "CPU_ENVIRONMENT_AND_AUDIT_FINALIZED_WITH_APPROVED_EXCEPTIONS", "Recovery did not finalize")
    for filename, key in [("CPU_ENVIRONMENT_CONTRACT.json", "cpu_environment_contract_sha256"),
                          ("AUDIT_ID_CONTRACT.json", "audit_id_contract_sha256")]:
        require(digest(EXPERIMENT / filename) == recovery_report[key], "Finalized contract differs: " + filename)
    require(digest(EXPERIMENT / "ENVIRONMENT_RECOVERY_APPROVAL.json") == environment["recovery_approval_sha256"], "Recovery approval differs")
    require(digest(EXPERIMENT / "INPUT_IDENTITY_CONTRACT.json") == environment["input_contract_sha256"], "Input identity contract differs")
    require(read_json(EXPERIMENT / "OWNER.json")["approval_sha256"] == environment["approval_sha256"], "Experiment owner differs")
    for name, version in environment["all_required_package_versions"].items():
        require(importlib.metadata.version(name) == version, "Required package version changed: " + name)
    identity = digest(ROOT / "MANIFEST.json")
    preserved = EXPERIMENT / "model_inventory_releases" / identity
    for name in [*read_json(ROOT / "MANIFEST.json"), "MANIFEST.json"]:
        save_bytes(preserved / name, (ROOT / name).read_bytes())
    attempt_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    attempt = EXPERIMENT / "model_inventory_attempts" / attempt_id
    attempt.mkdir(parents=True, exist_ok=False)
    report = {"format": "ATML_TASK4_MODEL_INVENTORY_V1", "status": "RUNNING",
              "attempt_utc": attempt_id, "source_manifest_sha256": identity,
              "recovery_report_sha256": digest(recovery_report_path),
              "environment_contract_sha256": digest(EXPERIMENT / "CPU_ENVIRONMENT_CONTRACT.json"),
              "model_weights_downloaded": False, "model_weights_loaded": False,
              "generation_performed": False, "judging_performed": False, "training_performed": False,
              "judge_revision_selected_for_experiment": False, "base_verified_files": {}}
    try:
        save(attempt / "START.json", report)
        baseline = read_json(ROOT / "TASK3_BASELINE.json")
        task3 = Path("/content/drive/MyDrive") / baseline["drive_relative_root"]
        preparation = read_json(task3 / "PREPARATION.json")
        manifest_path = task3 / "models/model_manifest.json"
        require(digest(manifest_path) == baseline["model_manifest_sha256"] == preparation["model_manifest_sha256"],
                "Task 3 model manifest differs from the exported baseline")
        entry = read_json(manifest_path)["policy"]
        require(entry["model_id"] == baseline["policy_model"] == BASE and
                entry["revision"] == baseline["policy_revision"] == BASE_REVISION and
                entry["directory"] == "policy", "Prepared base model identity differs")
        folder = task3 / "models/policy"
        files = verify_files(folder, entry["sha256"], lambda verified: report.update({"base_verified_files": dict(verified)}))
        config = read_json(folder / "config.json")
        base_receipt = {"model_id": BASE, "revision": BASE_REVISION, "directory": str(folder),
                        "model_manifest_sha256": digest(manifest_path), "verified_files": files,
                        "total_bytes": sum(item["bytes"] for item in files.values()),
                        "model_type": config.get("model_type"), "architectures": config.get("architectures"),
                        "all_saved_files_verified": True, "model_weights_loaded": False}
        save(attempt / "BASE_MODEL_INVENTORY.json", base_receipt)
        print("Existing pinned base snapshot: VERIFIED —", len(files), "files;", base_receipt["total_bytes"], "bytes.", flush=True)
        print("Reading public judge repository metadata only; no weight download.", flush=True)
        from huggingface_hub import HfApi
        from huggingface_hub.constants import HF_HUB_CACHE
        api = HfApi(token=False)
        head = api.model_info(JUDGE, timeout=30)
        require(head.id == JUDGE and re.fullmatch(r"[0-9a-f]{40}", head.sha or ""),
                "Judge head metadata has no valid repository commit")
        candidate = judge_metadata(api.model_info(JUDGE, revision=head.sha, files_metadata=True, timeout=30))
        require(candidate["observed_revision"] == head.sha, "Judge metadata revision changed during inspection")
        save(attempt / "JUDGE_METADATA_PROPOSAL.json", candidate)
        snapshots = Path(HF_HUB_CACHE) / "models--Qwen--Qwen2.5-3B-Instruct/snapshots"
        cached = []
        if snapshots.is_dir():
            for path in sorted(snapshots.iterdir()):
                if path.is_dir() and re.fullmatch(r"[0-9a-f]{40}", path.name):
                    cached.append({"revision": path.name, "config_present": (path / "config.json").is_file(),
                                   "weight_filenames": sorted(p.name for p in path.glob("*.safetensors")),
                                   "integrity_verified": False})
        report.update({"status": "BASE_FILES_VERIFIED_JUDGE_METADATA_READY",
                       "base_inventory_sha256": digest(attempt / "BASE_MODEL_INVENTORY.json"),
                       "judge_metadata_proposal_sha256": digest(attempt / "JUDGE_METADATA_PROPOSAL.json"),
                       "judge_observed_revision": candidate["observed_revision"],
                       "judge_proposed_download_bytes": candidate["proposed_download_bytes"],
                       "existing_local_judge_cache_snapshots": cached})
        print("Judge model:", JUDGE, flush=True)
        print("Observed judge commit:", candidate["observed_revision"], flush=True)
        print("Proposed judge snapshot:", len(candidate["proposed_snapshot_files"]), "files;",
              candidate["proposed_download_bytes"], "bytes (", round(candidate["proposed_download_bytes"] / 1e9, 3), "GB).", flush=True)
        print("Existing local judge cache candidates:", json.dumps(cached), flush=True)
        print("Judge revision/download choice remains pending explicit approval.", flush=True)
        print("Remaining: generation 1800; judging 1800; human labels 240. Stay on CPU.", flush=True)
    except BaseException as error:
        report["status"] = "MODEL_INVENTORY_FAILED_PRESERVED"
        report["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        report["artifact_sha256"] = {p.name: digest(p) for p in attempt.iterdir() if p.is_file()}
        save(attempt / "REPORT.json", report)
        print("Saved model inventory report:", attempt / "REPORT.json", flush=True)
        print("Status:", report["status"], flush=True)


if __name__ == "__main__":
    main()
