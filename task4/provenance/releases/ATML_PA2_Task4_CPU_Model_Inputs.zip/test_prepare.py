"""Synthetic adapter integrity tests; no model weights or network access."""
import copy
import hashlib
import json
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch

import prepare as stage


BASE = {'hidden_size': 8, 'num_attention_heads': 4, 'num_key_value_heads': 2, 'num_hidden_layers': 2}
ADAPTER = {'r': 8, 'lora_alpha': 16, 'lora_dropout': 0.05, 'target_modules': ['q_proj', 'v_proj'],
           'peft_type': 'LORA', 'task_type': 'CAUSAL_LM', 'base_model_name_or_path': '/historical/snapshot'}


def fixture():
    header, cursor = {'__metadata__': {'format': 'pt'}}, 0
    for layer in range(2):
        for module in ['q_proj', 'v_proj']:
            for factor in ['A', 'B']:
                shape = [8, 8] if factor == 'A' else [8 if module == 'q_proj' else 4, 8]
                size = shape[0] * shape[1] * 4
                key = f'base_model.model.model.layers.{layer}.self_attn.{module}.lora_{factor}.weight'
                header[key] = {'dtype': 'F32', 'shape': shape, 'data_offsets': [cursor, cursor + size]}
                cursor += size
    return header, cursor


def pack(header, data_size):
    raw = json.dumps(header).encode()
    return struct.pack('<Q', len(raw)) + raw + bytes(data_size)


def immutable(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_bytes() != payload:
        raise RuntimeError('Existing payload differs')
    path.write_bytes(payload)


class AdapterPreparationBoundaries(unittest.TestCase):
    def test_header_shapes_and_complete_coverage_pass_without_tensor_loading(self):
        header, size = fixture()
        result = stage.inspect_lora_header(pack(header, size), ADAPTER, BASE)
        self.assertEqual(result['tensor_count'], 8)
        self.assertEqual(result['parameter_count'] * 4, size)
        self.assertFalse(result['tensor_values_materialized'])
        self.assertEqual(ADAPTER['base_model_name_or_path'], '/historical/snapshot')

    def test_shape_mismatch_with_pinned_base_rejected(self):
        header, size = fixture()
        header[next(key for key in header if key != '__metadata__')]['shape'] = [8, 7]
        with self.assertRaisesRegex(RuntimeError, 'shape differs'):
            stage.inspect_lora_header(pack(header, size), ADAPTER, BASE)

    def test_missing_or_unexpected_layer_target_rejected(self):
        original, size = fixture()
        for variant in ['missing', 'unexpected']:
            header = copy.deepcopy(original)
            name = next(key for key in header if key != '__metadata__')
            value = header.pop(name)
            if variant == 'unexpected':
                header[name.replace('q_proj', 'k_proj')] = value
            with self.subTest(variant=variant), self.assertRaises(RuntimeError):
                stage.inspect_lora_header(pack(header, size), ADAPTER, BASE)

    def test_overlap_hole_or_trailing_bytes_rejected(self):
        header, size = fixture()
        names = [key for key in header if key != '__metadata__']
        for delta in [-1, 1]:
            changed = copy.deepcopy(header)
            changed[names[1]]['data_offsets'] = [x + delta for x in changed[names[1]]['data_offsets']]
            with self.subTest(delta=delta), self.assertRaisesRegex(RuntimeError, 'overlap or have holes'):
                stage.inspect_lora_header(pack(changed, size), ADAPTER, BASE)
        with self.assertRaisesRegex(RuntimeError, 'data length differs'):
            stage.inspect_lora_header(pack(header, size + 1), ADAPTER, BASE)

    def test_invalid_header_and_duplicate_keys_rejected(self):
        with self.assertRaisesRegex(RuntimeError, 'too short'):
            stage.inspect_lora_header(b'', ADAPTER, BASE)
        with self.assertRaisesRegex(RuntimeError, 'length is invalid'):
            stage.inspect_lora_header(struct.pack('<Q', 999) + b'{}', ADAPTER, BASE)
        with self.assertRaisesRegex(RuntimeError, 'Duplicate'):
            stage.unique_object([('same', 1), ('same', 2)])

    def test_hidden_parameterization_change_rejected(self):
        for field, value in [('r', 4), ('rank_pattern', {'q_proj': 4}), ('use_dora', True),
                             ('target_modules', ['k_proj', 'q_proj'])]:
            cfg = {**ADAPTER, field: value}
            with self.subTest(field=field), self.assertRaises(RuntimeError):
                stage.validate_adapter_config(cfg)

    def test_late_existing_conflict_prevents_all_earlier_copy_writes(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            conflict = root / 'prepared_adapters/ppo/adapter_config.json'
            conflict.parent.mkdir(parents=True)
            conflict.write_bytes(b'old preserved bytes')
            bundles = {name: {'adapter_config.json': b'{}', 'adapter_model.safetensors': b'fake'}
                       for name in ['dpo', 'ppo']}
            with self.assertRaisesRegex(RuntimeError, 'differs; preserved'):
                stage.prepare_adapter_copies(root, bundles, immutable)
            self.assertFalse((root / 'prepared_adapters/dpo').exists())
            self.assertEqual(conflict.read_bytes(), b'old preserved bytes')

    def test_copy_rerun_reuses_exact_original_bytes_and_sha(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            cfg = json.dumps(ADAPTER).encode()
            header, size = fixture()
            bundles = {'ppo': {'adapter_config.json': cfg, 'adapter_model.safetensors': pack(header, size)}}
            first = stage.prepare_adapter_copies(root, bundles, immutable)
            second = stage.prepare_adapter_copies(root, bundles, immutable)
            self.assertEqual(first, second)
            self.assertEqual((root / 'prepared_adapters/ppo/adapter_config.json').read_bytes(), cfg)
            self.assertEqual(first['ppo']['files_sha256']['adapter_config.json'], hashlib.sha256(cfg).hexdigest())

    def test_snapshot_metadata_hashes_checked_without_rehashing_weight_bytes(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            metadata, weight = b'{}', b'synthetic model weight bytes'
            (root / 'config.json').write_bytes(metadata)
            (root / 'model.safetensors').write_bytes(weight)
            files = {p.name: {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                     for p in root.iterdir()}
            original_digest = stage.digest
            with patch.object(stage, 'digest', wraps=original_digest) as hashed:
                result = stage.verify_snapshot_metadata(root, files)
                self.assertEqual([item.args[0].name for item in hashed.call_args_list], ['config.json'])
                self.assertFalse(result['weight_files_rehashed_this_block'])
            (root / 'config.json').write_bytes(b'[]')
            with self.assertRaisesRegex(RuntimeError, 'metadata changed'):
                stage.verify_snapshot_metadata(root, files)


if __name__ == '__main__':
    unittest.main(verbosity=2)
