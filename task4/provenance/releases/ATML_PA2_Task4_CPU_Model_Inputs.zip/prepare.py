"""CPU-only frozen adapters, tokenizers and generation metadata preparation."""
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import re
import struct
import sys
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
EXPERIMENT = Path('/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1')
STAGE1 = '9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65'
DOWNLOAD = '0f1b51a93ec1d861f336fe4eae1c360939e166526eceeaeab023e6b5ac7d1f16'
DOWNLOAD_ATTEMPT = '20261011T115834.218702Z'
ADAPTER_FILES = ('adapter_config.json', 'adapter_model.safetensors')


def require(value, message):
    if not value:
        raise RuntimeError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def json_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    allow_nan=False).encode()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_adapter_config(cfg):
    require(cfg.get('r') == 8 and cfg.get('lora_alpha') == 16 and cfg.get('lora_dropout') == 0.05,
            'Frozen adapter LoRA settings differ')
    require(set(cfg.get('target_modules', [])) == {'q_proj', 'v_proj'} and
            cfg.get('peft_type') == 'LORA' and cfg.get('task_type') == 'CAUSAL_LM',
            'Frozen adapter family or targets differ')
    require(not cfg.get('rank_pattern') and not cfg.get('alpha_pattern') and
            not cfg.get('use_dora', False) and cfg.get('bias', 'none') == 'none',
            'Unexpected adapter parameterization')


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate safetensors header key')
        result[key] = value
    return result


def inspect_lora_header(payload, adapter, base):
    """Read names/shapes/offsets only; never deserialize tensor values."""
    validate_adapter_config(adapter)
    require(len(payload) >= 8, 'Safetensors file is too short')
    size = struct.unpack('<Q', payload[:8])[0]
    require(0 < size <= len(payload) - 8, 'Safetensors header length is invalid')
    header = json.loads(payload[8:8 + size], object_pairs_hook=unique_object)
    require(isinstance(header, dict), 'Safetensors header is not an object')
    tensors = {key: value for key, value in header.items() if key != '__metadata__'}
    hidden, heads = int(base['hidden_size']), int(base['num_attention_heads'])
    head_dim = int(base.get('head_dim') or hidden // heads)
    layers, rank = int(base['num_hidden_layers']), int(adapter['r'])
    out_rows = {'q_proj': heads * head_dim, 'v_proj': int(base['num_key_value_heads']) * head_dim}
    expected = {(layer, module, factor) for layer in range(layers)
                for module in ['q_proj', 'v_proj'] for factor in ['A', 'B']}
    seen, intervals, shapes = set(), [], {}
    dtype_bytes = {'F16': 2, 'BF16': 2, 'F32': 4}
    for name, item in tensors.items():
        match = re.search(r'(?:^|\.)layers\.(\d+)\.self_attn\.(q_proj|v_proj)\.lora_([AB])(?:\.default)?\.weight$', name)
        require(match is not None, 'Unexpected adapter tensor: ' + name)
        layer, module, factor = int(match[1]), match[2], match[3]
        key = (layer, module, factor)
        require(key in expected and key not in seen, 'Unexpected/duplicate adapter tensor placement')
        seen.add(key)
        shape = [rank, hidden] if factor == 'A' else [out_rows[module], rank]
        require(item['shape'] == shape, 'Adapter tensor shape differs from the pinned base: ' + name)
        require(item['dtype'] in dtype_bytes, 'Unexpected saved adapter dtype: ' + name)
        begin, end = item['data_offsets']
        require(type(begin) is int and type(end) is int and 0 <= begin < end and
                end - begin == math.prod(shape) * dtype_bytes[item['dtype']], 'Invalid tensor byte range')
        intervals.append((begin, end))
        shapes[name] = {'shape': shape, 'dtype': item['dtype']}
    require(seen == expected, 'Adapter tensor layer/target coverage differs')
    cursor = 0
    for begin, end in sorted(intervals):
        require(begin == cursor, 'Adapter tensor byte ranges overlap or have holes')
        cursor = end
    require(cursor == len(payload) - 8 - size, 'Adapter tensor data length differs')
    return {'tensor_count': len(tensors), 'layers': layers, 'target_modules': ['q_proj', 'v_proj'],
            'rank': rank, 'tensor_shapes_and_dtypes': shapes,
            'parameter_count': sum(math.prod(item['shape']) for item in shapes.values()),
            'tensor_values_materialized': False}


def prepare_adapter_copies(experiment, bundles, save_bytes):
    """Precheck every destination before writing any immutable adapter copy."""
    targets = []
    for policy, files in bundles.items():
        folder = experiment / 'prepared_adapters' / policy
        require(not folder.is_symlink(), 'Adapter destination is a symlink')
        if folder.exists():
            require({p.name for p in folder.iterdir()} <= set(ADAPTER_FILES),
                    'Unexpected prepared adapter file; preserved')
        for name, payload in files.items():
            require(name in ADAPTER_FILES, 'Unapproved adapter filename')
            target = folder / name
            require(not target.is_symlink(), 'Prepared adapter file is a symlink')
            require(not target.exists() or target.is_file() and target.read_bytes() == payload,
                    'Prepared adapter differs; preserved: ' + str(target))
            targets.append((target, payload))
    for target, payload in targets:
        save_bytes(target, payload)
    return {policy: {'directory': str(experiment / 'prepared_adapters' / policy),
                     'files_sha256': {name: hashlib.sha256(payload).hexdigest() for name, payload in files.items()}}
            for policy, files in bundles.items()}


def verify_snapshot_metadata(folder, files):
    """Reuse prior weight hashes; freshly verify the small metadata read here."""
    actual = {p.relative_to(folder).as_posix() for p in folder.rglob('*')
              if p.is_file() and '.cache' not in p.relative_to(folder).parts}
    require(actual == set(files), 'Prepared snapshot file coverage changed')
    checked = {}
    for name, record in files.items():
        path = folder / name
        require(path.is_file() and not path.is_symlink() and path.stat().st_size == record['bytes'],
                'Prepared snapshot file missing or size changed: ' + str(path))
        if not name.endswith('.safetensors'):
            require(digest(path) == record['sha256'], 'Snapshot metadata changed: ' + str(path))
            checked[name] = record['sha256']
    return {'metadata_sha256_verified_now': checked,
            'weight_hashes_reused_from_previous_verified_snapshot': True,
            'weight_files_rehashed_this_block': False}


def tokenizer_probe(tokenizer):
    messages = [[{'role': 'user', 'content': text}] for text in
                ['Hello.', 'Write one sentence about the weather today.']]
    rendered = [tokenizer.apply_chat_template(value, tokenize=False, add_generation_prompt=True) for value in messages]
    require(tokenizer.padding_side == 'left' and tokenizer.pad_token_id is not None and
            tokenizer.eos_token_id is not None and tokenizer.is_fast, 'Tokenizer settings differ from course')
    encoded = tokenizer(rendered, return_tensors='pt', padding=True, truncation=True, max_length=256)
    for ids, mask in zip(encoded['input_ids'].tolist(), encoded['attention_mask'].tolist()):
        require(mask == sorted(mask), 'Tokenizer does not left-pad attention')
        require(all(value == tokenizer.pad_token_id for value, keep in zip(ids, mask) if not keep),
                'Tokenizer padding ID differs')
    require(bool(tokenizer.chat_template), 'Tokenizer chat template is unavailable')
    return {'class': type(tokenizer).__name__, 'is_fast': bool(tokenizer.is_fast),
            'vocabulary_size_with_added_tokens': len(tokenizer),
            'padding_side': tokenizer.padding_side, 'truncation_side': tokenizer.truncation_side,
            'pad_token_id': tokenizer.pad_token_id, 'eos_token_id': tokenizer.eos_token_id,
            'chat_template_sha256': json_hash(tokenizer.chat_template),
            'synthetic_renderings_sha256': json_hash(rendered),
            'synthetic_input_ids_sha256': json_hash(encoded['input_ids'].tolist()),
            'synthetic_attention_masks': encoded['attention_mask'].tolist(),
            'model_generation_performed': False}


def main():
    stage1 = EXPERIMENT / 'preflight_releases' / STAGE1
    require(digest(stage1 / 'MANIFEST.json') == STAGE1, 'Preflight source identity differs')
    require(digest(stage1 / 'scripts/preflight.py') == read_json(stage1 / 'MANIFEST.json')['scripts/preflight.py'],
            'Preflight helper differs')
    preflight = load_module('task4_input_preflight', stage1 / 'scripts/preflight.py')
    preflight.verify_source(stage1)
    own = preflight.verify_source(ROOT)
    preflight.require_cpu()
    download_source = EXPERIMENT / 'judge_download_releases' / DOWNLOAD
    require(digest(download_source / 'MANIFEST.json') == DOWNLOAD, 'Judge preparation source differs')
    preflight.verify_source(download_source)
    download = load_module('task4_verified_judge_preparation', download_source / 'download.py')
    save, save_bytes = preflight.immutable_json, preflight.immutable_bytes
    require(read_json(EXPERIMENT / 'OWNER.json')['approval_sha256'] == digest(stage1 / 'docs/approval.json'),
            'Task 4 experiment ownership differs')
    persisted = EXPERIMENT / 'model_inputs_releases' / own['manifest_sha256']
    for name in [*read_json(ROOT / 'MANIFEST.json'), 'MANIFEST.json']:
        save_bytes(persisted / name, (ROOT / name).read_bytes())
    attempt_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    attempt = EXPERIMENT / 'model_inputs_attempts' / attempt_id
    attempt.mkdir(parents=True, exist_ok=False)
    report = {'format': 'ATML_TASK4_CPU_MODEL_INPUT_ATTEMPT_V1', 'status': 'RUNNING',
              'attempt_utc': attempt_id, 'source_manifest_sha256': own['manifest_sha256'],
              'models_instantiated': False, 'tensor_values_materialized': False,
              'model_downloads_performed': False, 'package_changes_performed': False,
              'generation_performed': False, 'judging_performed': False, 'training_performed': False}
    try:
        save(attempt / 'START.json', report)
        download_folder = EXPERIMENT / 'judge_download_attempts' / DOWNLOAD_ATTEMPT
        previous = read_json(download_folder / 'REPORT.json')
        require(previous['status'] == 'JUDGE_FILES_VERIFIED_NO_INFERENCE' and
                previous['source_manifest_sha256'] == DOWNLOAD and previous['verified_file_count'] == 9 and
                previous['verified_bytes'] == 6183451098, 'Judge download result differs')
        for name, expected in previous['artifact_sha256'].items():
            require(digest(download.root_file(download_folder, name)) == expected, 'Judge preparation artifact changed')
        for filename, key in [('JUDGE_SNAPSHOT_CONTRACT.json', 'judge_snapshot_contract_sha256'),
                              ('JUDGE_REVISION_CONTRACT.json', 'judge_revision_contract_sha256'),
                              ('BASE_MODEL_REFERENCE.json', 'base_model_reference_sha256'),
                              ('CPU_ENVIRONMENT_CONTRACT.json', 'environment_contract_sha256')]:
            require(digest(EXPERIMENT / filename) == previous[key], 'Preparation contract changed: ' + filename)
        approval = read_json(EXPERIMENT / 'JUDGE_DOWNLOAD_APPROVAL.json')
        download.validate_approval(approval)
        require(digest(EXPERIMENT / 'JUDGE_DOWNLOAD_APPROVAL.json') == previous['approval_sha256'] ==
                digest(download_source / 'APPROVAL.json'), 'Judge download approval changed')
        env = read_json(EXPERIMENT / 'CPU_ENVIRONMENT_CONTRACT.json')
        require(env['format'] == 'ATML_TASK4_CPU_ENVIRONMENT_V2' and
                env['required_dependency_chain_passed'] is True and env['required_distributions'] == 64 and
                env['global_dependency_check_passed'] is False, 'CPU environment scope differs')
        require(platform.python_version() == env['python'], 'Python version changed')
        require(len(env['all_required_package_versions']) == 64, 'Required package count differs')
        for name, version in env['all_required_package_versions'].items():
            require(importlib.metadata.version(name) == version, 'Required package changed: ' + name)
        require(digest(EXPERIMENT / 'INPUT_IDENTITY_CONTRACT.json') == env['input_contract_sha256'] and
                digest(EXPERIMENT / 'ENVIRONMENT_RECOVERY_APPROVAL.json') == env['recovery_approval_sha256'],
                'Input or recovery approval identity differs')
        recovery = read_json(EXPERIMENT / 'recovery_attempts' / download.RECOVERY_ATTEMPT / 'REPORT.json')
        require(digest(EXPERIMENT / 'AUDIT_ID_CONTRACT.json') == recovery['audit_id_contract_sha256'],
                'Audit ID contract changed')
        base, judge = read_json(EXPERIMENT / 'BASE_MODEL_REFERENCE.json'), read_json(EXPERIMENT / 'JUDGE_SNAPSHOT_CONTRACT.json')
        require(base['model_id'] == 'Qwen/Qwen2.5-1.5B-Instruct' and
                base['revision'] == '989aa7980e4cf806f80c7fef2b1adb7bc71aa306' and base['all_saved_files_verified'] is True,
                'Base snapshot identity differs')
        require(judge['model_id'] == download.JUDGE and judge['revision'] == download.REVISION and
                judge['all_files_verified'] is True and set(judge['verified_files']) == set(judge['files']),
                'Judge snapshot identity or coverage differs')
        base_path, judge_path = Path(base['directory']), Path(judge['directory'])
        snapshot_checks = {'base': verify_snapshot_metadata(base_path, base['verified_files']),
                           'judge': verify_snapshot_metadata(judge_path, judge['verified_files'])}
        save(attempt / 'SNAPSHOT_METADATA_CHECKS.json', snapshot_checks)
        base_config = read_json(base_path / 'config.json')
        require(base_config['model_type'] == 'qwen2', 'Pinned base architecture differs')
        expected = read_json(stage1 / 'provenance/expected_inputs.json')
        drive = Path('/content/drive/MyDrive')
        bundles, sources, adapter_info = {}, {}, {}
        for policy in ['dpo', 'ppo', 'grpo']:
            source_path = drive / expected[policy]['drive_relative_path']
            print('Verifying frozen standard adapter:', policy, flush=True)
            if policy == 'dpo':
                sources[policy] = preflight.verify_dpo(source_path, expected[policy])
                blobs = {name: (source_path / name).read_bytes() for name in ADAPTER_FILES}
            else:
                sources[policy] = preflight.verify_final_archive(source_path, expected[policy], policy.upper())
                with zipfile.ZipFile(source_path) as archive:
                    blobs = {name: archive.read('policy/' + name) for name in ADAPTER_FILES}
            adapter = json.loads(blobs['adapter_config.json'])
            header = inspect_lora_header(blobs['adapter_model.safetensors'], adapter, base_config)
            adapter_info[policy] = {'saved_adapter_config_unchanged': adapter, 'header': header}
            bundles[policy] = blobs
            save(attempt / (policy.upper() + '_SOURCE_AND_HEADER.json'),
                 {'source': sources[policy], **adapter_info[policy]})
            print(policy.upper(), 'adapter header verified:', header['tensor_count'], 'tensors.', flush=True)
        prepared = prepare_adapter_copies(EXPERIMENT, bundles, save_bytes)
        for policy, entry in prepared.items():
            entry.update(adapter_info[policy])
        save(attempt / 'PREPARED_ADAPTERS.json', prepared)
        print('Frozen adapters prepared: 3/3. SFT adapter: None.', flush=True)
        # Operational offline mode affects network access only. Course tokenizer
        # helpers receive verified absolute snapshot paths and are unchanged.
        os.environ['HF_HUB_OFFLINE'] = '1'
        os.environ['TRANSFORMERS_OFFLINE'] = '1'
        course = stage1 / 'course_reference'
        sys.path.insert(0, str(course))
        from common.data import load_yaml
        from common.models import load_tokenizer
        from task4_safety.make_audit_sheet import fixed_audit_ids
        from transformers import GenerationConfig
        import pandas as pd
        cfg = load_yaml(course / 'configs/feedback.yaml')
        require(cfg['seed'] == 6304 and cfg['base_model'] == base['model_id'] and
                cfg['ai_judge_model'] == judge['model_id'] and cfg['dtype'] == 'float16' and
                cfg['quantize_frozen_models'] is True and cfg['safety_max_new_tokens'] == 256 and
                cfg['judge_max_new_tokens'] == 64 and cfg['manual_audit_per_class'] == 30,
                'Course Task 4 settings differ')
        tokenizers, metadata = {}, {}
        for role, folder in [('policy', base_path), ('judge', judge_path)]:
            print('Loading saved tokenizer and generation metadata only:', role, flush=True)
            tokenizer = load_tokenizer(str(folder), padding_side='left')
            probe = tokenizer_probe(tokenizer)
            defaults = GenerationConfig.from_pretrained(str(folder), local_files_only=True).to_dict()
            require(defaults['num_return_sequences'] == 1, 'Inherited generation returns multiple sequences')
            call = {'max_new_tokens': 256 if role == 'policy' else 64, 'do_sample': False,
                    'pad_token_id': tokenizer.pad_token_id if role == 'policy' else tokenizer.eos_token_id,
                    'eos_token_id': tokenizer.eos_token_id}
            metadata[role] = {'tokenizer': probe, 'generation_config_file': read_json(folder / 'generation_config.json'),
                              'generation_defaults_from_pinned_transformers': defaults,
                              'fixed_course_generate_kwargs': call,
                              'effective_generation_config_preview': {**defaults, **call},
                              'preview_requires_confirmation_against_loaded_gpu_model': True}
            tokenizers[role] = tokenizer
            save(attempt / (role.upper() + '_TOKENIZER_AND_GENERATION_METADATA.json'), metadata[role])
        data = preflight.verify_csv(drive / expected['xstest']['drive_relative_path'], expected['xstest']['sha256'])
        inputs = read_json(EXPERIMENT / 'INPUT_IDENTITY_CONTRACT.json')['inputs']['xstest']
        require(data['ordered_prompt_ids'] == inputs['ordered_prompt_ids'] and
                data['class_counts'] == {'SAFE': 250, 'UNSAFE': 200} and data['prompts'] == 450,
                'Fixed XSTest coverage/order differs')
        frame = pd.read_csv(data['path'])
        audit = read_json(EXPERIMENT / 'AUDIT_ID_CONTRACT.json')
        require(fixed_audit_ids(frame.to_dict('records'), 30, 6304) == audit['ordered_audit_prompt_ids'],
                'Fixed audit IDs changed')
        tokenizer = tokenizers['policy']
        rendered = [tokenizer.apply_chat_template([{'role': 'user', 'content': str(value)}],
                    tokenize=False, add_generation_prompt=True) for value in frame['prompt'].tolist()]
        full_ids = tokenizer(rendered, padding=False, truncation=False)['input_ids']
        batches = []
        for start in range(0, len(rendered), 4):
            encoded = tokenizer(rendered[start:start + 4], return_tensors='pt', padding=True,
                                truncation=True, max_length=256)
            batches.append({'batch_index': start // 4,
                'ordered_prompt_ids': data['ordered_prompt_ids'][start:start + 4],
                'input_ids_sha256': json_hash(encoded['input_ids'].tolist()),
                'attention_mask_sha256': json_hash(encoded['attention_mask'].tolist()),
                'prompt_width': int(encoded['input_ids'].shape[1])})
        encoding = {'prompts': 450, 'generation_batches_per_policy': len(batches),
            'batch_size': 4, 'max_prompt_length': 256, 'padding_side': tokenizer.padding_side,
            'truncation_side': tokenizer.truncation_side, 'ordered_prompt_ids': data['ordered_prompt_ids'],
            'rendered_prompts_sha256': json_hash(rendered),
            'untruncated_prompt_lengths': [len(row) for row in full_ids],
            'prompts_exceeding_fixed_cap': sum(len(row) > 256 for row in full_ids),
            'batch_encoding_checksums': batches, 'responses_generated': 0}
        require(len(batches) == 113, 'Fixed generation batch coverage differs')
        save(attempt / 'POLICY_PROMPT_ENCODING_CHECKS.json', encoding)
        contract = {'format': 'ATML_TASK4_CPU_MODEL_INPUTS_V1', 'source_manifest_sha256': own['manifest_sha256'],
            'judge_download_report_sha256': digest(download_folder / 'REPORT.json'),
            'environment_contract_sha256': digest(EXPERIMENT / 'CPU_ENVIRONMENT_CONTRACT.json'),
            'input_contract_sha256': digest(EXPERIMENT / 'INPUT_IDENTITY_CONTRACT.json'),
            'audit_id_contract_sha256': digest(EXPERIMENT / 'AUDIT_ID_CONTRACT.json'),
            'base_model_reference_sha256': digest(EXPERIMENT / 'BASE_MODEL_REFERENCE.json'),
            'judge_snapshot_contract_sha256': digest(EXPERIMENT / 'JUDGE_SNAPSHOT_CONTRACT.json'),
            'policy_order': ['sft', 'dpo', 'ppo', 'grpo'], 'sft_adapter': None,
            'prepared_adapters': prepared, 'tokenizer_and_generation_metadata': metadata,
            'prompt_encoding_checks': encoding, 'course_configuration': cfg,
            'models_instantiated': False, 'tensor_values_materialized': False,
            'cpu_orchestration_validation_pending': True, 'gpu_inference_validation_pending': True}
        save(EXPERIMENT / 'CPU_MODEL_INPUT_CONTRACT.json', contract)
        report.update({'status': 'CPU_ADAPTERS_TOKENIZERS_READY', 'prepared_adapters': 3,
            'tokenizers_checked': 2, 'prompts_tokenized': 450, 'generation_batches_checked': 113,
            'prompts_exceeding_fixed_cap': encoding['prompts_exceeding_fixed_cap'],
            'cpu_model_input_contract_sha256': digest(EXPERIMENT / 'CPU_MODEL_INPUT_CONTRACT.json')})
        print('Saved tokenizers verified: 2/2; prompt encodings checked: 450/450 in 113 batches.', flush=True)
        print('Prompts exceeding unchanged 256-token cap:', encoding['prompts_exceeding_fixed_cap'], flush=True)
        print('Course generation defaults recorded; no decoding settings changed.', flush=True)
        print('Remaining: generation 1800; judging 1800; human labels 240.', flush=True)
        print('CPU orchestration checks and GPU model validation remain pending. Stay on CPU.', flush=True)
    except BaseException as error:
        report['status'] = 'CPU_MODEL_INPUT_PREPARATION_FAILED_PRESERVED'
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        report['artifact_sha256'] = {p.name: digest(p) for p in attempt.iterdir() if p.is_file()}
        save(attempt / 'REPORT.json', report)
        print('Saved CPU model-input report:', attempt / 'REPORT.json', flush=True)
        print('Status:', report['status'], flush=True)


if __name__ == '__main__':
    main()
