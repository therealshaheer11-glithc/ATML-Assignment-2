"""Narrow repair of notebook-only plotting configuration inherited by a child."""
from pathlib import Path, PurePosixPath

NOTEBOOK_BACKEND = 'module://matplotlib_inline.backend_inline'


def require(value, message):
    if not value:
        raise RuntimeError(message)


def child_environment(original, existing_cleaner):
    require(original.get('MPLBACKEND') in {None, '', NOTEBOOK_BACKEND},
            'Unexpected plotting backend requires review; it will not be silently replaced')
    result = existing_cleaner(original)
    result.pop('MPLBACKEND', None)
    return result


def safe_artifact(folder, relative):
    path = PurePosixPath(relative)
    require(isinstance(relative, str) and relative not in {'', '.', '..'} and
            not path.is_absolute() and '..' not in path.parts and '\\' not in relative,
            'Unsafe saved artifact path')
    target = Path(folder) / relative
    require(target.is_file() and not target.is_symlink() and
            target.resolve().is_relative_to(Path(folder).resolve()), 'Saved artifact escapes its attempt')
    return target


def validate_failure(report, log, original_source):
    require(report['status'] == 'ISOLATED_A100_PREPARATION_FAILED_PRESERVED' and
            report['source_manifest_sha256'] == original_source and
            report['error']['message'] == 'preserved_fresh_a100_probe failed; no fallback or automatic repair is applied',
            'Saved failure differs from returned evidence')
    require('ValueError: Key backend:' in log and NOTEBOOK_BACKEND in log and
            "rcParams['backend'] = os.environ.get('MPLBACKEND')" in log,
            'Saved traceback is not the verified inherited plotting-backend failure')
    require(report['gpu_exceptions_accepted'] == [] and report['pretrained_models_loaded'] == 0 and
            report['base_package_changes_performed'] is False, 'Unexpected action in prior attempt')
