"""Revalidate the existing isolated A100 environment; no installation/mutation."""
from datetime import datetime, timezone
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

from packaging.utils import canonicalize_name

from isolation import child_environment, require, safe_artifact, validate_failure

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
EXPERIMENT = Path('/content/drive/MyDrive/ATML-Assignment-2/task4/experiment_v1')
LOCAL = Path('/content/task4_isolated_runtime_v1')
STAGE1 = '9a121f29750b5b09c5feafeb491630ba4b88b6c91dc2ed5ee94ebdb989793b65'
INSTALL = '7a5673003062448f66a3c43763340483968234f42d2659d517c47d7e33de6e8a'
INSTALL_ATTEMPT = '20261011T153611.551337Z'
WHEELS = 'df469ec50f8fc5e493f2f818eb490858c713eb88e3216309aeb43e5fb49a7aab'
WHEEL_ATTEMPT = '20261011T151647.989109Z'
GPU = 'd941ecb6c16ec91a942b319167826007f5124b0dedc10d2a337b3b783ff4015b'
ORCHESTRATION = '35ca690761d2bfda0992ff37855b16fc72c03ffd4b47afaa81edc533ab7a5f65'
DIAGNOSTIC = '71bdb7fdbe130c5adaef8328437371bcd89621d0a93e849bab61b7db8491c540'


def read(path):
    return json.loads(Path(path).read_text())


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def inventory():
    return {canonicalize_name(item.metadata['Name']): item.version for item in metadata.distributions()
            if item.metadata.get('Name')}


def main():
    first = EXPERIMENT / 'preflight_releases' / STAGE1
    require(hashlib.sha256((first / 'MANIFEST.json').read_bytes()).hexdigest() == STAGE1,
            'Original source identity differs')
    require(hashlib.sha256((first / 'scripts/preflight.py').read_bytes()).hexdigest() ==
            read(first / 'MANIFEST.json')['scripts/preflight.py'], 'Original helper differs')
    preflight = load('task4_recheck_preflight', first / 'scripts/preflight.py')
    digest, save, save_bytes = preflight.sha256, preflight.immutable_json, preflight.immutable_bytes
    preflight.verify_source(first)
    own = preflight.verify_source(ROOT)
    require(read(EXPERIMENT / 'OWNER.json')['approval_sha256'] == digest(first / 'docs/approval.json'),
            'Task ownership differs')
    approval = read(ROOT / 'APPROVAL.json')
    require(approval['approved'] is True and approval['user_message'] == 'approved' and
            'isolated A100 environment preserving all 84 reviewed pins' in approval['approved_scope'] and
            approval['approved_proposal_sha256'] == digest(ROOT / 'APPROVED_PROPOSAL.md') and
            approval['approved_isolated_versions_sha256'] == digest(ROOT / 'APPROVED_ISOLATED_VERSIONS.json') and
            approval['gpu_exceptions_authorized'] is False, 'Inherited isolation approval differs')
    identity = own['manifest_sha256']
    release = EXPERIMENT / 'isolated_recheck_releases' / identity
    for name in [*read(ROOT / 'MANIFEST.json'), 'MANIFEST.json']:
        save_bytes(release / name, (ROOT / name).read_bytes())
    attempt_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    attempt = EXPERIMENT / 'isolated_recheck_attempts' / attempt_id
    attempt.mkdir(parents=True, exist_ok=False)
    report = {'format': 'ATML_TASK4_ISOLATED_RECHECK_ATTEMPT_V1', 'status': 'RUNNING',
              'attempt_utc': attempt_id, 'source_manifest_sha256': identity,
              'approval_sha256': digest(ROOT / 'APPROVAL.json'), 'commands': [],
              'package_installation_or_removal_performed': False, 'virtual_environment_created': False,
              'downloads_performed': False, 'base_package_changes_performed': False,
              'pretrained_models_loaded': 0, 'task4_responses_generated': 0,
              'task4_judgments_produced': 0, 'human_labels_assigned': 0,
              'training_performed': False, 'gpu_exceptions_accepted': []}
    environment = None

    def command(argv, name):
        event = {'stage': name, 'argv': [str(value) for value in argv],
                 'child_environment_policy': 'Original sanitizer plus removal of recognized notebook-only MPLBACKEND; parent unchanged; no fixed replacement backend.'}
        save(attempt / (name + '_command.json'), event)
        print('Isolated A100 recheck:', name, flush=True)
        with (attempt / (name + '.log')).open('x') as log:
            process = subprocess.Popen(event['argv'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                       text=True, bufsize=1, env=environment, cwd='/content')
            for line in process.stdout:
                log.write(line); log.flush()
                print(line, end='', flush=True)
            event['returncode'] = process.wait()
        event['log_sha256'] = digest(attempt / (name + '.log'))
        save(attempt / (name + '_result.json'), event)
        report['commands'].append(event)
        require(event['returncode'] == 0, name + ' failed; no additional workaround is applied')

    try:
        save(attempt / 'START.json', report)
        folders = {}
        for kind, source in [('isolated_gpu', INSTALL), ('wheel_cache', WHEELS),
                             ('gpu_environment', GPU), ('orchestration', ORCHESTRATION), ('diagnostic', DIAGNOSTIC)]:
            folder = EXPERIMENT / (kind + '_releases') / source
            require(digest(folder / 'MANIFEST.json') == source, 'Referenced source differs: ' + kind)
            preflight.verify_source(folder)
            folders[kind] = folder
        original_guards = load('task4_original_isolation_guards', folders['isolated_gpu'] / 'guards.py')
        gates = load('task4_original_gpu_gates', folders['gpu_environment'] / 'gates.py')
        require(digest(folders['isolated_gpu'] / 'APPROVAL.json') == report['approval_sha256'],
                'Original and inherited setup approvals differ')
        failed_folder = EXPERIMENT / 'isolated_gpu_attempts' / INSTALL_ATTEMPT
        failed = read(failed_folder / 'REPORT.json')
        for name, expected in failed['artifact_sha256'].items():
            require(digest(safe_artifact(failed_folder, name)) == expected, 'Saved installation artifact differs: ' + name)
        validate_failure(failed, (failed_folder / 'preserved_fresh_a100_probe.log').read_text(), INSTALL)
        for name in ['bootstrap_approved_pip', 'install_exact_offline_pins',
                     'inspect_isolation_after', 'isolated_full_dependency_check']:
            require(read(failed_folder / (name + '_result.json'))['returncode'] == 0,
                    'Prior installation did not complete: ' + name)
        require((failed_folder / 'isolated_full_dependency_check.log').read_text().strip() ==
                'No broken requirements found.', 'Prior full dependency result differs')
        report['original_failed_report_sha256'] = digest(failed_folder / 'REPORT.json')
        pins = read(ROOT / 'APPROVED_ISOLATED_VERSIONS.json')
        require(len(pins) == 84, 'Approved distribution count differs')
        installed_before = read(failed_folder / 'ISOLATED_INVENTORY_AFTER.json')
        original_guards.validate_inventory(installed_before, pins, LOCAL, complete=True)
        before = inventory()
        require(before == read(failed_folder / 'BASE_PACKAGE_VERSIONS_BEFORE.json'),
                'Colab base inventory has changed since the installation attempt')
        save(attempt / 'BASE_PACKAGE_VERSIONS_BEFORE.json', before)
        parent_backend = os.environ.get('MPLBACKEND')
        environment = child_environment(os.environ, original_guards.clean_environment)
        policy = {'format': 'ATML_TASK4_ISOLATED_CHILD_ENVIRONMENT_POLICY_V1',
                  'source_manifest_sha256': identity, 'original_sanitizer_source_manifest_sha256': INSTALL,
                  'additional_variable_removed_only_from_child': 'MPLBACKEND',
                  'recognized_removed_value': 'module://matplotlib_inline.backend_inline',
                  'absent_or_empty_value_allowed': True, 'unexpected_nonempty_value_requires_review': True,
                  'replacement_backend_forced': False, 'parent_environment_modified': False}
        save(attempt / 'CHILD_ENVIRONMENT_POLICY.json', policy)
        save(attempt / 'OBSERVED_BACKEND_INHERITANCE.json', {'parent_mplbackend': parent_backend,
             'isolated_child_mplbackend': environment.get('MPLBACKEND'), 'parent_unchanged': True})
        require(LOCAL.is_dir() and not LOCAL.is_symlink(),
                'The installed local environment is missing. Keep the original A100 runtime; no automatic reinstall occurs.')
        owner = read(LOCAL / '.task4_isolation_owner.json')
        wheelhouse_contract = EXPERIMENT / 'environment_wheelhouse/VERIFIED_WHEELHOUSE_CONTRACT.json'
        require(owner['source_manifest_sha256'] == INSTALL and owner['approval_sha256'] == report['approval_sha256'] and
                owner['wheelhouse_contract_sha256'] == digest(wheelhouse_contract) and
                owner['directory'] == str(LOCAL) and owner['system_site_packages'] is False,
                'Local environment owner differs')
        cached = read(wheelhouse_contract)
        require(cached['isolated_package_versions'] == pins and cached['all_wheels_verified'] is True and
                cached['source_manifest_sha256'] == WHEELS, 'Frozen wheelhouse contract differs')
        wheel_folder = EXPERIMENT / 'wheel_cache_attempts' / WHEEL_ATTEMPT
        wheel_report = read(wheel_folder / 'REPORT.json')
        require(wheel_report['status'] == 'CPU_WHEEL_CACHE_VERIFIED_NO_INSTALLATION' and
                wheel_report['source_manifest_sha256'] == WHEELS and
                wheel_report['verified_wheelhouse_contract_sha256'] == digest(wheelhouse_contract),
                'Frozen successful wheel-cache report differs')
        for name, expected in wheel_report['artifact_sha256'].items():
            require(digest(safe_artifact(wheel_folder, name)) == expected, 'Saved wheel-cache evidence differs')
        plan = read(wheel_folder / 'APPROVED_ISOLATION_PROPOSAL.json')
        protocol = EXPERIMENT / 'CPU_ORCHESTRATION_VALIDATION_CONTRACT.json'
        require(digest(protocol) == plan['cpu_orchestration_contract_sha256'], 'Frozen evaluation protocol differs')
        cpu = read(protocol)
        require(cpu['tests_passed'] == 37 and cpu['source_manifest_sha256'] == ORCHESTRATION and
                digest(EXPERIMENT / 'CPU_MODEL_INPUT_CONTRACT.json') == cpu['model_input_contract_sha256'],
                'Frozen model input/synthetic validation contract differs')
        command(['nvidia-smi', '--query-gpu=name,memory.total,driver_version,uuid',
                 '--format=csv,noheader,nounits'], 'nvidia_inventory')
        hardware = gates.parse_a100_inventory((attempt / 'nvidia_inventory.log').read_text())
        require(hardware == read(failed_folder / 'A100_HARDWARE.json'),
                'A100 hardware/runtime differs from the installed environment attempt')
        save(attempt / 'A100_HARDWARE.json', hardware)
        python = LOCAL / 'bin/python'
        command([python, '-I', '-B', folders['isolated_gpu'] / 'inspect_python.py',
                 attempt / 'ISOLATED_INVENTORY_BEFORE.json'], 'inspect_isolated_before')
        current_inventory = read(attempt / 'ISOLATED_INVENTORY_BEFORE.json')
        original_guards.validate_inventory(current_inventory, pins, LOCAL, complete=True)
        require(current_inventory['python'] == installed_before['python'] == owner['target_python_full_version'],
                'Installed Python identity changed')
        command([python, '-I', '-B', '-m', 'pip', '--disable-pip-version-check', 'check'],
                'isolated_full_dependency_check')
        probe_directory = attempt / 'fresh_probe'
        probe_directory.mkdir()
        command([python, '-I', '-B', '-u', folders['gpu_environment'] / 'probe_gpu.py',
                 first, folders['orchestration'], folders['diagnostic'], probe_directory],
                'preserved_fresh_a100_probe')
        probe = read(probe_directory / 'GPU_PROBE.json')
        expected_course = {name: version for name, version in pins.items() if name != 'pip'}
        require(probe['all_required_package_versions'] == expected_course and probe['required_distributions'] == 83 and
                probe['synthetic_semantic_checks_passed'] == 37 and probe['required_dependency_chain_passed'] and
                probe['fresh_process_imports_passed'] and probe['tiny_float16_cuda_check_passed'] and
                probe['tiny_nf4_cuda_backend_check_passed'] and probe['pretrained_model_weights_loaded'] is False,
                'Complete isolated A100 validation did not pass')
        command([python, '-I', '-B', folders['isolated_gpu'] / 'inspect_python.py',
                 attempt / 'ISOLATED_INVENTORY_AFTER.json'], 'inspect_isolated_after')
        final_inventory = read(attempt / 'ISOLATED_INVENTORY_AFTER.json')
        original_guards.validate_inventory(final_inventory, pins, LOCAL, complete=True)
        require(final_inventory['package_versions'] == current_inventory['package_versions'],
                'Installed package inventory changed during validation')
        after = inventory()
        save(attempt / 'BASE_PACKAGE_VERSIONS_AFTER.json', after)
        require(before == after and os.environ.get('MPLBACKEND') == parent_backend,
                'Base package versions or parent plotting setting changed unexpectedly')
        contract = {'format': 'ATML_TASK4_ISOLATED_A100_ENVIRONMENT_V1',
            'source_manifest_sha256': identity, 'installation_source_manifest_sha256': INSTALL,
            'approval_sha256': report['approval_sha256'], 'wheelhouse_contract_sha256': digest(wheelhouse_contract),
            'environment_directory': str(LOCAL), 'python_executable': str(python), 'python': final_inventory['python'],
            'isolated_package_versions': pins, 'all_required_package_versions': expected_course,
            'required_distributions': 83, 'isolated_distributions': 84,
            'cpu_orchestration_contract_sha256': digest(protocol),
            'model_input_contract_sha256': digest(EXPERIMENT / 'CPU_MODEL_INPUT_CONTRACT.json'),
            'course_requirements_sha256': digest(first / 'course_reference/requirements.txt'),
            'isolated_child_environment_policy': policy,
            'system_site_packages': False, 'user_site_enabled': False,
            'isolated_full_dependency_check_passed': True, 'required_dependency_chain_passed': True,
            'fresh_process_imports_passed': True, 'tiny_float16_cuda_check_passed': True,
            'tiny_nf4_cuda_backend_check_passed': True, 'torch_cuda_version': probe['torch_cuda_version'],
            'synthetic_semantic_checks_passed': 37, 'hardware_requirement': 'A100, compute capability 8.0',
            'base_package_inventory_unchanged_by_this_block': True,
            'colab_base_repair_and_full_validation_pending': True,
            'gpu_exceptions_accepted': [], 'pretrained_model_weights_loaded': False,
            'gpu_model_loading_validation_pending': True}
        save(EXPERIMENT / 'ISOLATED_CHILD_ENVIRONMENT_CONTRACT.json', policy)
        save(EXPERIMENT / 'ISOLATED_GPU_ENVIRONMENT_CONTRACT.json', contract)
        report.update({'status': 'ISOLATED_A100_ENVIRONMENT_VALIDATED_BASE_REPAIR_PENDING',
            'isolated_distribution_count': 84, 'required_distribution_count': 83,
            'isolated_full_dependency_check_passed': True, 'synthetic_checks_passed': 37,
            'fresh_imports_cuda_and_nf4_passed': True, 'base_package_inventory_unchanged': True,
            'parent_mplbackend_unchanged': True, 'isolated_package_inventory_unchanged': True,
            'isolated_environment_contract_sha256': digest(EXPERIMENT / 'ISOLATED_GPU_ENVIRONMENT_CONTRACT.json'),
            'isolated_child_environment_contract_sha256': digest(EXPERIMENT / 'ISOLATED_CHILD_ENVIRONMENT_CONTRACT.json'),
            'colab_base_repair_pending': True})
        print('Reused existing 84/84 exact distributions; full isolated dependency check PASS.', flush=True)
        print('Fresh course imports/CUDA/NF4 PASS; synthetic checks 37/37 PASS.', flush=True)
        print('No installation/download/removal. Parent notebook backend and base packages unchanged.', flush=True)
        print('Colab base repair pending. Keep this A100 runtime connected and return the output.', flush=True)
        print('Evaluation progress: responses 0/1800; judgments 0/1800; human labels 0/240.', flush=True)
    except BaseException as error:
        report.update({'status': 'ISOLATED_A100_RECHECK_FAILED_PRESERVED',
                       'error': {'type': type(error).__name__, 'message': str(error)}})
        raise
    finally:
        report['artifact_sha256'] = {p.relative_to(attempt).as_posix(): digest(p)
                                    for p in attempt.rglob('*') if p.is_file()}
        save(attempt / 'REPORT.json', report)
        print('Saved isolated A100 recheck report:', attempt / 'REPORT.json', flush=True)
        print('Status:', report['status'], flush=True)


if __name__ == '__main__':
    main()
