"""Meaningful guards for the observed environment inheritance regression."""
import importlib.util
from pathlib import Path
import tempfile
import unittest

from isolation import NOTEBOOK_BACKEND, child_environment, safe_artifact, validate_failure

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('fixture_original_guards', ROOT.parent / 'isolated_gpu_v1/guards.py')
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)


class RecheckGuards(unittest.TestCase):
    def test_known_notebook_backend_removed_only_from_child(self):
        parent = {'MPLBACKEND': NOTEBOOK_BACKEND, 'LD_LIBRARY_PATH': '/driver', 'HOME': '/example'}
        child = child_environment(parent, original.clean_environment)
        self.assertNotIn('MPLBACKEND', child)
        self.assertEqual(parent['MPLBACKEND'], NOTEBOOK_BACKEND)
        self.assertEqual(child['LD_LIBRARY_PATH'], '/driver')
        self.assertEqual(child['HOME'], '/example')

    def test_no_replacement_backend_introduced(self):
        for parent in [{}, {'MPLBACKEND': ''}]:
            child = child_environment(parent, original.clean_environment)
            self.assertNotIn('MPLBACKEND', child)

    def test_unexpected_backend_stops_for_review(self):
        for value in ['agg', 'qtagg', 'module://unexpected.module']:
            with self.assertRaises(RuntimeError):
                child_environment({'MPLBACKEND': value}, original.clean_environment)

    def test_existing_python_and_pip_isolation_guards_preserved(self):
        child = child_environment({'MPLBACKEND': NOTEBOOK_BACKEND, 'PYTHONPATH': '/base',
                                   'PIP_TARGET': '/base', 'VIRTUAL_ENV': '/other'}, original.clean_environment)
        for key in ['MPLBACKEND', 'PYTHONPATH', 'PIP_TARGET', 'VIRTUAL_ENV']:
            self.assertNotIn(key, child)
        self.assertEqual(child['HF_HUB_OFFLINE'], '1')
        self.assertEqual(child['PYTHONNOUSERSITE'], '1')

    def test_safe_nested_artifact_allowed_and_escape_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            (folder / 'fresh_probe').mkdir()
            target = folder / 'fresh_probe/graph.json'; target.write_text('{}')
            self.assertEqual(safe_artifact(folder, 'fresh_probe/graph.json'), target)
            for name in ['../escape', '/absolute', 'fresh_probe/../../escape', 'bad\\path', '.', 'missing']:
                with self.subTest(name=name), self.assertRaises(RuntimeError):
                    safe_artifact(folder, name)
            (folder / 'linked').symlink_to(target)
            with self.assertRaises(RuntimeError):
                safe_artifact(folder, 'linked')

    def failure(self):
        return {'status': 'ISOLATED_A100_PREPARATION_FAILED_PRESERVED', 'source_manifest_sha256': 'source',
                'error': {'message': 'preserved_fresh_a100_probe failed; no fallback or automatic repair is applied'},
                'gpu_exceptions_accepted': [], 'pretrained_models_loaded': 0, 'base_package_changes_performed': False}

    def test_only_observed_matplotlib_failure_is_accepted(self):
        log = "rcParams['backend'] = os.environ.get('MPLBACKEND')\nValueError: Key backend: " + NOTEBOOK_BACKEND
        validate_failure(self.failure(), log, 'source')
        for changed in [{**self.failure(), 'status': 'OTHER'},
                        {**self.failure(), 'source_manifest_sha256': 'other'},
                        {**self.failure(), 'gpu_exceptions_accepted': ['anything']}]:
            with self.assertRaises(RuntimeError):
                validate_failure(changed, log, 'source')
        with self.assertRaises(RuntimeError):
            validate_failure(self.failure(), 'Different error', 'source')


if __name__ == '__main__':
    unittest.main(verbosity=2)
