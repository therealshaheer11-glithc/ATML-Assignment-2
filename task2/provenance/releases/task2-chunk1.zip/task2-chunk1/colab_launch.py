# Run this as one cell in a fresh Colab GPU notebook, then select task2-chunk1.zip.
from google.colab import files
from pathlib import Path
import io
import subprocess
import sys
import tempfile
import zipfile

uploaded = files.upload()
if len(uploaded) != 1:
    raise RuntimeError("Select exactly one file: task2-chunk1.zip")

destination = Path(tempfile.mkdtemp(prefix="task2_chunk1_", dir="/content")).resolve()
with zipfile.ZipFile(io.BytesIO(next(iter(uploaded.values())))) as archive:
    for item in archive.infolist():
        if not (destination / item.filename).resolve().is_relative_to(destination):
            raise RuntimeError("Archive contains an unexpected path.")
    archive.extractall(destination)

installer = destination / "task2-chunk1" / "setup_chunk1.py"
if not installer.is_file():
    raise RuntimeError("This is not the supplied Task 2 Chunk 1 archive.")
subprocess.run(
    [sys.executable, str(installer), "--repo", "/content/ATML-PA2-Task2"],
    check=True,
)
