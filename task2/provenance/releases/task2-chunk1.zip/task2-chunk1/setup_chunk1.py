"""Install and validate approved Task 2 Chunk 1 in an isolated course checkout."""
import argparse
import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4


PACKAGE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run(*command, cwd=None):
    print("Running:", " ".join(map(str, command)), flush=True)
    subprocess.run(list(map(str, command)), cwd=cwd, check=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, default=Path("/content/ATML-PA2-Task2"))
    args = parser.parse_args()
    repo = args.repo.expanduser().resolve()
    approval_path = PACKAGE / "task2_chunk1/approval.json"
    approval = json.loads(approval_path.read_text())
    package_manifest = json.loads((PACKAGE / "PACKAGE_SHA256.json").read_text())
    for relative, expected in package_manifest.items():
        if digest(PACKAGE / relative) != expected:
            raise RuntimeError(f"Chunk 1 package file differs: {relative}")
    # Check before package installation or the large asset download.
    run(sys.executable, "-c", "import torch; print('Torch:', torch.__version__); "
        "assert torch.cuda.is_available(), 'Select a CUDA GPU runtime before running Chunk 1.'; "
        "print('GPU:', torch.cuda.get_device_name(0))")
    fresh = not repo.exists() or not any(repo.iterdir())
    if fresh:
        repo.parent.mkdir(parents=True, exist_ok=True)
        run("git", "clone", "--no-checkout",
            "https://github.com/AbDu11aHHH/ATML-PA2-LLM-PostTraining.git", repo)
        run("git", "-C", repo, "checkout", "--detach", approval["course_commit"])
    elif not (repo / "docs/task2_approval.json").is_file():
        raise RuntimeError("Target folder already exists without this chunk's approval record. Choose a fresh --repo path.")
    head = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
    if head != approval["course_commit"]:
        raise RuntimeError("Existing checkout is at a different commit; it was left unchanged.")
    installs = {
        "task2_chunk1/ppo.py": "task2_ppo/ppo.py",
        "task2_chunk1/preflight.py": "task2_ppo/preflight.py",
        "task2_chunk1/reward_compat.py": "task2_ppo/reward_compat.py",
        "task2_chunk1/test_task2_objective.py": "tests/test_task2_objective.py",
        "task2_chunk1/approval.json": "docs/task2_approval.json",
        "task2_chunk1/approved_plan.md": "docs/task2_approved_plan.md",
    }
    # Validate all destinations before writing any of the approved replacement files.
    for relative, expected in approval["source_sha256"].items():
        if relative in installs.values():
            continue
        if digest(repo / relative) != expected:
            raise RuntimeError(f"Course helper/config was modified: {relative}")
    for source, destination in installs.items():
        target = repo / destination
        if target.exists():
            allowed = {digest(PACKAGE / source)}
            if destination == "task2_ppo/ppo.py":
                allowed.add(approval["original_ppo_sha256"])
            if digest(target) not in allowed:
                raise RuntimeError(f"Existing file has different contents; not overwritten: {destination}")
    run(sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "-r", repo / "requirements.txt")
    for source, destination in installs.items():
        target = repo / destination
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((PACKAGE / source).read_bytes())
    run(sys.executable, "-m", "scripts.check_environment", cwd=repo)
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + uuid4().hex[:8]
    checks = repo / "results/task2_ppo/setup" / ("checks_" + run_id)
    checks.mkdir(parents=True, exist_ok=False)
    command = [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_task2_objective.py", "-v"]
    result = subprocess.run(command, cwd=repo, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print(result.stdout, flush=True)
    (checks / "objective_tests.log").write_text(result.stdout)
    count = re.search(r"Ran (\d+) tests?", result.stdout)
    report = {"command": command, "return_code": result.returncode,
              "tests_run": int(count.group(1)) if count else None,
              "passed": result.returncode == 0,
              "test_file_sha256": digest(repo / "tests/test_task2_objective.py"),
              "model_weights_loaded": False, "training_executed": False}
    (checks / "objective_tests.json").write_text(json.dumps(report, indent=2) + "\n")
    if not report["passed"] or report["tests_run"] != 21:
        raise RuntimeError("Objective/setup tests did not all pass. Assets were not downloaded; inspect the saved test log.")
    run(sys.executable, "-m", "scripts.download_assets", cwd=repo)
    run(sys.executable, "-m", "scripts.validate_assets", cwd=repo)
    # Only the tiny public RM config is fetched here; no public model weights.
    code = ("from huggingface_hub import hf_hub_download; "
            f"print(hf_hub_download({approval['reward_model']!r}, 'config.json', revision={approval['reward_revision']!r}))")
    reward_config = subprocess.check_output([sys.executable, "-c", code], cwd=repo, text=True).strip().splitlines()[-1]
    run(sys.executable, "-m", "task2_ppo.preflight", "--reward-config", reward_config,
        "--objective-report", checks / "objective_tests.json", cwd=repo)


if __name__ == "__main__":
    main()
