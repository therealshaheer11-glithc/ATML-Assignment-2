# Task 2, Chunk 1: setup and objective validation

The user approved decisions A-K on 8 October 2026. This chunk prepares the fixed course release and validates PPO's objective. It does not run PPO training or load public model weights.

## Run in Colab

1. Open a fresh Colab notebook and select a GPU runtime.
2. Run `colab_launch.py` as a notebook cell (or use the supplied Chunk 1 notebook).
3. Select the downloaded `task2-chunk1.zip` when the upload selector appears.

The installer creates `/content/ATML-PA2-Task2`. It refuses to overwrite an unrelated existing folder. If the same chunk is rerun, installed files must have exactly the expected contents. Task 1's folder is not used.

On another CUDA machine, extract this ZIP and run:

```sh
python setup_chunk1.py --repo /absolute/path/to/a/new/task2-folder
```

## What runs

- Check that PyTorch can access a CUDA GPU.
- Clone the public course starter and check out approved commit `1d64ac65acd5e45d1e4e1f415edc80455e21274e`.
- Install the course requirements. Commands and tests run in separate Python processes, so notebook imports do not retain an older library version.
- Install the corrected `task2_ppo/ppo.py`, the setup checks, the reward compatibility helper, tests, and approval record.
- Run all 21 CPU-sized analytical tests before downloading the large course bundle.
- Run the official pinned course asset download and official schema validation. This downloads the supplied critic/checkpoints; it does not load them for inference or training.
- Verify Task 2 asset hashes against the pinned manifest, validate prompt/cache provenance, check the approved reward configuration translation, and freeze exact training/evaluation prompt and seed schedules.
- Save environment/package versions, source/asset hashes, test logs, reward-translation details, and the resolved configuration under `results/task2_ppo/setup/`.

The official release's manifest has a stale self-hash entry. The preflight verifies the manifest's frozen file bytes and substantive PPO assets; it does not edit the course manifest.

## Expected final output

```text
Ran 21 tests in ...
OK
...
CHUNK 1 COMPLETE: objective tests and setup checks passed.
GPU: ... | VRAM GiB: ...
Results: results/task2_ppo/setup/...
No model weights were loaded and no PPO training was run.
```

If a command fails, stop and retain its output. Do not change seeds, package pins, precision, checkpoints, or clipping settings to work around the failure.

## Local validation limits

The corrected objective and all 21 tests passed in the author's local CPU environment. The unmodified starter fails five of the 17 objective/reference/alignment tests. The actual pinned reward configuration also passed the in-memory translation check.

The local host has no CUDA GPU. Full Colab installation, the large checkpoint download, and GPU setup validation must therefore be confirmed by the user's run. No GPU experiment or result is claimed by this package.

## Attribution

`task2_chunk1/ppo.py` is adapted from the course starter, with its deliberate `maximum` defect changed to `minimum` and an explanatory comment. The remaining objective helpers are preserved. At installation, the course `common/` helpers are retained and their contents checked against the approved commit.

Course source: https://github.com/AbDu11aHHH/ATML-PA2-LLM-PostTraining

Course assets: https://huggingface.co/datasets/AbDu11aHHH/ATML-PA2-assets

The reward compatibility helper adapts the narrow in-memory translation developed for this assignment's Task 1. Setup, preflight, and analytical tests were written with LLM coding assistance and should be reviewed and understood before submission.
