"""Install remaining code, validate on CPU, and save the final GPU-ready snapshot."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from scripts.task2_stage import restore_files
from task2_ppo.storage import atomic_json, sha256


PACKAGE = Path(__file__).resolve().parent


def run_visible(command, cwd=None):
    lines = []
    with subprocess.Popen(list(map(str, command)), cwd=cwd, text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, bufsize=1) as process:
        for line in process.stdout:
            print(line, end="", flush=True)
            lines.append(line)
        code = process.wait()
    return code, "".join(lines)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, default=Path("/content/ATML-PA2-Task2"))
    parser.add_argument("--preparation", required=True, type=Path)
    args = parser.parse_args()
    import torch
    if torch.cuda.is_available():
        raise RuntimeError("Keep GPU off while installing, checking and saving the final code")
    package_hashes = json.loads((PACKAGE / "PACKAGE_SHA256.json").read_text())
    for name, digest in package_hashes.items():
        if sha256(PACKAGE / name) != digest:
            raise RuntimeError(f"Package checksum differs: {name}")
    preparation = json.loads(args.preparation.read_text())
    if preparation["status"] != "CPU_PREPARATION_VERIFIED":
        raise RuntimeError("Expected the completed Chunk 2 CPU preparation receipt")
    restore_files(preparation, args.repo)
    repo = args.repo.resolve()
    expected_chunk2 = json.loads((PACKAGE / "chunk2_expected_files.json").read_text())
    if json.loads((repo / "docs/task2_chunk2_files.json").read_text()) != expected_chunk2:
        raise RuntimeError("Chunk 2 installation record differs from the verified package")
    for name, digest in expected_chunk2.items():
        if sha256(repo / name) != digest:
            raise RuntimeError(f"Installed Chunk 2 file differs: {name}")
    installs = {p.relative_to(PACKAGE).as_posix(): p.relative_to(PACKAGE).as_posix()
                for subdir in ("task2_ppo", "tests", "scripts")
                for p in (PACKAGE / subdir).rglob("*.py")}
    installs.update({"resource_approval.json": "docs/task2_resource_approval.json",
                     "README.md": "docs/task2_chunk3_README.md",
                     "GENERATION_DEFAULTS_CPU.json": "docs/task2_generation_defaults_local_check.json",
                     "CACHE_RECONSTRUCTION_CPU.json": "docs/task2_cache_reconstruction_local_check.json"})
    for source, destination in installs.items():
        target = repo / destination
        if target.exists() and sha256(target) != sha256(PACKAGE / source):
            raise RuntimeError(f"Existing new-code file differs; not overwritten: {destination}")
    code, _ = run_visible([sys.executable, "-m", "pip", "install", "--disable-pip-version-check",
                           "-r", repo / "requirements.txt"])
    if code:
        raise RuntimeError("Package installation failed")
    installed = {}
    for source, destination in installs.items():
        target = repo / destination
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((PACKAGE / source).read_bytes())
        installed[destination] = sha256(target)
    atomic_json(repo / "docs/task2_chunk3_files.json", installed)
    code, log = run_visible([sys.executable, "-m", "unittest", "discover", "-s", "tests",
                             "-p", "test_task2_*.py", "-v"], cwd=repo)
    count = re.search(r"Ran (\d+) tests?", log)
    tests_run = int(count.group(1)) if count else None
    expected_count = json.loads((PACKAGE / "LOCAL_VALIDATION.json").read_text())["tests_run"]
    stage_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + uuid4().hex[:8]
    checks = repo / "results/task2_ppo/setup" / ("chunk3_" + stage_id)
    checks.mkdir(parents=True, exist_ok=False)
    (checks / "tests.log").write_text(log)
    validation = {"passed": code == 0 and tests_run == expected_count, "tests_run": tests_run,
                  "return_code": code, "installed_sha256": installed, "gpu_used": False,
                  "course_weights_loaded": False}
    atomic_json(checks / "validation.json", validation)
    if not validation["passed"]:
        raise RuntimeError("Final code checks did not pass; retain CPU runtime for inspection")
    # Real cache reconstruction with the prepared pinned tokenizer, still no model weights.
    command = [sys.executable, "-m", "scripts.task2_verify_cache_cpu",
               "--policy-folder", Path(preparation["models_drive_dir"]) / "policy"]
    code, _ = run_visible(command, cwd=repo)
    if code:
        raise RuntimeError("Real cache reconstruction failed; no GPU launch was prepared")
    resource = json.loads((repo / "docs/task2_resource_approval.json").read_text())
    if resource["session_minutes"] != 120 or resource["automatic_disconnect"] is not True or not resource["approved"]:
        raise RuntimeError("GPU resource choices differ from the user's explicit approval")
    destination = Path("/content/drive/MyDrive/ATML-Assignment-2/task2/gpu_ready") / stage_id
    destination.mkdir(parents=True, exist_ok=False)
    ready = {**preparation, "status": "GPU_JOBS_READY", "gpu_launch_ready": True,
        "resource_approval": resource, "source_cpu_receipt": str(args.preparation),
        "experiment_root": "/content/drive/MyDrive/ATML-Assignment-2/task2/experiment_v1",
        "new_code_validation": validation, "ready_receipt": str(destination / "ready.json")}
    # Avoid self-referential archive hashes: store the full receipt outside the archive.
    embedded = {k: v for k, v in ready.items() if k != "project_archive"}
    atomic_json(repo / "docs/task2_gpu_preparation.json", embedded)
    excluded = {"data", "cached", "checkpoints", "outputs", ".cache", ".venv", "__pycache__"}
    paths = [p for p in repo.rglob("*") if p.is_file() and p.suffix != ".pyc"
             and not excluded.intersection(p.relative_to(repo).parts)
             and p.name != "TASK2_BACKUP_MANIFEST.json"]
    hashes = {p.relative_to(repo).as_posix(): sha256(p) for p in paths}
    with tempfile.TemporaryDirectory() as temporary:
        local = Path(temporary) / "project.zip"
        with zipfile.ZipFile(local, "w", zipfile.ZIP_DEFLATED, compresslevel=1) as archive:
            for p in sorted(paths):
                if p.is_symlink():
                    raise RuntimeError("Do not persist project symlinks")
                archive.write(p, p.relative_to(repo).as_posix())
            archive.writestr("TASK2_BACKUP_MANIFEST.json", json.dumps({
                "files_sha256": hashes, "training_executed": False, "stage": "All Task 2 code ready"}))
        saved = destination / "project.zip"
        shutil.copyfile(local, saved)
        if sha256(saved) != sha256(local):
            raise RuntimeError("Final project archive copy differs")
        with zipfile.ZipFile(saved) as archive:
            for name, digest in hashes.items():
                if hashlib.sha256(archive.read(name)).hexdigest() != digest:
                    raise RuntimeError(f"Saved final project file differs: {name}")
        ready["project_archive"] = {"path": str(saved), "sha256": sha256(saved), "bytes": saved.stat().st_size}
    atomic_json(destination / "ready.json", ready)
    print("GPU JOBS READY:", destination / "ready.json", flush=True)
    print("Session: 120 minutes; automatic disconnection only after verified backup and Drive flush.", flush=True)
    print("No GPU used and no course model weights loaded during preparation.", flush=True)


if __name__ == "__main__":
    main()
