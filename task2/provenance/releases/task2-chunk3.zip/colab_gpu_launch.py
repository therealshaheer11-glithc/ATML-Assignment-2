from pathlib import Path
from uuid import uuid4
import hashlib
import json
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import zipfile


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(2**20), b''):
            h.update(block)
    return h.hexdigest()


def safe_extract(z, destination):
    destination = Path(destination).resolve()
    names = set()
    for item in z.infolist():
        target = (destination / item.filename).resolve()
        if destination not in target.parents or item.filename in names or (item.external_attr >> 16) & 0o170000 == 0o120000:
            raise RuntimeError('Unsafe or duplicate archive member')
        names.add(item.filename)
    z.extractall(destination)


def run_visible(command, cwd=None):
    process = subprocess.Popen(list(map(str, command)), cwd=cwd, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=1)
    try:
        for line in process.stdout:
            print(line, end='', flush=True)
        code = process.wait()
    except KeyboardInterrupt:
        # The GPU orchestrator stops its child process and saves completed work.
        process.send_signal(signal.SIGINT)
        remaining, _ = process.communicate()
        print(remaining, end='', flush=True)
        code = process.returncode
    except BaseException:
        process.terminate()
        process.wait()
        raise
    if code:
        raise RuntimeError('Process failed; keep the runtime available and inspect the printed error.')


def latest_receipt(pattern, status, override=''):
    choices = [Path(override)] if override else sorted(Path('/content/drive/MyDrive/ATML-Assignment-2/task2').glob(pattern), reverse=True)
    for path in choices:
        record = json.loads(path.read_text())
        if record['status'] == status:
            return path, record
    raise RuntimeError('No completed preparation receipt found. Run the CPU preparation notebook first.')


def restore_project(ready, repo):
    spec = ready['project_archive']
    repo = Path(repo)
    with tempfile.TemporaryDirectory(prefix='task2_bootstrap_') as tmp:
        local = Path(tmp) / 'project.zip'
        shutil.copyfile(spec['path'], local)
        if file_sha(local) != spec['sha256']:
            raise RuntimeError('Saved project archive checksum differs')
        with zipfile.ZipFile(local) as z:
            manifest = json.loads(z.read('TASK2_BACKUP_MANIFEST.json'))['files_sha256']
            expected = set(manifest) | {'TASK2_BACKUP_MANIFEST.json'}
            if set(z.namelist()) != expected or len(z.namelist()) != len(expected):
                raise RuntimeError('Project archive inventory differs')
            for name, digest in manifest.items():
                if hashlib.sha256(z.read(name)).hexdigest() != digest:
                    raise RuntimeError('Project member checksum differs: ' + name)
            extracted = Path(tmp) / 'extracted'
            safe_extract(z, extracted)
        for name, digest in manifest.items():
            target = repo / name
            if target.exists() and file_sha(target) != digest:
                raise RuntimeError('Existing project file differs; use a fresh runtime: ' + name)
        for name in manifest:
            target = repo / name
            if not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(extracted / name, target)

# Optional exact GPU-ready receipt path. Approved session limit: 120 minutes.
READY_RECEIPT = ''
SESSION_START_EPOCH = time.time()
import torch
from google.colab import drive, runtime
if not torch.cuda.is_available():
    raise RuntimeError('Select Runtime > Change runtime type > A100 GPU first.')
print('GPU:', torch.cuda.get_device_name(0), flush=True)
if 'A100' not in torch.cuda.get_device_name(0):
    raise RuntimeError('This prepared launch expects the previously tested A100. Select A100 before using GPU time.')
drive.mount('/content/drive')
ready_path, ready = latest_receipt('gpu_ready/*/ready.json', 'GPU_JOBS_READY', READY_RECEIPT)
print('Using GPU-ready receipt:', ready_path, flush=True)
repo = Path('/content/ATML-PA2-Task2')
restore_project(ready, repo)
finish_path = Path('/content') / ('task2_finish_' + uuid4().hex + '.json')
run_visible([sys.executable, '-u', '-m', 'scripts.task2_gpu_session', '--ready', ready_path,
             '--start-epoch', str(SESSION_START_EPOCH), '--finish-receipt', finish_path], cwd=repo)
finished = json.loads(finish_path.read_text())
if not finished['verified']:
    raise RuntimeError('Session backup not verified. Keep this runtime available for recovery.')
# Both process output and the complete session log have now been persisted.
print('SESSION BACKUP VERIFIED. Status:', finished['status'], flush=True)
if finished['status'] == 'SESSION_LIMIT':
    print('After disconnection, resume the same GPU notebook in a fresh A100 runtime.', flush=True)
elif finished['status'] == 'COMPLETE':
    print('GPU work complete. Next run Task2_Results_CPU.ipynb on CPU.', flush=True)
else:
    print('The job failed. The saved session log contains the error; inspect it before retrying.', flush=True)
sys.path.insert(0, str(repo))
from scripts.task2_finish import disconnect_after_verified
try:
    disconnect_after_verified(finished['resource_approval'], finished['verified'],
                              drive.flush_and_unmount, runtime.unassign)
except Exception as error:
    print('Automatic shutdown did not finish:', repr(error), flush=True)
    print('If Drive flush failed, keep this runtime for recovery. If flushing succeeded and only unassign failed, select Runtime > Disconnect and delete runtime.', flush=True)
    raise
