"""Restore the verified project backup and install Chunk 2 on a CPU runtime."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

from task2_ppo.storage import atomic_json, safe_extract, sha256


PACKAGE = Path(__file__).resolve().parent


def restore_project(backup, repo):
    """The backup is the user's confirmed Chunk 1 archive; verify every member."""
    if repo.exists():
        if not (repo / "docs/task2_approval.json").is_file():
            raise RuntimeError("Existing target is not the approved Task 2 project")
        return
    repo.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=repo.parent) as temporary:
        draft = Path(temporary) / "project"
        draft.mkdir()
        with zipfile.ZipFile(backup) as archive:
            manifest = json.loads(archive.read("TASK2_BACKUP_MANIFEST.json"))
            hashes = manifest["files_sha256"]
            names = archive.namelist()
            if len(names) != len(set(names)) or set(names) != set(hashes) | {"TASK2_BACKUP_MANIFEST.json"}:
                raise RuntimeError("Backup file inventory differs")
            if manifest["training_executed"] is not False:
                raise RuntimeError("Expected the saved pre-training project backup")
            for name, digest in hashes.items():
                if hashlib.sha256(archive.read(name)).hexdigest() != digest:
                    raise RuntimeError(f"Backup checksum differs: {name}")
            safe_extract(archive, draft)
        os.rename(draft, repo)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, default=Path("/content/ATML-PA2-Task2"))
    parser.add_argument("--backup", type=Path, default=Path(
        "/content/drive/MyDrive/ATML-Assignment-2/task2/runtime_backups/20261008T161047_398047Z/project.zip"))
    args = parser.parse_args()
    import torch
    if torch.cuda.is_available():
        raise RuntimeError("Use a CPU runtime for restoration, installation, tests and downloads")
    manifest = json.loads((PACKAGE / "PACKAGE_SHA256.json").read_text())
    for name, digest in manifest.items():
        if sha256(PACKAGE / name) != digest:
            raise RuntimeError(f"Chunk 2 package checksum differs: {name}")
    restore_project(args.backup, args.repo)
    repo = args.repo.resolve()
    approval = json.loads((repo / "docs/task2_approval.json").read_text())
    head = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
    if head != approval["course_commit"]:
        raise RuntimeError("Restored Git commit differs")
    for name, digest in approval["source_sha256"].items():
        if sha256(repo / name) != digest:
            raise RuntimeError(f"Previously validated Chunk 1 file changed: {name}")
    installs = {p.relative_to(PACKAGE).as_posix(): p.relative_to(PACKAGE).as_posix()
                for subdir in ("task2_ppo", "tests", "scripts")
                for p in (PACKAGE / subdir).rglob("*.py")}
    installs.update({"precision_approval.json": "docs/task2_precision_approval.json",
                     "precision_approval.md": "docs/task2_precision_approval.md",
                     "precision_diagnostic.json": "docs/task2_precision_diagnostic.json",
                     "README.md": "docs/task2_chunk2_README.md"})
    for source, destination in installs.items():
        path = repo / destination
        if path.exists() and sha256(path) != sha256(PACKAGE / source):
            raise RuntimeError(f"Existing file differs and was not overwritten: {destination}")
    subprocess.run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check",
                    "-r", str(repo / "requirements.txt")], check=True)
    installed = {}
    for source, destination in installs.items():
        path = repo / destination
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((PACKAGE / source).read_bytes())
        installed[destination] = sha256(path)
    record_path = repo / "docs/task2_chunk2_files.json"
    if record_path.exists() and json.loads(record_path.read_text()) != installed:
        raise RuntimeError("An existing Chunk 2 installation record differs")
    atomic_json(record_path, installed)
    command = [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_task2_*.py", "-v"]
    result = subprocess.run(command, cwd=repo, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print(result.stdout, flush=True)
    from datetime import datetime, timezone
    from uuid import uuid4
    stage = repo / "results/task2_ppo/setup" / ("chunk2_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + uuid4().hex[:8])
    stage.mkdir(parents=True, exist_ok=False)
    (stage / "tests.log").write_text(result.stdout)
    count = re.search(r"Ran (\d+) tests?", result.stdout)
    report = {"passed": result.returncode == 0, "return_code": result.returncode,
              "tests_run": int(count.group(1)) if count else None,
              "installed_sha256": installed, "gpu_used": False, "course_weights_loaded": False}
    atomic_json(stage / "validation.json", report)
    if not report["passed"] or report["tests_run"] != 37:
        raise RuntimeError("Chunk 2 tests did not all pass; inspect the saved log")
    print("CHUNK 2 CODE INSTALLED: 37 CPU checks passed; no training run.", flush=True)


if __name__ == "__main__":
    main()
