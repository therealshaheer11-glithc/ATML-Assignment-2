"""Seal source, generate thin Colab notebooks, and package reviewable artifacts."""
import ast
import hashlib
import json
import zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save(p,v):
    p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')

def cell(kind,text):
    result={'cell_type':kind,'id':hashlib.sha256(text.encode()).hexdigest()[:12],'metadata':{},'source':text.strip().splitlines(keepends=True)}
    if kind=='code':
        result.update(execution_count=None,outputs=[])
        ast.parse(text.strip())
    return result

source=ROOT/'source'
files={p.relative_to(source).as_posix():sha(p) for p in sorted(source.rglob('*'))
       if p.is_file() and '__pycache__' not in p.parts and p.name!='SOURCE_SHA256.json'}
save(source/'docs/SOURCE_SHA256.json',files)
source_hash=sha(source/'docs/SOURCE_SHA256.json')
bootstrap='''import time
SESSION_START_EPOCH = time.time()
import os, sys, json, hashlib, subprocess, zipfile
from pathlib import Path
from google.colab import files, drive
uploaded = files.upload()  # Upload ATML_PA2_Task3_Colab.zip.
archives = [name for name in uploaded if name.endswith('.zip')]
assert len(archives) == 1, 'Upload exactly the Task 3 package ZIP.'
assert Path(archives[0]).name == archives[0], 'Upload a filename without directories.'
archive_path = Path('/content') / archives[0]
archive_path.write_bytes(uploaded[archives[0]])
del uploaded
package = Path('/content/task3_package')
package.mkdir(exist_ok=True)
with zipfile.ZipFile(archive_path) as z:
    names = z.namelist()
    assert len(names) == len(set(names)), 'Duplicate archive members.'
    manifest = json.loads(z.read('PACKAGE_SHA256.json'))
    assert set(names) == set(manifest) | {'PACKAGE_SHA256.json'}, 'Package file set differs.'
    for item in z.infolist():
        target = (package / item.filename).resolve()
        assert package.resolve() in target.parents, 'Unsafe archive path.'
        assert (item.external_attr >> 16) & 0o170000 != 0o120000, 'Archive contains a link.'
    for name,digest in manifest.items():
        payload = z.read(name)
        assert hashlib.sha256(payload).hexdigest() == digest, 'Package checksum differs: ' + name
        target = package / name
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():
            assert target.read_bytes() == payload, 'Existing package differs; start a fresh Colab runtime.'
        else:
            target.write_bytes(payload)
expected_source = 'SOURCE_HASH'
assert hashlib.sha256((package/'task3/source/docs/SOURCE_SHA256.json').read_bytes()).hexdigest() == expected_source
runtime = Path('/content/task3_runtime/course')
subprocess.run([sys.executable,str(package/'task3/restore_source.py'),'--destination',str(runtime)],check=True)
subprocess.run([sys.executable,'-m','pip','install','-r',str(runtime/'requirements.txt')],check=True)
drive.mount('/content/drive')
EXPERIMENT = '/content/drive/MyDrive/ATML-Assignment-2/task3/experiment_v1'
os.chdir(runtime)
print('Sealed Task 3 source ready. Scientific settings are fixed in the approved package.')
'''.replace('SOURCE_HASH',source_hash)
cpu_run='''# First preparation: False. Set True only to resume this SAME package/contract.
RESUME_PREPARATION = False
command = [sys.executable,'-m','task3_grpo.prepare','--experiment',EXPERIMENT]
if RESUME_PREPARATION:
    command.append('--resume')
subprocess.run(command,check=True)
receipt = json.loads((Path(EXPERIMENT)/'PREPARATION.json').read_text())
assert receipt['full_course_asset_validator_passed'] and not receipt['policy_training_performed']
print('CPU preparation verified on Drive. Next open the GPU notebook and choose a GPU runtime.')
drive.flush_and_unmount()
'''
gpu_run='''# Resume is contract-checked; this never starts a replacement experiment.
command = [sys.executable,'-u','-m','task3_grpo.pipeline','--experiment',EXPERIMENT,
           '--local','/content/task3_runtime/results','--resume',
           '--session-start-epoch',str(SESSION_START_EPOCH)]
process = subprocess.run(command)  # Returns only after the model process exits.
if process.returncode not in (0,75):
    raise RuntimeError('Task 3 stopped with an error. Completed units remain on Drive. Runtime retained for inspection.')
safe = json.loads((Path(EXPERIMENT)/'SAFE_TO_DISCONNECT.json').read_text())
assert safe['created_epoch'] >= SESSION_START_EPOCH
assert safe['model_jobs_returned'] and safe['all_committed_archives_verified']
assert safe['source']['source_manifest_sha256'] == expected_source
for name,digest in safe['archives_sha256'].items():
    h = hashlib.sha256()
    with (Path(EXPERIMENT)/name).open('rb') as f:
        for block in iter(lambda:f.read(2**20),b''):
            h.update(block)
    assert h.hexdigest() == digest, 'Drive changed after process exit: ' + name
print(safe['status'])
if safe['status'] == 'COMPLETE':
    print('Results: '+EXPERIMENT+'/task3_small_results.zip')
else:
    print('120-minute scheduling boundary reached. Run this notebook again to resume saved work.')
# Approved automatic disconnect: verification, stopped process, then successful flush.
# If any earlier assertion or flush fails, unassign is never reached.
drive.flush_and_unmount()
from google.colab import runtime as colab_runtime
colab_runtime.unassign()
'''
for name,title,body,run in [
    ('01_CPU_Prepare.ipynb','Task 3 — CPU preparation',
     'Choose Runtime → Change runtime type → Hardware accelerator **None**. Run both cells. Upload `ATML_PA2_Task3_Colab.zip` when prompted. This downloads pinned course assets and model files to Drive, runs CPU tests, freezes prompt/seed schedules and computes the supplied-cache study. It does not load policy weights or train. An existing experiment requires an explicit same-contract resume.',cpu_run),
    ('02_GPU_Run_and_Resume.ipynb','Task 3 — GPU run and resume',
     'Complete the CPU notebook first. Choose a **GPU** runtime and run both cells. Upload the same package ZIP. The fixed queue runs the common probe, standard 20-update continuation, two independent 8-update forks and all four 200-prompt evaluations. Every completed unit persists to Drive. A 120-minute scheduling boundary pauses between units; run this notebook again to resume. A current unit may overrun the boundary. Errors retain the runtime; successful saves and Drive flushing permit the approved automatic disconnect.',gpu_run)]:
    cells=[cell('markdown','# '+title+'\n\n'+body+'\n\nNo reported result exists until its job actually runs. The standard endpoint is reserved for Task 4. New experimental choices require explicit approval.'),
           cell('code',bootstrap),cell('code',run)]
    notebook={'nbformat':4,'nbformat_minor':5,'metadata':{'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},
        'language_info':{'name':'python'},'colab':{'name':name,'provenance':[]}},'cells':cells}
    save(ROOT/'notebooks'/name,notebook)
# Package contains no private course asset bundle, model weights or runtime outputs.
package_files={p:'task3/'+p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*')
    if p.is_file() and not any(part in ('__pycache__','.runtime') for part in p.relative_to(ROOT).parts)
    and p.suffix not in ('.pyc','.zip')}
manifest={name:sha(p) for p,name in sorted(package_files.items(),key=lambda v:v[1])}
archive=ROOT.parent/'ATML_PA2_Task3_Colab.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p,name in package_files.items(): z.write(p,name)
    z.writestr('PACKAGE_SHA256.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(manifest)|{'PACKAGE_SHA256.json'}
    assert all(hashlib.sha256(z.read(name)).hexdigest()==h for name,h in manifest.items())
save(ROOT.parent/'ATML_PA2_Task3_Colab.sha256.json',{'archive':archive.name,'sha256':sha(archive),
    'bytes':archive.stat().st_size,'source_manifest_sha256':source_hash,'files':len(manifest)})
print('Packaged',archive,'source',source_hash)
